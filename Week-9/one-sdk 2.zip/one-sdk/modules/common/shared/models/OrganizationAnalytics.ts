import { getDot } from "../utils/dotNotation";
import { IAnalyticsData, IOrganizationAnalytics, TIssueCount, TPassRateAnalytics, TRiskLevelAnalytics } from "./api";

export class OrganizationAnalytics {
  pass_rate: TPassRateAnalytics;
  risk_level: TRiskLevelAnalytics;
  issues: TIssueCount[];
  children: any;
  constructor(analytics = {}) {
    const { pass_rate, risk_level, issues } = {
      pass_rate: {
        passed: 0,
        manually_passed: 0,
        failed: 0,
        manually_failed: 0,
        needs_attention: 0,
        unchecked: 0,
        pending: 0,
        duplicate: 0,
        archived: 0,
        inactive: 0,
      },
      risk_level: {
        high: 0,
        low: 0,
        medium: 0,
        unacceptable: 0,
        unknown: 0,
      },
      issues: [],
      ...analytics,
    };

    this.pass_rate = {
      passed: pass_rate.passed || 0,
      manually_passed: pass_rate.manually_passed || 0,
      failed: pass_rate.failed || 0,
      manually_failed: pass_rate.manually_failed || 0,
      needs_attention: pass_rate.needs_attention || 0,
      unchecked: pass_rate.unchecked || 0,
      pending: pass_rate.pending || 0,
      duplicate: pass_rate.duplicate || 0,
      archived: pass_rate.archived || 0,
      inactive: pass_rate.inactive || 0,
    };
    this.risk_level = {
      high: risk_level.high || 0,
      low: risk_level.low || 0,
      medium: risk_level.medium || 0,
      unacceptable: risk_level.unacceptable || 0,
      unknown: risk_level.unknown || 0,
    };
    this.issues = issues.filter((iss: TIssueCount) => !!iss.count);
    this.children = {};
  }
  init(data: IAnalyticsData): OrganizationAnalytics {
    const { own: parentData, ...childrenData } = data;
    const organization = new OrganizationAnalytics(parentData);
    const childrenIdDataArray = Object.entries(childrenData);
    childrenIdDataArray.forEach((children) => {
      const [id, data] = children;
      organization.addChild(id, data);
    });
    return organization;
  }
  getChildrenAsArray() {
    return Object.values(this.children);
  }

  addChild(id, organizationAnalytics) {
    this.children[id] = organizationAnalytics;
    return this;
  }

  getChild(id) {
    return this.children[id];
  }

  getBundle(ids, includeParent) {
    const children = Object.entries(this.children)
      .filter(([id, _data]) => ids.includes(id))
      .map(([_id, data]) => data as IOrganizationAnalytics);
    const addChildren = (dot): number => {
      return children.reduce((sum: number, child) => {
        const value = getDot(dot, child);
        return sum + value;
      }, 0);
    };
    const addAllFrom = (dot) => {
      let sum = 0;
      if (includeParent) sum += getDot(dot, this);
      sum += addChildren(dot);
      return sum;
    };
    const countParentIssue = (type) => {
      const issue = this.issues.find((iss) => iss.type === type);
      return issue ? issue.count : 0;
    };
    const countChildrenIssue = (type) => {
      const sum = children.reduce((sum: number, child) => {
        const issue = (child as IOrganizationAnalytics).issues.find((iss) => iss.type === type);
        if (issue) {
          return sum + issue.count;
        }
        return sum;
      }, 0);
      return sum;
    };
    const uniqueIssueTypes = (() => {
      const allOfChildrenIssues = (children as IOrganizationAnalytics[]).reduce((issues: string[], child) => {
        const issueTypes = child.issues.map((iss) => iss.type);
        issues.push(...issueTypes);
        return issues;
      }, []);
      if (includeParent) allOfChildrenIssues.push(...this.issues.map((is) => is.type));

      return Array.from(new Set(allOfChildrenIssues));
    })();
    const sumOfIssues = uniqueIssueTypes.map((type) => ({
      type,
      count: (includeParent ? countParentIssue(type) : 0) + countChildrenIssue(type),
    }));

    const total = {
      pass_rate: {
        passed: addAllFrom("pass_rate.passed"),
        manually_passed: addAllFrom("pass_rate.manually_passed"),
        failed: addAllFrom("pass_rate.failed"),
        manually_failed: addAllFrom("pass_rate.manually_failed"),
        needs_attention: addAllFrom("pass_rate.needs_attention"),
        // unchecked: addAllFrom("pass_rate.unchecked"),
        pending: addAllFrom("pass_rate.pending"),
        // duplicate: addAllFrom("pass_rate.duplicate"),
        // archived: addAllFrom("pass_rate.archived"),
        // inactive: addAllFrom("pass_rate.inactive")
      },
      risk_level: {
        high: addAllFrom("risk_level.high"),
        low: addAllFrom("risk_level.low"),
        medium: addAllFrom("risk_level.medium"),
        unacceptable: addAllFrom("risk_level.unacceptable"),
        unknown: addAllFrom("risk_level.unknown"),
      },
      issues: sumOfIssues,
    };
    return new OrganizationAnalytics(total);
  }

  getTotal() {
    const allIds = Object.keys(this.children);
    return this.getBundle(allIds, true);
  }
}
