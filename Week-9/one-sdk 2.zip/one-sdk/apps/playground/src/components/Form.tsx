import { useEffect, useMemo, type CSSProperties } from 'react';

import { wildcardEventLogger } from '@frankieone/one-sdk';
import type { OneSdkContext } from '@module/types';

import useScreenToggle from '../hooks/useScreenToggle';

export function Form(o: { oneSdk: OneSdkContext }) {
  const { oneSdk } = o;

  const { isFullScreen, toggleScreen } = useScreenToggle();

  //change configuration based on your requirement
  const form = oneSdk.component('form', {
    name: 'ID_SELECTION',
  });

  useEffect(() => {
    form.on('*', wildcardEventLogger);

    form.mount('#form-container');

    return () => {
      form.off('*', wildcardEventLogger);
    };
  }, []);

  const containerStyle: CSSProperties = useMemo(
    () => ({
      width: isFullScreen ? '100%' : '',
      maxWidth: isFullScreen ? '100%' : '390px',
      height: isFullScreen ? '100%' : '844px',
      top: '0',
      left: '0',
      position: isFullScreen ? 'fixed' : 'relative',
      margin: '0 auto',
      border: '1px solid',
    }),
    [isFullScreen]
  );

  return (
    <>
      <h3 style={{ marginBottom: 0 }}>Update details below</h3>
      <h4
        style={{
          fontStyle: 'italic',
          fontWeight: 'normal',
          margin: 0,
          marginBottom: '2em',
        }}
      ></h4>
      {isFullScreen && (
        <button
          onClick={() => toggleScreen(false)}
          style={{ position: 'absolute', top: 0, right: 0, zIndex: 1000 }}
        >
          Exit
        </button>
      )}
      {<button onClick={() => toggleScreen(true)}>Full Screen</button>}
      <div id="form-container" style={containerStyle}></div>
    </>
  );
}
