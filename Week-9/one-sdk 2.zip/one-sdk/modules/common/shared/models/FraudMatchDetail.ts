import { Address } from "./Address";

interface IFraudMatchDetail {
  fraudType: string | null;
  matchType: string | null;
  matchList: IMatchField[];
  extraDetails: IExtraDetail[];
  subject: string | null;
  reportedBy: string | null;
  dateOfFraud: string | null;
  status: IMatchStatus;
  comment: string | null;
  address: Address;
  matchListId: string | null;
  checkId: string | null;
}

interface IMatchDetails {
  key: string;
  value: string | null;
}

export interface IMatchField {
  type: "phone_number" | "id_details" | "employment" | "comment";
  matches: IMatchDetails[];
}

export interface IMatchStatus {
  label: string | null;
  value: string | null;
}

export interface IExtraDetail {
  label: string;
  value: string | null;
}

export class FraudMatchDetail implements IFraudMatchDetail {
  fraudType: string | null = null;
  matchType: string | null = null;
  matchList: IMatchField[] = [];
  extraDetails: IExtraDetail[] = [];
  subject: string | null = null;
  reportedBy: string | null = null;
  dateOfFraud: string | null = null;
  status: IMatchStatus = {
    label: null,
    value: null,
  };
  comment: string | null = null;
  address: Address = new Address();
  matchListId: string | null = null;
  checkId: string | null = null;

  toJSON(): IFraudMatchDetail {
    const address = this.address.toJSON();
    return { ...this, address };
  }
  static fromJSON(payload: IFraudMatchDetail): FraudMatchDetail {
    const fraudMatchDetail = new FraudMatchDetail();
    fraudMatchDetail.fraudType = payload.fraudType;
    fraudMatchDetail.matchType = payload.matchType;
    fraudMatchDetail.matchList = payload.matchList;
    fraudMatchDetail.extraDetails = payload.extraDetails;
    fraudMatchDetail.subject = payload.subject;
    fraudMatchDetail.status = payload.status;
    fraudMatchDetail.comment = payload.comment;
    fraudMatchDetail.dateOfFraud = payload.dateOfFraud;
    fraudMatchDetail.reportedBy = payload.reportedBy;
    fraudMatchDetail.matchListId = payload.matchListId;
    fraudMatchDetail.checkId = payload.checkId;
    fraudMatchDetail.address = Address.fromJSON(payload.address);
    return fraudMatchDetail;
  }
}
