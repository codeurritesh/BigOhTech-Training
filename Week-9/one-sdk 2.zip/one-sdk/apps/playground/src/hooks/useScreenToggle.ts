import { useState } from "react";

const useScreenToggle = () => {
  const [isFullScreen, setFullScreen] = useState(false);

  const toggleScreen = (isToggle: boolean) => setFullScreen(isToggle);

  return {
    isFullScreen,
    toggleScreen,
  };
};

export default useScreenToggle;
