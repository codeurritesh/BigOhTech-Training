import type { ModuleDefinition } from "@module/common/types";
import type { SessionContext } from "./SessionContext";
import { GlobalEvents } from "@module/sdk/types";
import { EventHub } from "@module/common";

export type SessionModule = ModuleDefinition<{
  module: {
    category: "setup";
    name: "session";
    context: SessionContext;
    options: {
      globalEventHub: EventHub<GlobalEvents>;
    };
  };
}>;
