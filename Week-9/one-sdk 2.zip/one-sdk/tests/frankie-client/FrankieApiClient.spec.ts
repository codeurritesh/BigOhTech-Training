import { ENVIRONMENTS, stringToBase64 } from "@module/common";
import { FrankieApiClient } from "@module/frankie-client";
import { AxiosResponse } from "axios";
import mockAxiosInstance from "jest-mock-axios";
import { mockSessionContext } from "../mocks/SessionContext";
import { jwtWithEntityId, jwtWithReference } from "../testUtils/tokens";

jest.mock("axios", () => {
  return {
    create: jest.fn().mockImplementation(function () {
      return mockAxiosInstance;
    }),
  };
});
const mkClient = () => new FrankieApiClient();
describe("Frankie Client", () => {
  beforeEach(() => {
    mockAxiosInstance.mockClear();
  });
  test("Call to login will call machine-session endpoint and return resulting token", async () => {
    const client = mkClient();
    const postSpy = jest.spyOn(client, "post").mockResolvedValue(<AxiosResponse>{
      data: { token: jwtWithEntityId },
    });
    const token = await client.login(
      { customerID: "ID", apiKey: "KEY" },
      { entityId: "some-id" },
      {
        environment: ENVIRONMENTS.development,
      }
    );
    expect(token).toBe(jwtWithEntityId);
    expect(postSpy).toHaveBeenCalledWith(
      "/auth/v2/machine-session",
      {
        permissions: {
          preset: "one-sdk",
          entityId: "some-id",
        },
      },
      {
        headers: {
          authorization: `machine ${stringToBase64("ID:KEY")}`,
        },
      }
    );
  });
  test("Initialise FrankieApiClient exposes get|put|delete|post methods that proxy directly to axios", async () => {
    const client = mkClient();
    client.get("some-url");
    client.delete("some-url");
    client.post("some-url", { data: true });
    client.put("some-url", { data: true });
    // "undefined" is required by jest to indicate no second parameter was provided
    expect(mockAxiosInstance.get).toHaveBeenCalledWith("some-url", undefined);
    expect(mockAxiosInstance.delete).toHaveBeenCalledWith("some-url", undefined);
    expect(mockAxiosInstance.post).toHaveBeenCalledWith("some-url", { data: true }, undefined);
    expect(mockAxiosInstance.put).toHaveBeenCalledWith("some-url", { data: true }, undefined);
  });
  test("Frankie client allows changing of its token (with entityId)", async () => {
    const client = mkClient();
    client.session = mockSessionContext(jwtWithEntityId);

    expect(client.session.token).toBe(jwtWithEntityId);
    expect(client.session.entityId).toBe("some-id");
    expect(client.session.reference).toBe(null);
    expect(client.session.environment).toBe("https://some-environment.com");
    expect(client.session.sessionId).toBe("some-session-id");
    expect(client.session.customerID).toBe("customer-id");
  });
  test("Frankie client allows changing of its token (with reference)", async () => {
    const client = mkClient();
    client.session = mockSessionContext(jwtWithReference);

    expect(client.session.token).toBe(jwtWithReference);
    expect(client.session.entityId).toBe(null);
    expect(client.session.reference).toBe("some-reference");
    expect(client.session.environment).toBe("https://some-environment.com");
    expect(client.session.sessionId).toBe("some-session-id");
    expect(client.session.customerID).toBe("customer-id");
  });
  test("Frankie client updates its token when a new token is present in response's header 'token', but keeps already found existing entityIds", async () => {
    const client = mkClient();
    client.session = mockSessionContext(jwtWithEntityId);

    expect(client.session.token).toBe(jwtWithEntityId);
    expect(client.session.entityId).toBe("some-id");
    expect(client.session.environment).toBe("https://some-environment.com");
    expect(client.session.sessionId).toBe("some-session-id");
    expect(client.session.reference).toBe(null);
    expect(client.session.customerID).toBe("customer-id");

    client.get("/some-endpoint");
    mockAxiosInstance.mockResponse({
      headers: { token: jwtWithReference },
      data: {},
    });

    expect(client.session.token).toBe(jwtWithReference);
    expect(client.session.entityId).toBe("some-id");
    expect(client.session.environment).toBe("https://some-environment.com");
    expect(client.session.sessionId).toBe("some-session-id");
    expect(client.session.reference).toBe("some-reference");
    expect(client.session.customerID).toBe("customer-id");
  });
});
