import type { Document } from '@module/common/shared/models/Document';
import type { IDVStatus } from '@module/frankie-client/clients/IDVClient';

import type { BiometricsModule } from './definition';

type Vendor = BiometricsModule['vendorName'];
export type Events = {
  vendor_sdk_loaded: [{ vendor: Vendor }];
  vendor_sdk_failed_loading: [{ vendor: Vendor; errorObject: unknown }];
  session_data_generated: [{ session: unknown }];
  session_data_failed_loading: [{ code?: unknown; message: string }];
  ready: [{ domElement: HTMLElement }];
  input_required: [info: { entityId: string }, status: IDVStatus];
  detection_complete: [];
  detection_failed: [{ message?: string }];
  processing: [{ checkStatus: IDVStatus; entityId: string }];
  results: [{ checkStatus: IDVStatus; document: Document; entityId: string }];
  session_closed: [];
};
