export type TIssueType = "warning" | "action" | "alert" | "success";
export interface IIssue {
  term: string;
  type: TIssueType;
}
export interface IIssueAction extends IIssue {
  type: "action";
  extra: {
    action: string;
    label?: string;
  };
}
