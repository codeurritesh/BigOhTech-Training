import { FrankieApiClient } from "@module/frankie-client";

export const eventHubAssertion = expect.objectContaining({
  on: expect.any(Function),
  off: expect.any(Function),
  emit: expect.any(Function),
  hasListenersFor: expect.any(Function),
});
export function expectEventHub(object: unknown) {
  expect(object).toEqual(eventHubAssertion);
}
export function expectFrankieClient(object: unknown) {
  expect(object).toStrictEqual(expect.any(FrankieApiClient));
}
