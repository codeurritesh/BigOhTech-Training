import { Address, IAddressPayload } from "./Address";
import { Dictionary, Nullable } from "./general";
export interface IBusinessInfoPayload {
  entityId: Nullable<string>;
  customerID: Nullable<string>;
  businessProfile: Nullable<string>;
  businessName: Nullable<string>;
  businessType: Nullable<string>;
  ABNNumber: Nullable<string>;
  ACNNumber: Nullable<string>;
  ARBNNumber: Nullable<string>;
  addresses: IAddressPayload[];
  businessReportRequestedAt: Nullable<Dictionary<string>>;
  mccCode: Nullable<string>;
}
export class BusinessInfo {
  entityId: Nullable<string> = null;
  customerID: Nullable<string> = null;
  businessProfile: Nullable<string> = null;
  businessName: Nullable<string> = null;
  businessType: Nullable<string> = null;
  ABNNumber: Nullable<string> = null;
  ACNNumber: Nullable<string> = null;
  ARBNNumber: Nullable<string> = null;
  addresses: Address[] = [];
  mccCode: Nullable<string> = null;

  get isBusinessReportInProgress() {
    return Boolean(this.businessReportRequestedAt);
  }
  clone(): BusinessInfo {
    const business = new BusinessInfo();
    business.customerID = this.customerID;
    business.businessProfile = this.businessProfile;
    business.businessName = this.businessName;
    business.businessType = this.businessType;
    business.ABNNumber = this.ABNNumber;
    business.ACNNumber = this.ACNNumber;
    business.ARBNNumber = this.ARBNNumber;
    business.mccCode = this.mccCode;
    return business;
  }
  businessReportRequestedAt: Nullable<Dictionary<string>> = null;

  toJSON(): IBusinessInfoPayload {
    const { addresses = [] } = this;
    const addressMap = addresses.filter((a) => !a.isIncomplete).map((a) => a.toJSON());
    return {
      entityId: this.entityId,
      customerID: this.customerID,
      businessProfile: this.businessProfile,
      businessName: this.businessName,
      businessType: this.businessType,
      ABNNumber: this.ABNNumber,
      ACNNumber: this.ACNNumber,
      ARBNNumber: this.ARBNNumber,
      businessReportRequestedAt: this.businessReportRequestedAt ?? null,
      addresses: addressMap,
      mccCode: this.mccCode,
    };
  }
  static fromJSON(payload: IBusinessInfoPayload) {
    const instance = new BusinessInfo();
    instance.entityId = payload.entityId;
    instance.customerID = payload.customerID;
    instance.businessProfile = payload.businessProfile;
    instance.businessName = payload.businessName;
    instance.businessType = payload.businessType;
    instance.ABNNumber = payload.ABNNumber;
    instance.ACNNumber = payload.ACNNumber;
    instance.ARBNNumber = payload.ARBNNumber;
    instance.addresses = payload.addresses?.map((add) => Address.fromJSON(add)) ?? [];
    instance.businessReportRequestedAt = payload.businessReportRequestedAt;
    instance.mccCode = payload.mccCode;
    return instance;
  }
}
