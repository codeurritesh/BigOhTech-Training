import { OneSdkRootParameters } from "@module/sdk/types";
import { SessionContext } from "../SessionContext";

export interface SessionModule {
  initialise: (o: OneSdkRootParameters) => SessionContext;
}
