/**
 * Triggers all callbacks for a particular event provided to a mocked "on" function.
 * @param onMethod mocked "on" function to find all the callbacks for the event
 * @param eventName event name to find the callback to be triggered
 * @param args arguments to be passed to the callback
 */
export function triggerEvent(onMethod: jest.Mock, eventName: string, ...args: unknown[]) {
  const allCalls = onMethod.mock.calls;
  // prettier-ignore
  const callbacks = allCalls
    .filter(([ev]) => ev === eventName)
    .map(([, callback]) => callback);
  callbacks.forEach((callback) => callback(...args));
}
