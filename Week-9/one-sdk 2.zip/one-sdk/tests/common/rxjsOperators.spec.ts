import { naiveObjectComparison } from "@module/common/modules/objectUtils";
import { onlyWhenChanged } from "@module/common/modules/rxjsOperators";
import { Subject } from "rxjs";

describe("rxjs custom operators", () => {
  test("onlyWhenChanged wraps distinctUntilChanged to detect changes in an observable value using the default comparison function", () => {
    const subject = new Subject();
    const observable = subject.pipe(onlyWhenChanged());
    const observer = jest.fn();
    observable.subscribe(observer);
    subject.next("A");
    subject.next("B");
    subject.next("B");
    subject.next("A");
    expect(observer).toHaveBeenCalledTimes(3);
    expect(observer).toHaveBeenNthCalledWith(1, "A");
    expect(observer).toHaveBeenNthCalledWith(2, "B");
    expect(observer).toHaveBeenNthCalledWith(3, "A");
  });
  test("onlyWhenChanged wraps distinctUntilChanged doesn't detect changes to non primitives when using the default comparison function", () => {
    const subject = new Subject();
    const observable = subject.pipe(onlyWhenChanged());
    const observer = jest.fn();
    observable.subscribe(observer);
    subject.next({ a: "A" });
    subject.next({ b: "B" });
    subject.next({ b: "B" });
    subject.next({ a: "A" });
    expect(observer).toHaveBeenCalledTimes(4);
    expect(observer).toHaveBeenNthCalledWith(1, { a: "A" });
    expect(observer).toHaveBeenNthCalledWith(2, { b: "B" });
    expect(observer).toHaveBeenNthCalledWith(3, { b: "B" });
    expect(observer).toHaveBeenNthCalledWith(4, { a: "A" });
  });
  test("onlyWhenChanged wraps distinctUntilChanged detects changes to any serialisable values when using the default comparison function", () => {
    const subject = new Subject();
    const observable = subject.pipe(onlyWhenChanged(naiveObjectComparison));
    const observer = jest.fn();
    observable.subscribe(observer);
    subject.next({ a: "A" });
    subject.next({ b: "B" });
    subject.next({ b: "B" });
    subject.next({ a: "A" });
    expect(observer).toHaveBeenCalledTimes(3);
    expect(observer).toHaveBeenNthCalledWith(1, { a: "A" });
    expect(observer).toHaveBeenNthCalledWith(2, { b: "B" });
    expect(observer).toHaveBeenNthCalledWith(3, { a: "A" });
  });
});
