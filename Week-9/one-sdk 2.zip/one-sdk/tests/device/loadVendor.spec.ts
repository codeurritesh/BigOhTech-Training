import { mkEventHub } from '@module/common';
import { InjectedState } from '@module/common/types';
import DeviceInitialise from '@module/device';
import { initialise as SardineInitialise } from '@module/device/vendors/Sardine';
import { initialise as ThreatmetrixInitialise } from '@module/device/vendors/Threatmetrix';
import { RecipeParsed, SdkModes } from '@module/sdk/types';
import { eventHubAssertion } from '@tests/testUtils/expecters';
import { mockFunction, optionalParameters } from '@tests/testUtils/functionUtilities';
import { delayTest } from '../testUtils/asyncUtils';

const DeviceModule = optionalParameters(DeviceInitialise);
const mockInitialiseSardine = mockFunction(SardineInitialise);
const mockInitialiseThreatmetrix = mockFunction(ThreatmetrixInitialise);

jest.mock('@module/device/vendors/Sardine.ts', () => {
  return {
    initialise: jest.fn().mockResolvedValue({ vendor: 'sardine' }),
  };
});
jest.mock('@module/device/vendors/Threatmetrix/index.ts', () => {
  return {
    initialise: jest.fn().mockResolvedValue({ vendor: 'threatmetrix' }),
  };
});

describe('device:: module initialisation', () => {
  beforeEach(() => {
    mockInitialiseSardine.mockClear();
    mockInitialiseThreatmetrix.mockClear();
  });
  test("initialising device module with provider 'sardine' causes dynamic import of sardine wrapper", async () => {
    const loadedEvent = jest.fn();
    const failureEvent = jest.fn();
    const globalEventHub = mkEventHub();
    const device = DeviceModule(
      <InjectedState>{
        mode: { modeName: SdkModes.PROD },
        moduleMeta: { moduleName: 'device', instanceName: 'device' },
        globalEventHub,
        recipe: <RecipeParsed>{
          deviceCharacteristics: { provider: { name: 'sardine', clientID: 'some id', environment: 'sandbox' } },
        },
      },
      {
        activityType: 'LOGIN',
      },
    );

    device.on('vendor_sdk_loaded', loadedEvent);
    device.on('vendor_sdk_failed_loading', failureEvent);
    device.start();

    return delayTest(() => {
      expect(loadedEvent).toHaveBeenCalledWith({ vendor: 'sardine', componentName: 'device', instanceName: 'device' });
      expect(failureEvent).not.toHaveBeenCalled();
      expect(mockInitialiseSardine).toHaveBeenCalledWith(
        {
          mode: { modeName: SdkModes.PROD },
          moduleMeta: { moduleName: 'device', instanceName: 'device' },
          globalEventHub: eventHubAssertion,
          localEventHub: eventHubAssertion,
          recipe: <RecipeParsed>{
            deviceCharacteristics: { provider: { name: 'sardine', clientID: 'some id', environment: 'sandbox' } },
          },
        },
        {
          eventHub: eventHubAssertion,
          activityType: 'LOGIN',
        },
      );
    }, 2);
  });
  test("initialising device module with provider 'threatmetrix' causes dynamic import of threatmetrix wrapper", async () => {
    const loadedEvent = jest.fn();
    const failureEvent = jest.fn();
    const globalEventHub = mkEventHub();

    const device = DeviceModule(
      <InjectedState>{
        mode: { modeName: SdkModes.PROD },
        moduleMeta: { moduleName: 'device', instanceName: 'device' },
        globalEventHub,
        recipe: <RecipeParsed>{
          deviceCharacteristics: { provider: { name: 'threatmetrix', clientID: 'some id', environment: 'sandbox' } },
        },
      },
      {
        activityType: 'REGISTRATION',
      },
    );
    device.on('vendor_sdk_loaded', loadedEvent);
    device.on('vendor_sdk_failed_loading', failureEvent);
    device.start();

    return delayTest(() => {
      expect(loadedEvent).toHaveBeenCalledWith({
        vendor: 'threatmetrix',
        componentName: 'device',
        instanceName: 'device',
      });
      expect(failureEvent).not.toHaveBeenCalled();
      expect(mockInitialiseThreatmetrix).toHaveBeenCalledWith(
        {
          mode: { modeName: SdkModes.PROD },
          moduleMeta: { moduleName: 'device', instanceName: 'device' },
          globalEventHub: eventHubAssertion,
          localEventHub: eventHubAssertion,
          recipe: <RecipeParsed>{
            deviceCharacteristics: { provider: { name: 'threatmetrix', clientID: 'some id', environment: 'sandbox' } },
          },
        },
        {
          activityType: 'REGISTRATION',
          eventHub: eventHubAssertion,
        },
      );
    }, 2);
  });
  test("initialising device module with provider 'nonexisting', which doesn't exist, causes dynamic import to fail with event 'vendor_sdk_failed_loading'", async () => {
    const loadedEvent = jest.fn();
    const failureEvent = jest.fn();
    const globalEventHub = mkEventHub();

    const device = DeviceModule(
      <InjectedState>{
        mode: { modeName: SdkModes.PROD },
        moduleMeta: { moduleName: 'device', instanceName: 'device' },
        globalEventHub,
        recipe: <RecipeParsed>{
          deviceCharacteristics: { provider: { name: <unknown>'nonexisting', environment: 'sandbox' } },
        },
      },
      {
        activityType: 'LOGIN',
      },
    );

    device.on('vendor_sdk_loaded', loadedEvent);
    device.on('vendor_sdk_failed_loading', failureEvent);
    device.start();

    return delayTest(() => {
      expect(loadedEvent).not.toHaveBeenCalled();
      expect(failureEvent).toHaveBeenCalledWith(
        expect.objectContaining({
          errorObject: expect.objectContaining(new Error("Vendor not recognised: 'nonexisting'")),
          vendor: 'nonexisting',
        }),
      );
      expect(mockInitialiseThreatmetrix).not.toHaveBeenCalled();
    }, 2);
  });
});
