import { EventHub, mkEventHub } from "@module/common";
import { Applicant } from "@module/common/shared/models/Applicant";
import { GlobalState } from "@module/common/types";
import { DummyFrankieApiClient, FrankieApiClient } from "@module/frankie-client";
import OneSdk from "@module/index";
import { parseConfiguration } from "@module/sdk/initialisation/configurationParser";
import { OneSdkRootParameters, SdkModes } from "@module/sdk/types";
import { mockSessionContext } from "../../mocks/SessionContext";

jest.mock("@module/sdk/initialisation/configurationParser", () => {
  return {
    ...jest.requireActual("@module/sdk/initialisation/configurationParser"),
    parseConfiguration: jest.fn(),
    resolveMode: jest.fn((o) => ({ mode: o.mode, modeName: o.mode })),
  };
});
const mockedInitialiseIndividual = jest.fn().mockReturnValue({ on: (_, cb: () => void) => cb() });

jest.mock("@module/config/modules", () => ({
  getInitialiser: jest.fn().mockImplementation((key: string) => {
    if (key === "individual") {
      return mockedInitialiseIndividual;
    }
    if (key === "session") return () => mockSessionContext();
    return jest.fn();
  }),
}));

const dummyClient = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
(dummyClient.session = mockSessionContext()),
  dummyClient.stubResponse(
    { url: "/data/v2/applicant/", method: "get" },
    {
      data: {
        applicant: new Applicant(),
        documents: [],
      },
    }
  );
describe("OneSdk entry", () => {
  const { mergeGlobalState, mockClear } = mockParseConfigurationFunction();

  beforeEach(() => {
    mergeGlobalState({
      frankieClient: dummyClient,
      globalEventHub: <EventHub>{},
      mode: { modeName: SdkModes.DUMMY, is: (v) => v === SdkModes.DUMMY },
      recipe: { name: "some-recipe" },
    });
    mockClear();
  });
  test("OneSdk default export is function and exposes properties FrankieApiClient and utils", () => {
    expect(typeof OneSdk).toBe("function");
    expect(OneSdk.FrankieApiClient).toBe(FrankieApiClient);
    expect(typeof OneSdk.utils).toEqual("object");
  });
  test("OneSdk initialisation function returns object exposing on, off and component methods", async () => {
    const oneSdk = await OneSdk({
      mode: SdkModes.DUMMY,
    });
    expect(typeof oneSdk.on).toBe("function");
    expect(typeof oneSdk.off).toBe("function");
    expect(typeof oneSdk.component).toBe("function");
    expect(typeof oneSdk.flow).toBe("function");
  });
  test("OneSdk initialisation calls parseConfiguration with its root parameters", async () => {
    const initOptions: OneSdkRootParameters = {
      mode: SdkModes.DUMMY,
      recipe: {
        name: "root parameter",
        deviceCharacteristics: {
          provider: {
            name: "sardine",
            clientID: "some-client-id",
          },
        },
      },
    };
    await OneSdk(initOptions);
    expect(parseConfiguration).toHaveBeenCalledWith(
      {
        ...initOptions,
        mode: { modeName: initOptions.mode, is: expect.any(Function) },
        session: {
          appReference: null,
          persist: false,
          token: null,
        },
        telemetry: true,
      },
      expect.objectContaining({
        frankieClient: expect.any(Object),
        globalEventHub: expect.any(Object),
      })
    );
    // just a quick extra sanity check
    expect(parseConfiguration).not.toHaveBeenCalledWith({ ...initOptions, recipe: "not this" });
  });
});

function mockParseConfigurationFunction() {
  const globalState = <GlobalState>{
    session: {},
  };
  const getMock = () => <jest.Mock>parseConfiguration;
  const mergeGlobalState = (state: Partial<GlobalState>) => {
    return getMock().mockResolvedValue({
      globalState: Object.assign(globalState, state),
      warnings: [],
    });
  };
  const mockClear = () => getMock().mockClear();
  return {
    getMock,
    mockClear,
    mergeGlobalState,
  };
}
