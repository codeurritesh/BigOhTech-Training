/** @type {import('tailwindcss').Config} */
import colors from './styles/tailwind/color'
import { text, icon } from './styles/tailwind/fontSize'
import { screens } from './styles/tailwind/screen'
import {
  spacing,
  spacingObject as object,
  outlineWidth
} from './styles/tailwind/spacing'

export default {
  prefix: 'f1-',
  content: [
    './modules/form/vendors/react/**/*.tsx'
  ],
  theme: {
    colors,
    borderRadius: {
      full: '9999px',
      ...spacing
    },
    fontSize: {
      ...text,
      ...icon
    },
    screens,
    extend: {
      spacing: {
        ...spacing,
        ...icon,
        ...object
      },
      outlineWidth
    }
  },
  plugins: [],
  corePlugins: {
    preflight: false
  }
}

