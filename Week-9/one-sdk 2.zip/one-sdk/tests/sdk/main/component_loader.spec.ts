import { jest } from '@jest/globals';

import { mkEventHub } from '@module/common';
import { Applicant } from '@module/common/shared/models/Applicant';
import type { InjectedState } from '@module/common/types';
import { getInitialiser } from '@module/config/modules';
import { DummyFrankieApiClient, mkFrankieClient } from '@module/frankie-client';
import {
  mkModuleInstantiator,
} from '@module/sdk/initialisation/componentLoader';
import type { AnyFunction } from '@types';

type Loader = ReturnType<typeof mkModuleInstantiator>;
type Module = ReturnType<Loader>;
type Mocked =
  { instances: Record<string, Record<string, Module>> }
  & ((name: string, options?: object) => Module);
jest.mock('@module/config/modules', () => {
  return {
    getInitialiser: jest.fn(),
  };
});
jest.mock('@module/frankie-client/index.ts', () => {
  return {
    mkFrankieClient: jest.fn(() => new DummyFrankieApiClient({ globalEventHub: mkEventHub() })),
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    DummyFrankieApiClient: jest.requireActual('@module/frankie-client/index.ts').DummyFrankieApiClient,
  };
});
const mkComponentLoader = (injected: Partial<InjectedState> = {}) => {
  return <Mocked>(<unknown>mkModuleInstantiator(<InjectedState>{
    oneSdkInstance: { mock: 'oneSdkInstance' },
    recipe: { mock: 'recipe' },
    frankieClient: { mock: 'frankieClient' },
    mode: { mock: 'mode' },
    globalEventHub: { mock: 'globalEventHub', emit: jest.fn() },
    session: { mock: 'sessions' },
    telemetry: { mock: 'telemetry' },
    ...injected,
  }));
};
const mockGetter = (initialiser: AnyFunction) => (<jest.Mock>getInitialiser).mockReturnValue(initialiser);
const mkFakeInitialiser = () => {
  const fakeContext = {
    on: (_ev: string, cb: AnyFunction) => cb(),
  };
  const fakeInitialiser = jest.fn(() => ({ ...fakeContext }));
  return fakeInitialiser;
};
const mkDummyClient = () => {
  const dummyClient = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
  dummyClient.stubResponse(
    {
      url: 'data/v2/applicant',
      method: 'get',
    },
    {
      data: {
        applicant: new Applicant().toJSON(),
      },
    },
  );
  return dummyClient;
};
describe('Component resolution', () => {
  beforeEach(() => {
    (<jest.Mock>getInitialiser).mockReset();
    (<jest.Mock>mkFrankieClient).mockResolvedValue(mkDummyClient());
  });

  test('Initialising module using method `component` without options will call corresponding module`s initialise function with `rootOptions` and the oneSdkInstance itself', async () => {
    const componentLoader = mkComponentLoader();
    const initialiser = mkFakeInitialiser();
    const get = mockGetter(initialiser);
    componentLoader('nameOfFakeModule');
    expect(get).toHaveBeenCalledWith('nameOfFakeModule');
    expect(initialiser).toHaveBeenCalledWith(
      expect.objectContaining({
        oneSdkInstance: expect.anything(),
        recipe: expect.anything(),
        frankieClient: expect.anything(),
        mode: expect.anything(),
        globalEventHub: expect.anything(),
        session: expect.anything(),
        telemetry: expect.anything(),
        moduleMeta: {
          instanceName: expect.anything(),
          moduleName: 'nameOfFakeModule',
        },
      }),
      {},
    );
  });
  test('Initialising module using method `component` with `moduleOptions` will call corresponding module`s initialise function with two parameters `sharedConfiguration` and `moduleOptions`', async () => {
    const componentLoader = mkComponentLoader();
    const initialiser = mkFakeInitialiser();
    const get = mockGetter(initialiser);
    componentLoader('nameOfFakeModule', {
      instanceName: 'theInstance',
      optionA: 'optionA',
    });

    expect(get).toHaveBeenCalledWith('nameOfFakeModule');
    expect(initialiser).toHaveBeenCalledWith(
      expect.objectContaining({
        oneSdkInstance: expect.anything(),
        recipe: expect.anything(),
        frankieClient: expect.anything(),
        mode: expect.anything(),
        globalEventHub: expect.anything(),
        session: expect.anything(),
        telemetry: expect.anything(),
        moduleMeta: {
          instanceName: 'theInstance',
          moduleName: 'nameOfFakeModule',
        },
      }),
      { optionA: 'optionA' },
    );
  });
  test('Initialising `nameOfFakeModule` using method `component` with the same `instanceName` = `theInstance` will always return the same instance', async () => {
    const componentLoader = mkComponentLoader();
    const initialiser = mkFakeInitialiser();
    mockGetter(initialiser);

    const moduleA = componentLoader('nameOfFakeModule', { instanceName: 'theInstance' });
    const moduleB = componentLoader('nameOfFakeModule', { instanceName: 'theInstance' });

    expect(moduleA).toBe(moduleB);
    expect(componentLoader.instances).toMatchObject({
      nameOfFakeModule: {
        theInstance: moduleA,
      },
    });
  });
  test('Initialising `nameOfFakeModule` using method `component` with different `instanceName` will always return different instances', async () => {
    const componentLoader = mkComponentLoader();
    const initialiser = mkFakeInitialiser();
    mockGetter(initialiser);

    const moduleInstance1 = componentLoader('nameOfFakeModule', { instanceName: 'A' });
    const moduleInstance2 = componentLoader('nameOfFakeModule', { instanceName: 'B' });

    expect(moduleInstance1).toMatchObject({ instanceName: 'A' });
    expect(moduleInstance2).toMatchObject({ instanceName: 'B' });
    expect(componentLoader.instances).toMatchObject({
      nameOfFakeModule: {
        A: moduleInstance1,
        B: moduleInstance2,
      },
    });
  });
  test.skip(`Without explicit 'instanceName', initialising 'nameOfFakeModule' using method 'component' will always return the same instance with 'instanceName' = 'nameOfFakeModule'`, async () => {
    const componentLoader = mkComponentLoader();
    const initialiser = mkFakeInitialiser();
    mockGetter(initialiser);

    const moduleA = componentLoader('nameOfFakeModule');
    const moduleB = componentLoader('nameOfFakeModule');

    expect(moduleA).toBe(moduleB);
    expect(componentLoader.instances).toMatchObject({
      nameOfFakeModule: {
        default: moduleA,
      },
    });
  });
});
