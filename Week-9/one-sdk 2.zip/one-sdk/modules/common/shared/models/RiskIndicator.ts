export interface IRiskFactor {
  factor: string;
  type: string;
  rating: number;
}

export interface IRiskResult {
  rating: number | null;
  score: string | null;
  policy: string | null;
}
export interface IRiskResultPayload {
  rating: number | null;
  score: string | null;
  policy: string | null;
}
export class RiskResult implements IRiskResultPayload {
  rating: number;
  score: string;
  "policy": string;
  constructor(d?: IRiskResult) {
    this.rating = d?.rating || 0;
    this.policy = d?.policy || "";
    this.score = d?.score || "";
  }

  toJSON(): IRiskResultPayload {
    return { rating: this.rating, policy: this.policy, score: this.score };
  }

  static fromJSON(payload: IRiskResultPayload): RiskResult {
    return new RiskResult({ ...payload });
  }
}

interface IRiskIndicatorConstructor {
  result: RiskResult;
  factors: IFactors;
  isManualOverride?: boolean;
  resultOverride: RiskResult;
}

interface IRiskIndicatorPayload {
  result: IRiskResult;
  factors: IFactors;
  isManualOverride: boolean;
  resultOverride: IRiskResult;
}

export interface IFactors {
  [x: string]: IRiskFactor;
}
export class RiskIndicator {
  result: RiskResult;
  factors: IFactors;
  resultOverride: RiskResult;
  isManualOverride: boolean;

  constructor(risk: IRiskIndicatorConstructor) {
    this.result = risk.result;
    this.isManualOverride = risk.isManualOverride || false;
    this.resultOverride = risk.resultOverride;
    this.factors = risk.factors || {};
  }

  toJSON(): IRiskIndicatorPayload {
    const result = this.result.toJSON();
    const resultOverride = this.resultOverride.toJSON();

    return { ...this, result, resultOverride };
  }

  static fromJSON(payload: IRiskIndicatorPayload): RiskIndicator {
    return new RiskIndicator({
      ...payload,
      result: RiskResult.fromJSON(payload.result),
      resultOverride: RiskResult.fromJSON(payload.resultOverride),
    });
  }
}