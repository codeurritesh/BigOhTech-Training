import jwtEncode from "jwt-encode";

export const jwtWithEntityId = jwtEncode(
  {
    data: {
      environment: "https://some-environment.com",
      sessionId: "some-session-id",
      entityId: "some-id",
      organisation: {
        customerId: "customer-id",
      },
    },
  },
  "secret"
);

export const jwtWithReference = jwtEncode(
  {
    data: {
      environment: "https://some-environment.com",
      sessionId: "some-session-id",
      reference: "some-reference",
      organisation: {
        customerId: "customer-id",
      },
    },
  },
  "secret"
);
