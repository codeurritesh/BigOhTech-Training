import { Dictionary } from "@types";
import { InjectedState } from "../oneSDKModules";

/**
 * Definition for a vendor wrapper initialise function. This is the function that is whats exported by all vendor wrappers.
 * It takes as type parameters:
 * 1) the module name which holds and initialises the vendor wrapper.
 * 2) the custom options that the vendor wrapper takes defined as a dictionary of values
 * 3) the context object that the vendor wrapper returns, which has no strict definition
 * 4) whether the vendor wrapper is sync or async, which means the contxt object is either wraped in a promise or not
 */
export type WrapperInitialiseFunction<
  Options extends Dictionary = never, // Vendor wrappers almost always have extra options
  VendorWrapperContext extends unknown | void = void, // But sometimes they don't return anything
  Async extends "sync" | "async" = "sync",
  InjectedParameters extends object = object
> = (
  b: InjectedState & InjectedParameters,
  o: Options
) => Async extends "async" ? Promise<VendorWrapperContext> : Awaited<VendorWrapperContext>;
/**
 * The type of the imported vendor wrapper module.
 * This allows do define the general shape of the vendor wrapper module and reference in the dynamic import function.
 */
export type VendorWrapperImport<Wrapper extends WrapperInitialiseFunction> = {
  initialise: Wrapper;
};
