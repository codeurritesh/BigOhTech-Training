import sanitizeHtml from "sanitize-html";
import type { DynamicUIComponent } from "./DynamicUIComponent";
import type { UIBlueprint } from "./UIBlueprint";
import type { Dictionary } from "./general";

export declare type Sanitiser = typeof sanitizeHtml;
export declare type SanitiserOptions = Parameters<Sanitiser>[1] & {
  extraAllowedTags?: string[];
};
export declare type ValidationMessageUnit = true | false | string;
export declare type ValidationMessageDictionary = true | Dictionary<string | false>;

export declare type HTMLString = string;
export declare type LeafNode = DynamicUIComponent | HTMLString;
export declare type UINodeType = UIBlueprint | LeafNode;
export declare interface HasValidation<Type> {
  isValid(): Type;
}
export declare type GetPhraseOptions = {
  isMandatory?: boolean;
  sanitiseHtml?: boolean | SanitiserOptions;
};
export declare type GetPhraseFunction = (key: string, options?: GetPhraseOptions) => string;
export declare type HasPhrases = { getPhrase: GetPhraseFunction };
export declare type BlueprintContext = HasPhrases & Dictionary;
export declare type BlueprintFactory<Context extends BlueprintContext> = (context: Context) => UIBlueprint;
