import type { Scan } from '@module/common/shared/models/Document';
import { Document } from '@module/common/shared/models/Document';
import { OCRStatus } from '@module/frankie-client/clients/OCRClient';
import { URL_PARAM } from '@module/frankie-client/DummyFrankieApiClient';
import * as startModule from '@module/ocr/actions/start';
import { completeOCR, inputRequired, mkEvaluateResults, mkProvideFile } from '@module/ocr/actions/start';
import { delayTest } from '@tests/testUtils/asyncUtils';

import { mkStartMethod } from './utils';

describe('start::completeOCR', () => {
  test('completeOCR, if documentId is present, call individual.updateDocument set isPreloaded to null and emit results with document', () => {
    const { dependencies, individual, eventHub, document$ } = mkStartMethod();
    const document = new Document();
    document.documentId = 'test-id';
    document$.getValue = () => document;
    completeOCR(dependencies);
    expect(individual.updateDocument).toHaveBeenCalledWith('test-id', document);
    expect(eventHub.emit).toHaveBeenCalledWith('results', {
      document,
      entityId: 'some-id',
    });
  });
});

describe('start::inputRequired', () => {
  test('emits { documentType: document.idType, side: expectedSide based on status$ }, status equals to status$', () => {
    const { dependencies, document$, status$, eventHub } = mkStartMethod();
    const document = new Document();
    document.documentId = 'test-id';
    document.idType = 'PASSPORT';
    document$.getValue = () => document;
    status$.setValue(OCRStatus.WAITING_BACK);

    inputRequired(OCRStatus.WAITING_BACK, dependencies);
    expect(eventHub.emit).toHaveBeenCalledWith(
      'input_required',
      { documentType: 'PASSPORT', side: 'back' },
      OCRStatus.WAITING_BACK,
      expect.anything(),
    );
  });
  test("emits { documentType: document.idType, side: expectedSide based on status$ }, status code could differ from status$, when it's a failure", () => {
    const { dependencies, document$, status$, eventHub } = mkStartMethod();
    const document = new Document();
    document.documentId = 'test-id';
    document.idType = 'PASSPORT';
    document$.getValue = () => document;
    status$.setValue(OCRStatus.WAITING_BACK);

    inputRequired(OCRStatus.FAILED_FILE_FORMAT, dependencies);
    expect(eventHub.emit).toHaveBeenCalledWith(
      'input_required',
      { documentType: 'PASSPORT', side: 'back' },
      OCRStatus.FAILED_FILE_FORMAT,
      expect.anything(),
    );
  });
  test('document with idType OTHER will be emitted with { documentType: null }', () => {
    const { dependencies, document$, _expectedSide$, eventHub } = mkStartMethod();
    const document = new Document();
    document.documentId = 'test-id';
    document.idType = 'OTHER';
    document$.getValue = () => document;
    _expectedSide$.getValue = () => 'front';

    inputRequired(OCRStatus.WAITING_BACK, dependencies);
    expect(eventHub.emit).toHaveBeenCalledWith(
      'input_required',
      { documentType: null, side: 'front' },
      OCRStatus.WAITING_BACK,
      expect.anything(),
    );
  });
});
describe('start::provide file', () => {
  test('providing a second file still works. List of files is retrieved correctly from reactive state', () => {
    const { dependencies, files$, frankieClient, document$, client } = mkStartMethod();
    files$.setValue([new File([''], 'filename1.jpeg', { type: 'image/jpeg' })]);

    const document = new Document();
    document.documentId = null;
    document$.getValue = () => document;
    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'put' },
      {
        status: 500,
        statusText: 'Oh no!',
      },
    );
    const provideFile = mkProvideFile(dependencies);
    const providedFile = new File([''], 'filename', { type: 'image/jpeg' });
    provideFile(providedFile);

    expect(files$.setValue).toHaveBeenCalledWith([providedFile]);
    expect(client.attachNewOCRDocument).toHaveBeenCalledWith(providedFile);
  });
  test('if document has NO documentId, providing a valid file will add it to the array of files$ and submit it to POST ocr with documentId and image-file', () => {
    const { dependencies, files$, frankieClient, document$, client } = mkStartMethod();
    const document = new Document();
    document.documentId = null;
    document$.getValue = () => document;
    files$.getValue = () => [];
    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'put' },
      {
        status: 500,
        statusText: 'Oh no!',
      },
    );
    const provideFile = mkProvideFile(dependencies);
    const providedFile = new File([''], 'filename', { type: 'image/jpeg' });
    provideFile(providedFile);

    expect(files$.setValue).toHaveBeenCalledWith([providedFile]);
    expect(client.attachNewOCRDocument).toHaveBeenCalledWith(providedFile);
  });
  test('if document has documentId, providing a valid file will add it to the array of files$ and submit it to PUT ocr with documentId and image-file', () => {
    const { dependencies, files$, frankieClient, document$, client } = mkStartMethod();
    const document = new Document();
    document.documentId = 'test-id';
    document$.getValue = () => document;
    files$.getValue = () => [];
    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'put' },
      {
        status: 500,
        statusText: 'Oh no!',
      },
    );
    const provideFile = mkProvideFile(dependencies);
    const providedFile = new File([''], 'filename', { type: 'image/jpeg' });
    provideFile(providedFile);

    expect(files$.setValue).toHaveBeenCalledWith([providedFile]);
    expect(client.updateOCRDocument).toHaveBeenCalledWith(providedFile, 'test-id');
  });
  test("providing a file with mime that's not existing will throw error with appropriate message", () => {
    const { dependencies, frankieClient, document$ } = mkStartMethod();
    const document = new Document();
    document.documentId = 'test-id';
    document$.getValue = () => document;

    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'put' },
      {
        status: 500,
        statusText: 'Oh no!',
      },
    );
    const provideFile = mkProvideFile(dependencies);
    let error = false;
    try {
      provideFile(new File([''], 'filename'));
    } catch (e) {
      error = e;
    }
    expect(error).toEqual(expect.any(Error));
    expect(error).toEqual(expect.objectContaining({ message: expect.stringContaining('missing mime type') }));
  });
  test("providing a file with mime that's not an image/ will throw error with appropriate message", () => {
    const { dependencies, frankieClient, document$ } = mkStartMethod();
    const document = new Document();
    document.documentId = 'test-id';
    document$.getValue = () => document;

    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'put' },
      {
        status: 500,
        statusText: 'Oh no!',
      },
    );
    const provideFile = mkProvideFile(dependencies);
    let error = false;
    try {
      provideFile(new File([''], 'filename', { type: 'application/pdf' }));
    } catch (e) {
      error = e;
    }
    expect(error).toEqual(expect.any(Error));
    expect(error).toEqual(expect.objectContaining({ message: expect.stringContaining('Invalid mime type') }));
  });
  test('if file submission fails, interrupt the entire flow', () => {
    const { dependencies, interruptOCR, frankieClient, document$ } = mkStartMethod();
    const document = new Document();
    document.documentId = 'test-id';
    document$.getValue = () => document;

    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'put' },
      {
        status: 500,
        statusText: 'Oh no!',
      },
    );
    const provideFile = mkProvideFile(dependencies);
    provideFile(new File([''], 'filename', { type: 'image/jpeg' }));
    return delayTest(() => {
      expect(interruptOCR).toHaveBeenCalledWith({
        message: 'Error submitting file',
        payload: expect.any(Object),
      });
    });
  });
});

describe('start:: evaluate results, successful statuses', () => {
  const mkTestDependencies = () => {
    const allDependencies = mkStartMethod();
    allDependencies.document$.getValue = () => new Document();
    const evaluateResults = mkEvaluateResults(allDependencies.dependencies);
    return { evaluateResults, ...allDependencies };
  };
  test('When getting new document object, set document$ value to returned ocrDocument', async () => {
    const returnedDocument = new Document();
    returnedDocument.documentId = 'test-id';
    returnedDocument.idNumber = '123321';
    const { document$: document$Front, evaluateResults: evaluateResultsFront } = mkTestDependencies();
    evaluateResultsFront({
      ocrDocument: returnedDocument,
      documentStatus: OCRStatus.WAITING_FRONT,
    });
    await delayTest(() => expect(document$Front.setValue).toHaveBeenCalledWith(returnedDocument));
    const { document$: document$Back, evaluateResults: evaluateResultsBack } = mkTestDependencies();
    evaluateResultsBack({
      ocrDocument: returnedDocument,
      documentStatus: OCRStatus.WAITING_BACK,
    });
    await delayTest(() => expect(document$Back.setValue).toHaveBeenCalledWith(returnedDocument));
    const { document$: document$Rerun, evaluateResults: evaluateResultsRerun, client } = mkTestDependencies();
    client.rerun = jest.fn().mockResolvedValue({
      documentStatus: OCRStatus.PROVIDER_OFFLINE,
    });
    evaluateResultsRerun({
      ocrDocument: returnedDocument,
      documentStatus: OCRStatus.WAITING_OCR_RUN,
    });
    await delayTest(() => expect(document$Rerun.setValue).toHaveBeenCalledWith(returnedDocument));
  });
  test('if returned status IS NOT WAITING_OCR and NOT FAILED, set failedStatus to null and status to returned status', async () => {
    const returnedDocument = new Document();
    returnedDocument.documentId = 'test-id';
    returnedDocument.idNumber = '123321';
    const {
      status$: status$Front,
      failedStatus$: failedStatus$Front,
      evaluateResults: evaluateResultsFront,
    } = mkTestDependencies();
    evaluateResultsFront({
      ocrDocument: returnedDocument,
      documentStatus: OCRStatus.WAITING_FRONT,
    });
    await delayTest(() => {
      expect(failedStatus$Front.setValue).toHaveBeenCalledWith(null);
      expect(status$Front.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    });

    const {
      status$: status$Back,
      failedStatus$: failedStatus$Back,
      evaluateResults: evaluateResultsBack,
    } = mkTestDependencies();
    evaluateResultsBack({
      ocrDocument: returnedDocument,
      documentStatus: OCRStatus.WAITING_BACK,
    });
    await delayTest(() => {
      expect(failedStatus$Back.setValue).toHaveBeenCalledWith(null);
      expect(status$Back.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_BACK);
    });
  });
  test('if returned status IS NOT WAITING_OCR and NOT FAILED, and scan side is found in returned ocrDocument.scans, emit event file_uploaded', async () => {
    const returnedDocument = new Document();
    returnedDocument.documentId = 'test-id';
    returnedDocument.idNumber = '123321';
    // WAITING_FRONT
    returnedDocument.scans = [
      { side: 'F', scanName: 'front.jpg', mimeType: 'image/jpg', scanId: 'scan-id-front' } as Scan,
    ];
    const {
      evaluateResults: evaluateResultsFront,
      eventHub: eventHubFront,
      status$: status$Front,
    } = mkTestDependencies();
    status$Front.setValue(OCRStatus.WAITING_FRONT);
    evaluateResultsFront({
      ocrDocument: returnedDocument,
      documentStatus: OCRStatus.COMPLETE,
    });
    await delayTest(() => {
      expect(eventHubFront.emit).toHaveBeenCalledWith('file_uploaded', {
        fileName: 'front.jpg',
        mimeType: 'image/jpg',
        scanId: 'scan-id-front',
        statusAfterUpload: OCRStatus.COMPLETE,
        statusBeforeUpload: OCRStatus.WAITING_FRONT,
      });
    });

    // WAITING_BACK
    returnedDocument.scans = [
      { side: 'B', scanName: 'back.jpg', mimeType: 'image/jpg', scanId: 'scan-id-back' } as Scan,
    ];
    const { evaluateResults: evaluateResultsBack, status$: status$Back, eventHub: eventHubBack } = mkTestDependencies();
    status$Back.setValue(OCRStatus.WAITING_BACK);
    evaluateResultsBack({
      ocrDocument: returnedDocument,
      documentStatus: OCRStatus.COMPLETE,
    });
    await delayTest(() => {
      expect(eventHubBack.emit).toHaveBeenCalledWith('file_uploaded', {
        fileName: 'back.jpg',
        mimeType: 'image/jpg',
        scanId: 'scan-id-back',
        statusAfterUpload: OCRStatus.COMPLETE,
        statusBeforeUpload: OCRStatus.WAITING_BACK,
      });
    });
  });
  test('if returned status IS NOT WAITING_OCR and NOT FAILED, and scan side is NOT found in returned ocrDocument.scans, emit event warning', async () => {
    const returnedDocument = new Document();
    returnedDocument.documentId = 'test-id';
    returnedDocument.idNumber = '123321';
    // WAITING_FRONT
    returnedDocument.scans = [
      { side: 'B', scanName: 'front.jpg', mimeType: 'image/jpg', scanId: 'scan-id-front' } as Scan,
    ];
    const {
      evaluateResults: evaluateResultsFront,
      eventHub: eventHubFront,
      status$: status$Front,
    } = mkTestDependencies();
    status$Front.setValue(OCRStatus.WAITING_FRONT);
    evaluateResultsFront({
      ocrDocument: returnedDocument,
      documentStatus: OCRStatus.COMPLETE,
    });
    await delayTest(() => {
      expect(eventHubFront.emit).toHaveBeenCalledWith('warning', {
        message: `File was uploaded successfully, but there was an issue identifying it within the document payload: document.scans[].side didn't match expected side front (F) `,
      });
    });

    // WAITING_BACK
    returnedDocument.scans = [
      { side: 'F', scanName: 'back.jpg', mimeType: 'image/jpg', scanId: 'scan-id-back' } as Scan,
    ];
    const { evaluateResults: evaluateResultsBack, status$: status$Back, eventHub: eventHubBack } = mkTestDependencies();
    status$Back.setValue(OCRStatus.WAITING_BACK);
    evaluateResultsBack({
      ocrDocument: returnedDocument,
      documentStatus: OCRStatus.COMPLETE,
    });
    await delayTest(() => {
      expect(eventHubBack.emit).toHaveBeenCalledWith('warning', {
        message: `File was uploaded successfully, but there was an issue identifying it within the document payload: document.scans[].side didn't match expected side back (B) `,
      });
    });
  });
  test('if returned status IS FAILED (-PROVIDER_OFFLINE), emit no events and set failedStatus to returned status', () => {
    const { evaluateResults, failedStatus$ } = mkTestDependencies();

    evaluateResults({
      ocrDocument: new Document(),
      documentStatus: OCRStatus.FAILED_FILE_FORMAT,
    });
    expect(failedStatus$.setValue).toHaveBeenCalledWith(OCRStatus.FAILED_FILE_FORMAT);
  });
  test('if returned status IS WAITING_OCR, emit no events and submit request to PUT without image-file (rerun). Failed requests causes an interruption to the flow', () => {
    const firstReturnedDocument = new Document();
    firstReturnedDocument.documentId = 'test-id';
    const { evaluateResults, failedStatus$, client, interruptOCR, status$, eventHub } = mkTestDependencies();
    const spy = jest.spyOn(client, 'rerun');
    spy.mockRejectedValue(new Error('Some request error'));
    evaluateResults({
      ocrDocument: firstReturnedDocument,
      documentStatus: OCRStatus.WAITING_OCR_RUN,
    });
    expect(spy).toHaveBeenCalledWith(firstReturnedDocument.documentId);
    return delayTest(() => {
      expect(interruptOCR).toHaveBeenCalledWith({
        message: `Attempting to resolve the status ${OCRStatus.WAITING_OCR_RUN} resulted in an error`,
        payload: expect.objectContaining({ message: 'Some request error' }),
      });
      expect(failedStatus$.setValue).not.toHaveBeenCalled();
      expect(status$.setValue).not.toHaveBeenCalled();
      expect(eventHub.emit).not.toHaveBeenCalled();
    });
  });
  test('if returned status IS WAITING_OCR, emit no events and submit request to PUT without image-file (rerun). If requests returns another WAITING_OCR it causes an interruption to the flow', () => {
    const firstReturnedDocument = new Document();
    firstReturnedDocument.documentId = 'test-id';
    const { evaluateResults, failedStatus$, client, interruptOCR, status$, eventHub } = mkTestDependencies();
    const spy = jest.spyOn(client, 'rerun');
    spy.mockResolvedValue({
      ocrDocument: firstReturnedDocument,
      documentStatus: OCRStatus.WAITING_OCR_RUN,
    });
    evaluateResults({
      ocrDocument: firstReturnedDocument,
      documentStatus: OCRStatus.WAITING_OCR_RUN,
    });
    expect(spy).toHaveBeenCalledWith(firstReturnedDocument.documentId);
    return delayTest(() => {
      expect(interruptOCR).toHaveBeenCalledWith({
        message: `Attempting to resolve the status ${OCRStatus.WAITING_OCR_RUN} resulted in an error`,
        payload: expect.objectContaining({
          message: `Two attempts to get OCR results failed with an unresolved "${OCRStatus.WAITING_OCR_RUN}". This is a system failure.`,
        }),
      });
      expect(failedStatus$.setValue).not.toHaveBeenCalled();
      expect(status$.setValue).not.toHaveBeenCalled();
      expect(eventHub.emit).not.toHaveBeenCalled();
    });
  });
  test('if returned status IS PROVIDER_OFFLINE, interrupt ocr flow', () => {
    const firstReturnedDocument = new Document();
    firstReturnedDocument.documentId = 'test-id';
    const { evaluateResults, interruptOCR } = mkTestDependencies();
    evaluateResults({
      ocrDocument: firstReturnedDocument,
      documentStatus: OCRStatus.PROVIDER_OFFLINE,
    });
    expect(interruptOCR).toHaveBeenCalledWith({
      message: `Provider is offline. Either switch providers and restart or skip OCR temporarily. Status ${OCRStatus.PROVIDER_OFFLINE}`,
      payload: null,
    });
  });
});

describe('start:: Generates two observables that will run cycles until a) status is COMPLETE OR b) a forced interruption happens', () => {
  let resetCurrentStatusSpy: jest.SpyInstance;
  let inputRequiredSpy: jest.SpyInstance;
  let completeOCRSpy: jest.SpyInstance;
  beforeAll(() => {
    resetCurrentStatusSpy = jest.spyOn(startModule, 'resetCurrentStatus');
    resetCurrentStatusSpy.mockImplementation(() => null);
    inputRequiredSpy = jest.spyOn(startModule, 'inputRequired');
    inputRequiredSpy.mockImplementation(() => null);
    completeOCRSpy = jest.spyOn(startModule, 'inputRequired');
    completeOCRSpy.mockImplementation(() => null);
  });
  beforeEach(() => {
    resetCurrentStatusSpy.mockReset();
    inputRequiredSpy.mockReset();
    completeOCRSpy.mockReset();
  });
  afterAll(() => {
    resetCurrentStatusSpy.mockRestore();
    inputRequiredSpy.mockRestore();
    completeOCRSpy.mockRestore();
  });
  test("Calling interruptOCR will trigger event 'error'", async () => {
    const { start, eventHub, status$, document$ } = mkStartMethod();
    status$.setValue(OCRStatus.WAITING_FRONT);
    document$.setValue(new Document());

    const { interruptOCR } = await start();
    interruptOCR();
    expect(eventHub.emit).toHaveBeenCalledWith(
      'error',
      expect.objectContaining({
        message: expect.stringContaining('While executing OCR callbacks: OCR Flow interrupted externally'),
        payload: {
          document: new Document(),
          status: OCRStatus.WAITING_FRONT,
          failedStatus: null,
        },
      }),
    );
  });
  test('Error callback will reset state to null', async () => {
    const { start, status$, failedStatus$, document$, files$, isPreloaded$ } = mkStartMethod();
    await start();
    status$.observable.error(new Error());

    expect(status$.setValue).toHaveBeenCalledWith(null);
    expect(failedStatus$.setValue).toHaveBeenCalledWith(null);
    expect(document$.setValue).toHaveBeenCalledWith(null);
    expect(files$.setValue).toHaveBeenCalledWith([]);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(null);
  });
  test('Updating status to WAITING_FRONT or WAITING_BACK triggers input_required', async () => {
    const { start, status$ } = mkStartMethod();
    status$.setValue(OCRStatus.WAITING_FRONT);
    await start();
    expect(inputRequiredSpy).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT, expect.any(Object));
    status$.setValue(OCRStatus.WAITING_BACK);
    expect(inputRequiredSpy).toHaveBeenCalledWith(OCRStatus.WAITING_BACK, expect.any(Object));
  });
  test('Updating status to COMPLETE triggers completeOCR', async () => {
    const { start, status$ } = mkStartMethod();
    status$.setValue(OCRStatus.WAITING_FRONT);
    await start();
    status$.setValue(OCRStatus.COMPLETE);
    expect(completeOCRSpy).toHaveBeenCalled();
  });
  test('Updating failureStatus to any value triggers input_required with that value', async () => {
    const { start, status$, failedStatus$ } = mkStartMethod();
    status$.setValue(OCRStatus.WAITING_FRONT);
    await start();
    failedStatus$.setValue(OCRStatus.DOCUMENTS_INVALID);
    expect(inputRequiredSpy).toHaveBeenCalledWith(OCRStatus.DOCUMENTS_INVALID, expect.any(Object));
  });
});
