import type { BiometricsModule } from '@module/biometrics';
import type { OneSDKError } from '@module/common';
import type { IDVStatus } from '@module/frankie-client/clients/IDVClient';
import type { OCRModule } from '@module/ocr';
import type { Override } from '@types';

export type Events = Override<
  OCRModule['moduleEvents'] & BiometricsModule['moduleEvents'],
  {
    session_data_failed_loading: [];
    detection_failed: [{ message: string; payload?: Record<string, unknown> }];
    input_required: [info: { entityId: string }, status: IDVStatus];
    error: [OneSDKError<{ errorStatus: IDVStatus }>];
  }
>;
