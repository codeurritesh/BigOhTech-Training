import { IDVClient, IDVStatus } from "@module/frankie-client/clients/IDVClient";
import { mockIDVFlow } from "@module/frankie-client/mocks/idvAndBiometrics/idvSubmission";

import { SessionContext } from "@module/session/SessionContext";
import { mockFrankieClient } from "@tests/mocks/FrankieClient";
import { jwtWithEntityId, jwtWithReference } from "@tests/testUtils/tokens";
describe("Dummy Mode: idv flow", () => {
  test("Load token with entityId", async () => {
    const { frankieClient } = mockFrankieClient();
    frankieClient.session = new SessionContext(jwtWithEntityId);

    mockIDVFlow(frankieClient, {
      idvRequests: {
        result: IDVStatus.COMPLETE
      }
    });
    const idvClient = new IDVClient(frankieClient);
    const response = await idvClient.getToken();

    expect(frankieClient.post).toHaveBeenCalledWith(
      expect.stringMatching(`data/v2/idvCheck/token`),
      {
        applicant: {
          customerReference: null,
          entityId: expect.any(String),
        },
      },
      {
        params: {},
      }
    );
    expect(response).toEqual({
      token: "session-token-from-provider",
      vendorParameters: {
        tokenURL: expect.any(String),
      },
      entityId: expect.any(String),
    });
  });
  test("Load token with reference", async () => {
    const { frankieClient } = mockFrankieClient();
    frankieClient.session = new SessionContext(jwtWithReference);

    mockIDVFlow(frankieClient, {
      idvRequests: {
        result: IDVStatus.COMPLETE
      }
    });
    const idvClient = new IDVClient(frankieClient);
    const response = await idvClient.getToken();

    expect(frankieClient.post).toHaveBeenCalledWith(
      `data/v2/idvCheck/token`,
      {
        applicant: expect.objectContaining({
          customerReference: expect.any(String),
          entityId: null,
        }),
      },
      {
        params: {},
      }
    );
    expect(response).toEqual({
      token: "session-token-from-provider",
      vendorParameters: {
        tokenURL: expect.any(String),
      },
      entityId: expect.any(String),
    });
  });
  test("Test different result statuses", async () => {
    const { frankieClient } = mockFrankieClient();
    frankieClient.session = new SessionContext(jwtWithReference);

    mockIDVFlow(frankieClient, {
      idvRequests: {
        result: IDVStatus.PROVIDER_OFFLINE,
        failGeneratingSession: false,
      },
    });
    const idvClient = new IDVClient(frankieClient);
    const response = await idvClient.initProcess({ isSynchronous: true, vendorParameters: { checkId: "anycheckid" } });

    expect(response).toEqual({
      checkStatus: IDVStatus.PROVIDER_OFFLINE,
      ocrDocument: null,
    });
  });
});
