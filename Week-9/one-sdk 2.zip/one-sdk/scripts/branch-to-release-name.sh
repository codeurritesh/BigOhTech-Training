#!/bin/bash
# requires variable BITBUCKET_BRANCH and BITBUCKET_DEPLOYMENT_ENVIRONMENT
releaseName=""

case $BITBUCKET_BRANCH in
    hotfix/*)
        case $BITBUCKET_DEPLOYMENT_ENVIRONMENT in
            "dev-cdn")
                releaseName="$(echo "$BITBUCKET_BRANCH" | cut -d'/' -f2)"
                ;;
            "prod-cdn")
                releaseName=v$(npm run curr-version --silent)
                ;;
        esac
        ;;
    feature/*|bugfix/*|refactor/*)
        releaseName="$(echo "$BITBUCKET_BRANCH" | cut -d'/' -f2)"
        ;;
    uat/*)
        # prepends uat_ to the branch name
        releaseName="uat_$(echo "$BITBUCKET_BRANCH" | cut -d'/' -f2)"
        ;;
    develop)
        releaseName="RC"
        ;;
    main)
        releaseName="v$(npm run curr-version --silent)"
        ;;
esac

echo "$releaseName"
