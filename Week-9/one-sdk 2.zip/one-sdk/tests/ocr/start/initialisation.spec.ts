import type { EventHub } from '@module/common';
import { ReactiveStore } from '@module/common';
import { defineModule } from '@module/common/modules/defineModule';
import type { OneSdkContext } from '@module/index';
import OcrInitialise from '@module/ocr';
import type { RecipeParsed } from '@module/sdk/types';
import { SdkModes } from '@module/sdk/types';
import type { SessionContext } from '@module/session/SessionContext';
import { mockFrankieClient } from '@tests/mocks/FrankieClient';
import { optionalParameters } from '@tests/testUtils/functionUtilities';

// eslint-disable-next-line no-console
console.log(defineModule);
const OcrModule = optionalParameters(OcrInitialise);

jest.mock('@module/common/modules/ReactiveStore', () => {
  return {
    ReactiveStore: require('../../mocks/ReactiveStore').mockReactiveStoreConstructor(),
  };
});
describe('OCR initialisation', () => {
  test('Initialised module initially contains empty document, AWAITING_DOCUMENT_UPLOAD_FRONT status and empty list of files', () => {
    const { frankieClient } = mockFrankieClient({ sessionType: 'entityId' });
    OcrModule({
      moduleMeta: { moduleName: 'ocr', instanceName: 'ocr' },
      mode: { is: jest.fn(), modeName: SdkModes.DEV },
      session: {} as SessionContext,
      telemetry: false,
      globalEventHub: {} as EventHub,
      recipe: <RecipeParsed>{ ocr: { provider: { name: 'onfido' } } },
      oneSdkInstance: <OneSdkContext>{ individual: () => ({}) },
      frankieClient,
    }, {});
    expect(ReactiveStore).toHaveBeenCalledWith(
      expect.objectContaining({
        document: null,
        status: null,
        files: [],
      }),
    );
  });
});
