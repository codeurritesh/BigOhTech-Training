// Generated using webpack-cli https://github.com/webpack/webpack-cli
import { CleanWebpackPlugin } from 'clean-webpack-plugin';
import CopyWebpackPlugin from 'copy-webpack-plugin';
import DotEnv from 'dotenv-webpack';
import merge from 'lodash.merge';
import MiniCssExtractPlugin from 'mini-css-extract-plugin';
import { dirname, resolve } from 'path';
import TsConfigPathsPlugin from 'tsconfig-paths-webpack-plugin';
import { fileURLToPath } from 'url';
import { BundleAnalyzerPlugin } from 'webpack-bundle-analyzer';

const _filename = fileURLToPath(import.meta.url);
const _dirname = dirname(_filename);

const isProduction = process.env.NODE_ENV == 'production';

const EMIT_BUNDLE_ANALYTICS = process.env.EMIT_BUNDLE_ANALYTICS;

const config = {
  entry: './modules/index.ts',
  target: 'web',
  devtool: 'source-map',
  stats: {
    errorDetails: true,
    children: true,
  },
  plugins: [
    // Add your plugins here
    // Learn more about plugins from https://webpack.js.org/configuration/plugins/
    new CopyWebpackPlugin({
      patterns: [{ from: 'static', noErrorOnMissing: true }],
    }),
    new DotEnv(),
    new CleanWebpackPlugin(),
  ].filter(Boolean),
  module: {
    rules: [
      {
        test: /\.json$/,
        type: 'json',
      },
      {
        test: /\.(ts|tsx)$/i,
        loader: 'ts-loader',
        exclude: ['/node_modules/'],
        options: { configFile: resolve(_dirname, './tsconfig.modules.json') },
      },
      {
        test: /\.css$/i,
        use: ['style-loader', 'css-loader'],
      },
      {
        test: /\.s[ac]ss$/i,
        use: ['style-loader', 'css-loader', 'sass-loader'],
      },
      {
        test: /\.(eot|svg|ttf|woff|woff2)$/i,
        use: ['file-loader'],
      },
      {
        test: /\.(png|jpe?g|gif)$/i,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[sha512:hash:base64:7].[ext]',
            },
          },
        ],
      },
      {
        test: /\.(js)$/i,
        include: [resolve(_dirname, 'modules'), resolve(_dirname, 'static')],
      },

      // Add your rules for custom modules here
      // Learn more about loaders from https://webpack.js.org/loaders/
    ],
  },
  resolve: {
    extensions: ['.tsx', '.ts', '.js'],
    plugins: [
      new TsConfigPathsPlugin({
        logLevel: 'info',
        configFile: resolve(_dirname, './tsconfig.modules.json'),
        mainFields: ['browser', 'main'],
      }),
    ],
  },
  optimization: {
    minimize: isProduction,
    splitChunks: {
      cacheGroups: {
        vendors: {
          priority: -10,
          test: /[\\/]node_modules[\\/]/,
        },
      },
      chunks: 'async',
      minChunks: 1,
      minSize: 30000,
      name: false,
    },
  },
  watchOptions: {
    ignored: [resolve(_dirname, './stats'), resolve(_dirname, './apps'), resolve(_dirname, './dist')],
  },
};

export default () => {
  if (isProduction) {
    config.mode = 'production';
    config.plugins.push(new MiniCssExtractPlugin());
  } else {
    config.mode = 'development';
  }
  if (EMIT_BUNDLE_ANALYTICS)
    console.log(
      process.env.EMIT_BUNDLE_ANALYTICS === 'open'
        ? 'Emitting and opening bundle analytics'
        : 'Emitting bundle analytics',
    );
  config.plugins.push(
    new BundleAnalyzerPlugin({
      openAnalyzer: process.env.EMIT_BUNDLE_ANALYTICS === 'open',
      analyzerMode: 'static',
      reportFilename: (() => {
        const date = new Date();
        const yyyy = date.getFullYear();
        const mm = String(date.getMonth()).padStart(2, '0');
        const dd = String(date.getDate()).padStart(2, '0');
        const timestamp = `${yyyy}${mm}${dd}`;
        return resolve(_dirname, './stats', `report-${timestamp}.html`);
      })(),
    }),
  );
  const umdConfig = merge({}, config);
  umdConfig.output = {
    library: {
      name: 'OneSdk',
      type: 'umd',
    },
    libraryExport: 'default',
    chunkFilename: '[name].js',
    filename: 'oneSdk.umd.js',
    path: resolve(_dirname, 'dist/umd'),
  };

  return [umdConfig];
};
