import { jest } from '@jest/globals';
import { BehaviorSubject } from 'rxjs';

import type { Accessors, ReactiveStore, ReadonlyAccessors } from '@module/common';
import type { Clonable } from '@module/common/modules/objectUtils';
import type { Dictionary, KeyOf } from '@types';

type ReturnType<Readonly, T> = Readonly extends true ? ReadonlyAccessors<T> : Accessors<T>;
export function mockAcessorsDictionary<T extends Dictionary>(state = {} as T) {
  return Object.keys(state).reduce((acc, key) => {
    acc[key] = mockAccessors(state, false, key);
    return acc;
  }, {}) as Record<keyof T, Accessors>;
}
export function mockAccessors<T, Readonly extends boolean = false>(
  state: { [field: string]: T },
  readOnly = false as Readonly,
  fieldName: string = Object.keys(state)[0],
): ReturnType<Readonly, T> {
  const observable = new BehaviorSubject<T>(state?.[fieldName] ?? null);
  const mockGetValue = jest.fn().mockImplementation(() => (state?.[fieldName] ?? null) as T);
  jest.spyOn(observable, 'subscribe');
  jest.spyOn(observable, 'pipe');
  jest.spyOn(observable, 'next');
  const mockSetValue = jest.fn().mockImplementation((value: T) => {
    state[fieldName] = value;
    observable.next(value);
  }) as (v: T) => void;

  const readonlyAccessors: ReadonlyAccessors = {
    getValue: mockGetValue,
    observable,
    property: fieldName,
  };

  if (readOnly) return readonlyAccessors as ReturnType<Readonly, T>;
  else {
    return {
      ...readonlyAccessors,
      setValue: mockSetValue,
      toReadonly: () => readonlyAccessors,
    } as ReturnType<Readonly, T>;
  }
}
export const mockReactiveStoreConstructor = (): typeof ReactiveStore => {
  type InternalState = { document: Accessors<Document>; status: Accessors<string>; files: Accessors<File[]> };

  const ReactiveStoreConstructor = jest.fn().mockImplementation((state: Dictionary) => {
    const accessorsDictionary = {} as InternalState;
    const mockNextMethod = jest.fn();
    // instance methods here
    return {
      next: mockNextMethod.mockImplementation((newState) => Object.assign(state, newState)),
      getRootAccessors: (fieldName: string) => {
        // Only initialise mock accessors once, so we may retrieve existing ones for tests
        if (accessorsDictionary[fieldName]) return accessorsDictionary[fieldName];
        return mockAccessors(state);
      },
    };
  });
  Object.defineProperties(ReactiveStoreConstructor, {
    // static methods here
    mkPropertyAccessors: {
      value: jest
        .fn()
        .mockImplementation(
          <T extends Clonable & { [k in string]: unknown }>(origin: Accessors<T>, propertyName: KeyOf<T>) => {
            const originState = { [propertyName]: origin.getValue()[propertyName] };
            return mockAccessors(originState);
          },
        ),
    },
    mkComputedAccessors: {
      value: jest.fn().mockImplementation((v) => v),
    },
  });
  return ReactiveStoreConstructor as unknown as typeof ReactiveStore;
};
