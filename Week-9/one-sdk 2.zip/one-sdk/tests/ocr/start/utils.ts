import { Document } from '@module/common/shared/models/Document';
import type { DummyFrankieApiClient } from '@module/frankie-client';
import { OCRClient, OCRStatus } from '@module/frankie-client/clients/OCRClient';
import { URL_PARAM } from '@module/frankie-client/DummyFrankieApiClient';
import type { Accessors } from '@module/index';
import { createOCRInternalState } from '@module/ocr';
import type { Events } from '@module/ocr';
import { mkStartMethod as originalMkStartMethod } from '@module/ocr/actions/start';
import type { DependenciesWithInterrupt } from '@module/ocr/actions/start';
import type { GlobalEvents } from '@module/sdk/types';
import { mockEventHub } from '@tests/mocks/EventHub';
import { mockFrankieClient } from '@tests/mocks/FrankieClient';
import { mockAccessors } from '@tests/mocks/ReactiveStore';
import { delayTest, waitFor } from '@tests/testUtils/asyncUtils';
import type { Dictionary } from '@types';

type StartDependencies = DependenciesWithInterrupt;
type DependencyValueType<Key extends keyof StartDependencies> = StartDependencies[Key] extends Accessors<infer Type>
  ? Type
  : StartDependencies[Key];
type Options = {
  [K in keyof StartDependencies]?: DependencyValueType<K>;
};
export const mkStartMethod = (deps: Options = {}) => {
  const { frankieClient } = mockFrankieClient({ sessionType: 'entityId' });
  const client = new OCRClient(frankieClient);
  const individual = {
    addDocument: jest.fn(),
    updateDocument: jest.fn(),
    access: jest.fn(() => mockAccessors({ documents: [] })),
  };

  const interruptOCR = jest.fn();
  const { _expectedSide$, document$, failedStatus$, files$, isPreloaded$, status$ } = createOCRInternalState({
    document: deps.document$ ?? new Document(),
    status: deps.status$ ?? OCRStatus.WAITING_FRONT,
    files: deps.files$ ?? <File[]>[],
    isPreloaded: <boolean>null,
    failedStatus: deps.failedStatus$ ?? null,
  });

  [status$, document$, files$, isPreloaded$, failedStatus$].forEach((accessors) => {
    jest.spyOn(accessors, 'setValue');
    jest.spyOn(accessors, 'getValue');
  });
  jest.spyOn(_expectedSide$, 'getValue');
  jest.spyOn(client, 'rerun');
  jest.spyOn(client, 'updateOCRDocument');
  jest.spyOn(client, 'attachNewOCRDocument');

  const dependencies = {
    _expectedSide$,
    client,
    document$,
    files$,
    status$,
    eventHub: mockEventHub<Events>(),
    individual: individual,
    isPreloaded$,
    failedStatus$,
    interruptOCR,
    globalEventHub: mockEventHub<GlobalEvents>(),
    maxDocumentCount: deps.maxDocumentCount,
  };
  const castDependencies = dependencies as unknown as StartDependencies;
  const start = originalMkStartMethod(castDependencies);
  return { start, ...dependencies, frankieClient, dependencies: castDependencies };
};

// eslint-disable-next-line @typescript-eslint/ban-types
type StubOptions = Omit<Exclude<Parameters<DummyFrankieApiClient['stubResponse']>[1], Function>, 'data'> & {
  data: {
    ocrDocument?: Partial<Document>;
    documentStatus: OCRStatus;
  };
};
type MkStartMethodOptions = ReturnType<typeof mkStartMethod>;
type TestCallback = (
  options: MkStartMethodOptions & {
    preloadedDocument: Document;
    requestSpy: jest.Mock;
    providedFile: File;
    inputRequiredSpy: jest.Mock;
    interruptOCR: jest.Mock;
  },
  passthrough,
) => Promise<void> | void;

export function testStartMethod(
  options: Partial<{
    preloadedDocument: Partial<Document>;
    stubPutResponse: StubOptions;
    stubPostResponse: StubOptions;
    startDependencies: Parameters<typeof mkStartMethod>[0];
    waitFor?: [string, TestCallback];
    callback?: TestCallback;
    delayTimes?: [number, TestCallback];
  }>,
  passthroughParameters?: Dictionary,
): Promise<void> {
  // testing verified.manual = true
  const { stubPostResponse, stubPutResponse, preloadedDocument = null } = options ?? {};

  const deps = mkStartMethod(options.startDependencies ?? {});
  const { start, individual, eventHub, frankieClient, interruptOCR } = deps;
  // enforce document id is included
  const documentWithId = () =>
    Object.assign(new Document(), preloadedDocument, { documentId: 'some-document-id' }) as Document;
  const documents = preloadedDocument ? [documentWithId()] : [];
  individual.access.mockReturnValue(
    mockAccessors<Document[]>({
      documents,
    }),
  );
  const requestSpy = jest.fn();
  const inputRequiredSpy = jest.fn();

  const mkFakeResponsePayload = (stubResponse?: StubOptions): StubOptions => {
    const { data } = stubResponse ?? {};

    const ocrDocument = Object.assign(new Document().toJSON(), data.ocrDocument);
    const documentStatus = data.documentStatus ?? OCRStatus.COMPLETE;

    return Object.assign(stubResponse, {
      data: {
        ocrDocument,
        documentStatus,
      },
    });
  };
  frankieClient.stubResponse({ url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'post' }, (config) => {
    requestSpy(config);
    return mkFakeResponsePayload(stubPostResponse);
  });
  frankieClient.stubResponse({ url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'put' }, (config) => {
    requestSpy(config);
    return mkFakeResponsePayload(stubPutResponse);
  });
  const providedFile = new File([''], 'filename', { type: 'image/jpeg' });

  eventHub.on('input_required', (_i, _s, provideFile) => {
    inputRequiredSpy(_i, _s, providedFile);
    provideFile(providedFile);
  });

  passthroughParameters = passthroughParameters ?? {};
  return new Promise((resolve, reject) => {
    const dependenciesParameter = {
      ...deps,
      preloadedDocument: documents[0],
      requestSpy,
      providedFile,
      inputRequiredSpy,
      interruptOCR,
    };

    if (options.waitFor) {
      // if waiting for an event, register the event first, then call "start"
      waitFor(
        (...eventPayload) => {
          const eventName = options.waitFor[0];
          const callback = options.waitFor[1];
          passthroughParameters = {
            [eventName]: eventPayload,
          };
          callback(dependenciesParameter, passthroughParameters);
        },
        eventHub,
        options.waitFor[0],
      )
        .then(resolve)
        .catch(reject);
      start();
    } else if (options.delayTimes) {
      const times = options.delayTimes[0];
      const callback = options.delayTimes[1];
      start();
      delayTest(() => callback(dependenciesParameter, passthroughParameters), times)
        .then(resolve)
        .catch(reject);
    } else {
      start();
      Promise.resolve(options.callback(dependenciesParameter, passthroughParameters)).then(resolve).catch(reject);
    }
  });
}
