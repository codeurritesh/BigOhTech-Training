import { SimplifiedIDVFlow } from "./idvFlow";
import { SimplifiedPreloadedIndividual } from "./preloadedIndividual";
import { SimplifiedOCRFlow } from "./ocrFlow";

// prettier-ignore
export type SimplifiedMockOptions = Partial<
  SimplifiedPreloadedIndividual & 
  SimplifiedOCRFlow & 
  SimplifiedIDVFlow
>;
