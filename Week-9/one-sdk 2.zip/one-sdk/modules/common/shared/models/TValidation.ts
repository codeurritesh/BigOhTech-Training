export type TValidation = boolean | null;
export type TValidationFieldIssues = string[];
export type TValidationResult = { [field: string]: TValidationFieldIssues };
export type TFieldIssuesTuple = [string, TValidationFieldIssues];