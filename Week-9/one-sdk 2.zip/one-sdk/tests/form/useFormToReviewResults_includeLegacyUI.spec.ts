import { OneSDKError } from '@module/common';
import { Document } from '@module/common/shared/models/Document';
import { delayTest } from '@tests/testUtils/asyncUtils';

import { execute } from './helpers';

describe('useFormToReviewResults: shouldAttachForm is true', () => {
  test(`'loading' is emitted in the right order`, () => {
    const { findEventEmissions } = execute({
      shouldAttachForm: true,
    });

    return delayTest(() => {
      expect(findEventEmissions('loading')).toEqual([
        ['loading', false, { message: 'Form loaded for user review' }],
        ['loading', true, { message: 'Updating individual state' }],
        [
          'loading',
          false,
          { message: 'Vendor capture was completed including user review' },
        ],
      ]);
    });
  });
  test('individual.search is called twice', () => {
    const { oneSdkInstance } = execute({
      shouldAttachForm: true,
    });
    return delayTest(() => {
      expect(oneSdkInstance.individual().search).toHaveBeenCalledTimes(2);
    });
  });
  test(`'detection_complete' is emitted once`, () => {
    const { localEventHub, findEventEmissions } = execute({
      shouldAttachForm: true,
    });

    return delayTest(() => {
      expect(localEventHub.emit).toHaveBeenCalledWith('detection_complete');
      expect(findEventEmissions('detection_complete')).toHaveLength(1);
    });
  });
  test(`'results' is emitted with updated document object`, () => {
    const originalDocument = new Document();
    originalDocument.idNumber = '000';

    const reviewedDocument = new Document();
    reviewedDocument.idNumber = '111';

    const { localEventHub, results } = execute({
      shouldAttachForm: true,
      results: {
        genericContent: 'generic',
        document: originalDocument,
        entityId: '333',
      },
      reviewedDocument: reviewedDocument,
    });

    return delayTest(() => {
      expect(localEventHub.emit).toHaveBeenCalledWith('results', {
        ...results,
        document: reviewedDocument,
      });
    }, 10);
  });
  test(`when initial individual.search fails, 'detection_failed' and 'loading' are emited once`, () => {
    const error = new Error('test');
    const { localEventHub, findEventEmissions } = execute({
      shouldAttachForm: true,
      oneSdkInstance: (oneSdkInstance) => {
        const searchMock = oneSdkInstance.individual().search as jest.Mock;
        searchMock.mockRejectedValueOnce(error);
        return oneSdkInstance;
      },
    });

    return delayTest(() => {
      expect(localEventHub.emit).toHaveBeenCalledWith(
        'detection_failed',
        new OneSDKError('Failed during data review in form', error),
      );
      expect(localEventHub.emit).toHaveBeenCalledWith('loading', false, {
        message: 'Failed during data review in form',
      });
      expect(findEventEmissions('loading')).toHaveLength(1);
      expect(findEventEmissions('detection_failed')).toHaveLength(1);
    }, 2);
  });
  test(`when second individual.search fails, "detection_failed" is emitted once and "loading" is emitted in the same order`, () => {
    const error = new Error('test');
    const { localEventHub, findEventEmissions } = execute({
      shouldAttachForm: true,
      oneSdkInstance: (oneSdkInstance) => {
        const searchMock = oneSdkInstance.individual().search as jest.Mock;
        let callCount = 0;
        searchMock.mockImplementation(() => {
          callCount++;
          if (callCount === 2) {
            return Promise.reject(error);
          }
          return Promise.resolve();
        });
        return oneSdkInstance;
      },
    });

    return delayTest(() => {
      expect(localEventHub.emit).toHaveBeenCalledWith(
        'detection_failed',
        new OneSDKError('Failed during data review in form', error),
      );
      expect(findEventEmissions('loading')).toEqual([
        ['loading', false, { message: 'Form loaded for user review' }],
        ['loading', true, { message: 'Updating individual state' }],
        ['loading', false, { message: 'Failed during data review in form' }],
      ]);
      expect(findEventEmissions('detection_failed')).toHaveLength(1);
    }, 2);
  });
});

jest.mock('@module/common/vendors/form/promisifyForm', () => {
  return {
    promisifyForm: jest.fn(),
  };
});
