import { OneSDKError } from '@module/common';
import { delayTest, waitFor } from '@tests/testUtils/asyncUtils';

import { execute } from './helpers';

describe('useFormToReviewResults: shouldAttachForm is false', () => {
  test('simply reemit the same results object', () => {
    const { localEventHub, results } = execute();

    return waitFor(
      () => {
        expect(localEventHub.emit).toHaveBeenCalledWith('loading', false, {
          message: 'Vendor capture was completed including user review',
        });
        expect(localEventHub.emit).toHaveBeenCalledWith('results', results);
      },
      localEventHub,
      'results',
    );
  });
  test('individual.search is called once', () => {
    const { oneSdkInstance } = execute();

    return delayTest(() => {
      expect(oneSdkInstance.individual().search).toHaveBeenCalledTimes(1);
    });
  });
  test(`'loading' is emited once`, () => {
    const { localEventHub } = execute();

    return waitFor(
      () => {
        expect(localEventHub.emit).toHaveBeenCalledWith('loading', false, {
          message: 'Vendor capture was completed including user review',
        });
        expect(localEventHub.emit).toHaveBeenCalledTimes(1);
      },
      localEventHub,
      'loading',
    );
  });
  test(`when individual.search fails, 'detection_failed' and 'loading' are emited once`, () => {
    const error = new Error('test');
    const { localEventHub, findEventEmissions } = execute({
      oneSdkInstance: (oneSdkInstance) => {
        const searchMock = oneSdkInstance.individual().search as jest.Mock;
        searchMock.mockRejectedValueOnce(error);
        return oneSdkInstance;
      },
    });

    return delayTest(() => {
      expect(localEventHub.emit).toHaveBeenCalledWith(
        'detection_failed',
        new OneSDKError('Failed during data review in form', error),
      );
      expect(localEventHub.emit).toHaveBeenCalledWith('loading', false, {
        message: 'Failed during data review in form',
      });
      expect(findEventEmissions('loading')).toHaveLength(1);
      expect(findEventEmissions('detection_failed')).toHaveLength(1);
    }, 2);
  });
});
