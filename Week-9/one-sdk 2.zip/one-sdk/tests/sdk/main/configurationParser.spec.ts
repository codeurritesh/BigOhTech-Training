import { ResolvedRootParameters } from "@module/common/types";
import { parseConfiguration, resolveParameters } from "@module/sdk/initialisation/configurationParser";
import { mkSharedDependencies, registerTelemetryEvents } from "@module/sdk/initialisation/sharedDependencies";
import { GlobalEvents, SdkModes } from "@module/sdk/types";
import axios, { AxiosError, AxiosInstance } from "axios";
import mockAxiosInstance from "jest-mock-axios";
import UAParser from "ua-parser-js";
import { mockEventHub } from "../../mocks/EventHub";
import { mockFrankieClient } from "../../mocks/FrankieClient";
import { mockSessionContext } from "../../mocks/SessionContext";
import { delayTest } from "../../testUtils/asyncUtils";
import { expectEventHub, expectFrankieClient } from "../../testUtils/expecters";
import { jwtWithEntityId, jwtWithReference } from "../../testUtils/tokens";

jest.mock("@package-meta", () => ({
  version: "0.4.1-alpha",
}));
const mockGetResult = jest.fn();
jest.mock("ua-parser-js", () => ({
  UAParser: class {
    getResult(): UAParser.IResult {
      return mockGetResult();
    }
  },
}));

const AxiosCreateSpy = jest.spyOn(axios, "create");
const mockScreenWidth = (width: number) => {
  return jest.spyOn(window.screen, "width", "get").mockReturnValue(width);
};

describe("parseConfiguration", () => {
  beforeEach(() => {
    AxiosCreateSpy.mockClear();
    mockScreenWidth(0);
    mockGetResult.mockReturnValue({
      ua: "some/user-agent",
      browser: {
        name: "Chrome",
        version: "vBR.y.z",
        major: "",
      },
      device: {
        model: "Model",
        type: "Desktop",
        vendor: "LG",
      },
      os: {
        name: "Mac OS",
        version: "vOS.x.y",
      },
      cpu: {
        architecture: "",
      },
      engine: {
        name: "Engine",
        version: "vEn.x.y",
      },
    });
  });
  test("Attaches frankieClient and globalEventHub to returned object with parsed options", async () => {
    const getMock = jest.fn().mockResolvedValue({});
    AxiosCreateSpy.mockReturnValue(<AxiosInstance>(<unknown>{
      ...mockAxiosInstance,
      get: getMock,
    }));
    const rootParameters: ResolvedRootParameters = resolveParameters({
      telemetry: true,
      recipe: "anything",
      mode: SdkModes.DUMMY,
      session: mockSessionContext(),
    });
    const shared = await mkSharedDependencies(rootParameters);
    const { globalState: resulting } = await parseConfiguration(rootParameters, shared);
    expect(resulting).toMatchObject({
      recipe: { name: "anything" },
      mode: { modeName: SdkModes.DUMMY },
      session: { customerID: "none", sessionId: "none", environment: "https://dummy.com" },
    });
    expect(getMock).not.toHaveBeenCalled();
    expectEventHub(resulting.globalEventHub);
    expectFrankieClient(resulting.frankieClient);
  });
  test("Missing options are replaced with defaults", async () => {
    const getMock = jest.fn().mockResolvedValue({});
    AxiosCreateSpy.mockReturnValue(<AxiosInstance>(<unknown>{
      ...mockAxiosInstance,
      get: getMock,
    }));
    const mandatorySessionObject = {
      token: jwtWithReference,
    };

    const rootParameters: ResolvedRootParameters = resolveParameters({ session: mandatorySessionObject });
    const shared = await mkSharedDependencies(rootParameters);
    const { globalState: resulting } = await parseConfiguration(rootParameters, shared);

    expect(resulting).toMatchObject({
      mode: { modeName: "production" },
      session: {
        token: jwtWithReference,
        environment: "https://some-environment.com",
        reference: "some-reference",
        sessionId: "some-session-id",
      },
      recipe: { name: "auto" },
    });
    expect(getMock).toHaveBeenNthCalledWith(1, "data/v2/token-validity", undefined);
    expect(getMock).toHaveBeenNthCalledWith(2, "/onesdk/v1/config", {
      params: { item: "auto", itemType: "object" },
    });
  });
  test("registerTelemetryEvents will register telemetry events to global event hub, which submit event to backend successfully with an info event", async () => {
    const globalEventHub = mockEventHub<GlobalEvents>();
    const infoListener = jest.fn();
    const warningListener = jest.fn();
    globalEventHub.on("info", infoListener);
    globalEventHub.on("warning", warningListener);

    const { frankieClient } = mockFrankieClient({ globalEventHub });
    frankieClient.session = mockSessionContext(jwtWithReference);

    registerTelemetryEvents(globalEventHub, frankieClient);

    frankieClient.post.mockResolvedValue(void 0);
    globalEventHub.emit("telemetry", { eventName: "test1", data: { extraInformation: "test1" } });
    expect(frankieClient.post).toHaveBeenCalledWith(expect.stringContaining("/events"), expect.any(Object));
    expect(frankieClient.post.mock.calls[0][1]).toMatchObject({
      name: "test1",
      environment: "https://some-environment.com",
      timestamp: expect.stringMatching(/\d{4}-\d{2}-\d{2}/),
      customerReference: "some-reference",
      entityId: "none",
      data: { extraInformation: "test1" },
      channel: "one-sdk",
      customerId: "customer-id",
      customerChildId: "none",
      sessionId: "some-session-id",
      version: "0.4.1-alpha",
      browser: {
        name: "chrome",
        userAgent: "some/user-agent",
        language: "en-us",
        version: "vbr.y.z",
      },
      device: expect.objectContaining({
        osName: "mac os",
        osVersion: "vos.x.y",
        model: "model",
        engine: expect.any(Object),
        cpu: expect.any(Object),
        type: "desktop",
        screen: {
          height: 0,
          width: 0,
          availableHeight: 0,
          availableWidth: 0,
          colorDepth: 24,
          orientation: "landscape-primary",
          pixelDepth: 24,
        },
        vendor: "lg",
      }),
    });
    return delayTest(() => {
      expect(infoListener).toHaveBeenCalledWith({
        message: "Event 'telemetry' submitted successfully",
        payload: { eventName: "test1", data: { extraInformation: "test1" } },
      });
      expect(warningListener).not.toHaveBeenCalled();
    });
  });
  test("option session.appReference is attached to telemetry event's 'channel'", async () => {
    const globalEventHub = mockEventHub<GlobalEvents>();
    const telemetryListener = jest.fn();
    globalEventHub.on("telemetry", telemetryListener);

    const { frankieClient } = mockFrankieClient({ globalEventHub });
    frankieClient.session = mockSessionContext(jwtWithReference, {
      appReference: "some-appReference",
      takenFromStorage: false,
    });

    registerTelemetryEvents(globalEventHub, frankieClient);

    frankieClient.post.mockResolvedValue(void 0);
    globalEventHub.emit("telemetry", { eventName: "test1", data: { extraInformation: "test1" } });
    expect(frankieClient.post.mock.calls[0][1]).toMatchObject({
      channel: "one-sdk/some-appReference",
    });
  });
  test("registerTelemetryEvents will register telemetry events to global event hub, which submits event to backend, but fails with a warning event", async () => {
    const globalEventHub = mockEventHub<GlobalEvents>();
    const infoListener = jest.fn();
    const warningListener = jest.fn();
    globalEventHub.on("info", infoListener);
    globalEventHub.on("warning", warningListener);

    const { frankieClient } = mockFrankieClient({ globalEventHub });
    frankieClient.session = mockSessionContext(jwtWithEntityId);

    registerTelemetryEvents(globalEventHub, frankieClient);

    const error = new AxiosError("Some error message");
    frankieClient.post.mockRejectedValue(error);
    globalEventHub.emit("telemetry", { eventName: "test2", data: { extraInformation: "test2" } });
    expect(frankieClient.post).toHaveBeenCalledWith(expect.stringContaining("/events"), expect.any(Object));
    expect(frankieClient.post.mock.calls[0][1]).toMatchObject({
      name: "test2",
      environment: "https://some-environment.com",
      timestamp: expect.stringMatching(/\d{4}-\d{2}-\d{2}/),
      customerReference: "none",
      entityId: "some-id",
      data: { extraInformation: "test2" },
      channel: "one-sdk",
      customerId: "customer-id",
      customerChildId: "none",
      sessionId: "some-session-id",
      version: "0.4.1-alpha",
      browser: {
        name: "chrome",
        userAgent: "some/user-agent",
        language: "en-us",
        version: "vbr.y.z",
      },
      device: expect.objectContaining({
        osName: "mac os",
        osVersion: "vos.x.y",
        model: "model",
        engine: expect.any(Object),
        cpu: expect.any(Object),
        type: "desktop",
        screen: {
          height: 0,
          width: 0,
          availableHeight: 0,
          availableWidth: 0,
          colorDepth: 24,
          orientation: "landscape-primary",
          pixelDepth: 24,
        },
        vendor: "lg",
      }),
    });
    return delayTest(() => {
      expect(warningListener).toHaveBeenCalledWith({
        message: expect.stringContaining("There was a problem"),
        payload: { eventName: "test2", data: { extraInformation: "test2" }, error },
      });
      expect(infoListener).not.toHaveBeenCalled();
    });
  });
  test("telemetry events might be defined simply as the event name too", async () => {
    const globalEventHub = mockEventHub<GlobalEvents>();
    const infoListener = jest.fn();
    const warningListener = jest.fn();
    globalEventHub.on("info", infoListener);
    globalEventHub.on("warning", warningListener);

    const { frankieClient } = mockFrankieClient({ globalEventHub });
    frankieClient.session = mockSessionContext(jwtWithEntityId);

    registerTelemetryEvents(globalEventHub, frankieClient);

    const error = new AxiosError("Some error message");
    frankieClient.post.mockRejectedValue(error);
    globalEventHub.emit("telemetry", "test3");
    expect(frankieClient.post).toHaveBeenCalledWith(expect.stringContaining("/events"), expect.any(Object));
    expect(frankieClient.post.mock.calls[0][1]).toMatchObject({
      name: "test3",
      environment: "https://some-environment.com",
      timestamp: expect.stringMatching(/\d{4}-\d{2}-\d{2}/),
      customerReference: "none",
      entityId: "some-id",
      data: {},
      channel: "one-sdk",
      customerId: "customer-id",
      customerChildId: "none",
      sessionId: "some-session-id",
      version: "0.4.1-alpha",
      browser: {
        name: "chrome",
        userAgent: "some/user-agent",
        language: "en-us",
        version: "vbr.y.z",
      },
      device: expect.objectContaining({
        osName: "mac os",
        osVersion: "vos.x.y",
        model: "model",
        engine: expect.any(Object),
        cpu: expect.any(Object),
        type: "desktop",
        screen: {
          height: 0,
          width: 0,
          availableHeight: 0,
          availableWidth: 0,
          colorDepth: 24,
          orientation: "landscape-primary",
          pixelDepth: 24,
        },
        vendor: "lg",
      }),
    });
    return delayTest(() => {
      expect(warningListener).toHaveBeenCalledWith({
        message: expect.stringContaining("There was a problem"),
        payload: { eventName: "test3", data: {}, error },
      });
      expect(infoListener).not.toHaveBeenCalled();
    });
  });
  test("telemetry device type will use the screen size for desktop devices", async () => {
    const globalEventHub = mockEventHub<GlobalEvents>();
    const { frankieClient } = mockFrankieClient({ globalEventHub });
    frankieClient.session = mockSessionContext(jwtWithEntityId);

    const fullDetails = mockGetResult();
    fullDetails.device.type = undefined;
    mockGetResult.mockReturnValue(fullDetails);
    mockScreenWidth(1000);

    registerTelemetryEvents(globalEventHub, frankieClient);
    globalEventHub.emit("telemetry", "test4");

    expect(frankieClient.post.mock.calls[0][1]).toMatchObject({
      device: expect.objectContaining({
        type: "desktop",
        screen: expect.objectContaining({
          width: 1000,
        }),
      }),
    });
  });
  test("telemetry device type will use the screen size as a fallback for mobile devices", async () => {
    const globalEventHub = mockEventHub<GlobalEvents>();
    const { frankieClient } = mockFrankieClient({ globalEventHub });
    frankieClient.session = mockSessionContext(jwtWithEntityId);

    const fullDetails = mockGetResult();
    fullDetails.device.type = undefined;
    mockGetResult.mockReturnValue(fullDetails);
    mockScreenWidth(300);

    registerTelemetryEvents(globalEventHub, frankieClient);
    globalEventHub.emit("telemetry", "test4");

    expect(frankieClient.post.mock.calls[0][1]).toMatchObject({
      device: expect.objectContaining({
        type: "mobile",
        screen: expect.objectContaining({
          width: 300,
        }),
      }),
    });
  });
  test("mkSharedDependencies will register telemetry events if option `telemetry` is true", async () => {
    const rootParameters: ResolvedRootParameters = resolveParameters({
      session: { token: jwtWithEntityId },
      telemetry: true,
    });
    const { globalEventHub } = await mkSharedDependencies(rootParameters);
    expect(globalEventHub.hasListenersFor("telemetry")).toBe(true);
  });
  test("mkSharedDependencies will not register telemetry events if option `telemetry` is false", async () => {
    const rootParameters: ResolvedRootParameters = resolveParameters({
      session: { token: jwtWithEntityId },
      telemetry: false,
    });
    const { globalEventHub } = await mkSharedDependencies(rootParameters);
    expect(globalEventHub.hasListenersFor("telemetry")).toBe(false);
  });
});
