import { ResolvedRootParameters } from "@module/common/types";
import { resolveToken } from "@module/session";
import { SessionContext } from "@module/session/SessionContext";
import { mockEventHub } from "./EventHub";

type Params = ConstructorParameters<typeof SessionContext>;
export function mockSessionContext(): SessionContext;
export function mockSessionContext(...args: Params): SessionContext;
export function mockSessionContext(token?: Params[0], options?: Params[1]): SessionContext {
  let sessionContext: SessionContext;

  if (token) {
    const globalEventHub = mockEventHub();
    const session = { token, appReference: options?.appReference ?? null };
    sessionContext = resolveToken(
      <ResolvedRootParameters>{
        session,
      },
      {
        globalEventHub,
      }
    );
  } else {
    sessionContext = new SessionContext({
      customerID: "none",
      customerChildID: "none",
      environment: "https://dummy.com",
      sessionId: "none",
      reference: "dummy-reference",
      entityId: null,
    });
  }

  jest.spyOn(sessionContext, "customerChildID", "get");
  jest.spyOn(sessionContext, "customerID", "get");
  jest.spyOn(sessionContext, "entityId", "get");
  jest.spyOn(sessionContext, "environment", "get");
  jest.spyOn(sessionContext, "reference", "get");
  jest.spyOn(sessionContext, "sessionId", "get");
  jest.spyOn(sessionContext, "token", "get");
  jest.spyOn(sessionContext, "setToken");
  jest.spyOn(sessionContext, "setEntityId");
  jest.spyOn(sessionContext, "isValid");

  return sessionContext;
}
