import {ReportAttribute, IReportAttributePayload} from "./ReportAttributes";
interface IBiometryReportPayload {
  checkDate: string | null;
  documentId: string | null;
  result: string | null;
  confidence_level: string | null;
  compare_type: string | null;
  checkStatus: string | null;
  referenceDocType: string | null;
  items: IReportAttributePayload[];
}

interface IBiometryReportConstructor {
  checkDate: string | null;
  documentId: string | null;
  result: string | null;
  confidence_level: string | null;
  compare_type: string | null;
  checkStatus: string | null;
  referenceDocType: string | null;
  items?: ReportAttribute[];
}

export class BiometryReport {
  checkDate: string;
  documentId: string;
  result: string;
  confidence_level: string;
  compare_type: string;
  checkStatus: string;
  referenceDocType: string;
  items: ReportAttribute[];
  constructor(payload?: IBiometryReportConstructor) {
    this.checkDate = payload?.checkDate || "";
    this.documentId = payload?.documentId || "";
    this.result = payload?.result || "";
    this.confidence_level = payload?.confidence_level || "";
    this.compare_type = payload?.compare_type || "";
    this.checkStatus = payload?.checkStatus || "";
    this.referenceDocType = payload?.referenceDocType || "";
    this.items = payload?.items || [];
  }

  toJSON(): IBiometryReportPayload{
    const items = this.items.map(a => a.toJSON());

    return{
      ...this,
      items
    }
  }

  static fromJSON(payload: IBiometryReportPayload):  BiometryReport{
    const items = payload.items.map(m => ReportAttribute.fromJSON(m));

    return new BiometryReport({
     ...payload,
     items
    });
  }
}
