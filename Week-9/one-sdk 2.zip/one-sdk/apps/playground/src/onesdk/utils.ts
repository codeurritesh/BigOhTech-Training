export const telemetryEventLogger = ({ eventName, ...payload }) => console.log("telemetry", eventName, payload);
