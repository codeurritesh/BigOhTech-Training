
import { Options as OCRFlowOptions } from "../ocr/ocrSubmission";
import { IDVFlowOptions } from "../idvAndBiometrics/idvSubmission";
import { ResolveIndividualDataOptions } from "../individual/resolveIndividualData";

export type MockOptions = Partial<{
  preloadedIndividual: false | ResolveIndividualDataOptions;
  ocrRequests: OCRFlowOptions;
  idvRequests: IDVFlowOptions;
}>;
