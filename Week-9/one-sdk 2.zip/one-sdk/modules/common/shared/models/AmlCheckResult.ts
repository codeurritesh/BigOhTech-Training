export interface IAmlCheckResultPayload {
  name: string | null;
  dateOfBirth: string | null;
  countries: string[] | null;
  searchFuzziness: number | null;
  vendorId: string | null;
  checkId: string | null;
  searchDate: string | null;
}

export interface IAmlCheckResultConstructor {
  name: string | null;
  dateOfBirth: string | null;
  countries: string[] | null;
  searchFuzziness: number | null;
  vendorId: string | null;
  checkId: string | null;
  searchDate: string | null;
}

export class AmlCheckResult {
  name: string | null;
  dateOfBirth: string | null;
  countries: string[] | null;
  searchFuzziness: number | null;
  vendorId: string | null;
  checkId: string | null;
  searchDate: string | null;
  matches: AmlMatchSummary[];
  constructor(a: IAmlCheckResultConstructor) {
    this.name = a.name || null;
    this.dateOfBirth = a.dateOfBirth || null;
    this.countries = a.countries || [];
    this.searchFuzziness = a.searchFuzziness || null;
    this.vendorId = a.vendorId || null;
    this.checkId = a.checkId || null;
    this.searchDate = a.searchDate || null;
    this.matches = [];
  }

  addMatchSummary(m: AmlMatchSummary) {
    this.matches.push(m);
  }

  toJSON(): IAmlCheckResultPayload {
    const { matches } = this;

    return { ...this, matches: matches.map((m) => m.toJSON()) };
  }

  static fromJSON(payload: IAmlCheckResultPayload): AmlCheckResult {
    return new AmlCheckResult({ ...payload });
  }
}
export interface IAmlMatchSummaryPayload {
  comment: string | null;
  pawsAlert: string[] | null;
  matchStrength: number | null;
  matchStatus: {
    by: string | null;
    status: string | null;
  };
  countries: string[] | null;
  dateOfBirth: string | null;
  name: string | null;
  entityType: string | null;
  groupId: string | null;
}

export interface IAmlMatchSummaryConstructor {
  comment: string | null;
  pawsAlert: string[] | null;
  matchStrength: number | null;
  matchStatus: {
    by: string | null;
    status: string | null;
  };
  countries: string[] | null;
  dateOfBirth: string | null;
  name: string | null;
  entityType: string | null;
  groupId: string | null;
}

export class AmlMatchSummary {
  comment: string | null;
  pawsAlert: string[];
  matchStrength: number | null;
  matchStatus: {
    by: string | null;
    status: string | null;
  };
  countries: string[];
  dateOfBirth: string | null;
  name: string | null;
  entityType: string | null;
  groupId: string | null;
  constructor(a: IAmlMatchSummaryConstructor) {
    this.comment = a.comment || null;
    this.pawsAlert = a.pawsAlert || [];
    this.matchStrength = a.matchStrength || null;
    this.matchStatus = {
      by: a.matchStatus.by || null,
      status: a.matchStatus.status || null,
    };
    this.countries = a.countries || [];
    this.dateOfBirth = a.dateOfBirth || null;
    this.name = a.name || null;
    this.entityType = a.entityType || null;
    this.groupId = a.groupId || null;
  }

  toJSON(): IAmlMatchSummaryPayload {
    return { ...this };
  }

  static fromJSON(payload: IAmlMatchSummaryPayload): AmlMatchSummary {
    return new AmlMatchSummary({ ...payload });
  }
}
