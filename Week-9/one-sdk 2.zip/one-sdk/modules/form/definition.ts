import type { DeepPartial } from '@module/common/shared/models/general';
import type { ModuleDefinition } from '@module/common/types';
import type { FormEvents } from '@module/form/events';
import type {
  LegacyUIConfiguration,
} from '@module/form/vendors/legacy/legacyUIOptions.types';
import type {
  TPageConfig,
} from '@module/form/vendors/react/appConfig.type';
import type {
  ReactFormIdsKeys,
} from '@module/form/vendors/react/types/pages.type';

import type { PartialDeep } from 'type-fest';

export type FormModule = ModuleDefinition<{
  module: {
    name: 'form';
    category: 'component';
    context: {
      readonly provider: FormModule['vendorName'];
      mount: (mountElement: string | HTMLElement) => Promise<WrapperContext>;
    };
    events: FormEvents;
    options: PartialDeep<FormRecipeOptions['provider']['config']>;
    recipe: {
      form: FormRecipeOptions;
    };
  };
  wrapper: {
    loadType: 'async';
    vendors: ['legacy', 'formio', 'react'];
    options: {
      mountElement: HTMLElement;
    };
    context: WrapperContext;
  };
}>;

type WrapperContext = {
  cleanup: () => void;
};

type FormRecipeOptions = {
  provider:
    | {
    name: 'legacy';
    version: string;
    config?: DeepPartial<LegacyUIConfiguration>;
  }
    | {
    name: 'formio';
    formUrl: string;
    config?: null;
  }
    | {
    name: 'react';
    config?: {
      mode: 'individual' | 'business';
      name: ReactFormIdsKeys;
      type: 'ocr' | 'manual';
    } & TPageConfig;
  };
}
