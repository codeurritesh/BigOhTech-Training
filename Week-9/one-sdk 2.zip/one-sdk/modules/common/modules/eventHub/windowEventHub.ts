import { OneSDKError } from '@module/common/errors/OneSDKError.class';
import type { KeyOf } from '@types';

import { mkEventHub, mkEventListener } from '.';

import type { EventsDictionary, KeyOfExtendedEvents, EventHub } from './types';

/**
 * This function is used to create an event hub that listens to events emitted by the window object.
 * This function will convert Error objects into OneSDKError objects.
 * @param autoEmitEventNames - The names of the events that should be listened to and reemitted automatically
 * @returns A cleanup method and an event listener
 */
export function mkWindowEventHub<Events extends EventsDictionary>(autoEmitEventNames: KeyOf<Events>[]) {
  type EventListenerCallback<T> = (event: CustomEvent<T>) => void;

  const listeners: {
    [key: string]: EventListenerCallback<unknown>[];
  } = {};

  const FormEventHub = mkEventHub<Events>();
  const emitToEventHub = extractGenericEmitMethod(FormEventHub);

  const addEventListener = (
    eventName: string,
    listener: EventListenerCallback<unknown>,
  ) => {
    listeners[eventName] ??= [];
    listeners[eventName].push(listener);

    window.addEventListener(eventName, listener);
  };
  autoEmitEventNames.forEach((eventName) =>
    addEventListener(eventName, (customEvent) => {
      const detail = customEvent.detail;
      const data = detail instanceof Error ? new OneSDKError(detail.message, detail) : detail;

      emitToEventHub(eventName as unknown as KeyOfExtendedEvents<Events>, data);
    }),
  );

  return {
    cleanup() {
      Object.entries(listeners).forEach(([eventName, listeners]) => {
        listeners.forEach((listener) => {
          window.removeEventListener(eventName, listener);
        });
      });
    },
    eventListener: mkEventListener(FormEventHub),
  };
}

/**
 * This function is simply used to simplify typescript's type inference
 */
const extractGenericEmitMethod = (eh: EventHub) => eh.emit.bind(eh) as (
  en: string,
  data: unknown
) => void;
