import { dirname, resolve } from 'path';
import { fileURLToPath } from 'url';

import { defineConfig, mergeConfig } from 'vite';

// import { viteSingleFile } from "vite-plugin-singlefile";
import { getDotEnvVariables } from '../../scripts/env';
import { pathTuplesWithoutWildcard } from '../../scripts/pathAlias';

export const _filename = fileURLToPath(import.meta.url);
export const _dirname = dirname(_filename);
export const repoRoot = resolve(_dirname, '../../');

// interface CustomConfig {
//   appDir: string;
//   entryFile?: string;
// }
/**
 * Options such as USE_SDK_DIST and customConfig?.aliasOneSdkSourceCode allows us to test the SDK in different stages
 * aliasOneSdkSourceCode = true: Use the SDK source code directly
 * aliasOneSdkSourceCode = false: Use the SDK from the npm registry
 */
const pathAliases = (aliasOneSdkSourceCode) => {
  // When using internal source code, take the path aliases from the tsconfig.base.json file
  // If we are using this app to validate the SDK build (as opposed to the SDK source code), we need to alias the import to the dist folder directly
  if (aliasOneSdkSourceCode) {
    return pathTuplesWithoutWildcard
      .map(([find, replacement]) => [find, resolve(repoRoot, replacement)])
      .map(([find, replacement]) => ({ find, replacement }));
  }
  return [];
};
export default function (mergedConfig, customConfig) {
  return defineConfig(() => {
    const { appDir } = customConfig;
    const appRoot = resolve(repoRoot, 'apps', appDir);
    const aliasOneSdkSourceCode = customConfig?.aliasOneSdkSourceCode ?? true;
    const aliases = pathAliases(aliasOneSdkSourceCode);
    const dotEnv = getDotEnvVariables('process.env');

    return mergeConfig(
      {
        root: appRoot,
        envDir: repoRoot,
        envPrefix: 'PUBLIC_',
        build: {
          outDir: resolve(appRoot, 'dist'),
        },
        define: dotEnv.definePluginReplacements,
        plugins: [],
        resolve: {
          alias: aliases,
          preserveSymlinks: true,
        },
      },
      mergedConfig,
    );
  });
}
