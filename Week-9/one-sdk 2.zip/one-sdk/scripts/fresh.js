/* eslint-disable no-console */
import { exec, execSync } from 'child_process';
import { existsSync, readdirSync, rmSync, statSync, writeFile } from 'fs';
import { dirname, resolve as resolvePath } from 'path';
import { fileURLToPath } from 'url';
import { promisify } from 'util';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

(async () => {
  const allParallelPromises = [];
  // Create meta file, used to expose package meta information to final sdk users
  allParallelPromises.push(createMetaFile());

  // Defining directory/file paths to be deleted
  const pathsToDelete = ['dist', '.rollup.cache', 'node_modules', 'tsconfig.tsbuildinfo'];
  if (arg('--include-apps')) {
    const apps = readdirSync(resolveToRoot('./apps'));
    const nodeModulesPaths = apps.map((app) => `apps/${app}/node_modules`);
    pathsToDelete.push(...nodeModulesPaths);
  }

  // Delete directories in series
  // TODO: Delete paths in parallel before installing dependencies
  pathsToDelete.forEach((path) => rm(path, { recursive: isDirectory(path) }));

  // Install dependencies in parallel
  allParallelPromises.push(npmInstallAt('.'));
  if (arg('--include-apps')) {
    const apps = readdirSync(resolveToRoot('./apps'));
    allParallelPromises.push(...apps.map((dir) => npmInstallAt(`./apps/${dir}`, { async: true })));
  }

  return Promise.all(allParallelPromises);
})();
function isDirectory(path) {
  return existsSync(path) && statSync(path).isDirectory();
}
function createMetaFile() {
  const contents = {
    version: 'v0.0.1-dev',
  };
  const path = resolvePath(__dirname, '../modules/meta.json');
  const writeFileAsync = promisify(writeFile);

  return writeFileAsync(path, JSON.stringify(contents)).then(() => console.log('> Created modules/meta.json file\n'));
}
function arg(argument) {
  return process.argv.slice(2).includes(argument);
}
function resolveToRoot(path) {
  // always resolve path relative to root of the project (..)
  const resolvedPath = resolvePath(__dirname, '..', path);
  return resolvedPath;
}
function rm(target, options = {}) {
  const resolvedPath = resolveToRoot(target);
  if (!existsSync(resolvedPath)) return;
  console.log(`> Deleting ${isDirectory(resolvedPath) ? 'directory' : 'file'} '${resolvedPath}'\n`);
  try {
    rmSync(resolvedPath, options);
  } catch (e) {
    if (e.code !== 'ENOENT') console.error(e.message);
    return null;
  }
  return resolvedPath;
}
function npmInstallAt(cwd, { async = false } = {}) {
  const resolvedPath = resolveToRoot(cwd);
  if (!existsSync(resolvePath(resolvedPath, 'package.json'))) return;

  console.log(`> Installing dependencies in '${resolvedPath}'...\n`);

  const command = `cd ${resolvedPath} && npm ci --force --production=false`;

  if (async) return promisify(exec)(command);
  return execSync(command);
}
