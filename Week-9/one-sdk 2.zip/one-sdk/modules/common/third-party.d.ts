declare module "load-script-promise" {
  export function loadScript(url: string): Promise<void>;
  export function loadCSS(url: string): Promise<void>;
}
declare module "convert-hex" {
  export function hexToBytes(hex: string): number[];
}
