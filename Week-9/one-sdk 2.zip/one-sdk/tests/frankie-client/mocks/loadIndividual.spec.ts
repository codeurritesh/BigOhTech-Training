import { mkEventHub } from '@module/common';
import { Applicant } from '@module/common/shared/models/Applicant';
import { Document } from '@module/common/shared/models/Document';
import { DummyFrankieApiClient } from '@module/frankie-client';
import { ApplicantClient } from '@module/frankie-client/clients/ApplicantClient';
import { OCRStatus } from '@module/frankie-client/clients/OCRClient';
import { loadExistingApplicant } from '@module/frankie-client/mocks/individual/loadIndividual';

import { mockSessionContext } from '../../mocks/SessionContext';
import { mockedPreloadedMatcher } from '../../testUtils/patterns';
import { jwtWithEntityId, jwtWithReference } from '../../testUtils/tokens';

describe('Dummy mode: initialise existing individual without session token', () => {
  test('successfully loading default existing applicant', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });

    dummyClient.session = mockSessionContext();

    loadExistingApplicant(dummyClient, {
      preloadedIndividual: {
        documents: [],
        individual: {},
      },
    });
    const applicantClient = new ApplicantClient(dummyClient);
    const { applicant, documents } = await applicantClient.load();
    const expectedApplicant = new Applicant();
    expectedApplicant.entityId = mockedPreloadedMatcher;
    expectedApplicant.name.givenName = 'John';
    expectedApplicant.name.familyName = 'Doe';
    expectedApplicant.dateOfBirth = '1991-10-16';
    expectedApplicant.customerReference = 'dummy-reference';

    expect(applicant).toEqual(expectedApplicant);
    expect(documents).toEqual([]);
  });
  test('successfully overriding default existing applicant except reference. Reference will always be assigned by the session token OR defaulted by the DummyFrankieApiClient. Incomplete fields will be deep merged with defaults. (Watch familyName)', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });
    dummyClient.session = mockSessionContext(jwtWithReference);
    dummyClient.entityId = '123321';

    loadExistingApplicant(dummyClient, {
      preloadedIndividual: {
        documents: [],
        individual: {
          name: <Applicant['name']>{ givenName: 'Pedro' },
          dateOfBirth: '2000-01-01',
          entityId: '123321',
          customerReference: 'ref-123321',
        },
      },
    });
    const applicantClient = new ApplicantClient(dummyClient);
    const { applicant, documents } = await applicantClient.load();
    const expectedApplicant = new Applicant();
    expectedApplicant.entityId = '123321';
    expectedApplicant.name.givenName = 'Pedro';
    expectedApplicant.name.familyName = 'Doe';
    expectedApplicant.dateOfBirth = '2000-01-01';
    expectedApplicant.customerReference = 'some-reference';

    expect(applicant).toEqual(expectedApplicant);
    expect(documents).toEqual([]);
  });
});
describe('Dummy mode: initialise existing individual with session token using entityId', () => {
  test('successfully loading default existing applicant. entityId = some-id be taken from token', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });
    dummyClient.session = mockSessionContext(jwtWithEntityId);

    loadExistingApplicant(dummyClient, {
      preloadedIndividual: {
        documents: [],
        individual: {},
      },
    });
    const applicantClient = new ApplicantClient(dummyClient);
    const { applicant, documents } = await applicantClient.load();
    const expectedApplicant = new Applicant();
    expectedApplicant.entityId = 'some-id';
    expectedApplicant.name.givenName = 'John';
    expectedApplicant.name.familyName = 'Doe';
    expectedApplicant.dateOfBirth = '1991-10-16';
    expectedApplicant.customerReference = null;

    expect(applicant).toEqual(expectedApplicant);
    expect(documents).toEqual([]);
  });
  test('successfully overriding default existing applicant. entityId = some-id will be taken from token and reference will be overriden', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });
    dummyClient.session = mockSessionContext(jwtWithEntityId);
    loadExistingApplicant(dummyClient, {
      preloadedIndividual: {
        documents: [],
        individual: {
          name: <Applicant['name']>{ givenName: 'Pedro', familyName: null },
          dateOfBirth: '2000-01-01',
          entityId: '123321',
          customerReference: 'ref-123321',
        },
      },
    });
    const applicantClient = new ApplicantClient(dummyClient);
    const { applicant, documents } = await applicantClient.load();
    const expectedApplicant = new Applicant();
    expectedApplicant.entityId = 'some-id';
    expectedApplicant.name.givenName = 'Pedro';
    expectedApplicant.name.familyName = null;
    expectedApplicant.dateOfBirth = '2000-01-01';
    expectedApplicant.customerReference = 'ref-123321';

    expect(applicant).toEqual(expectedApplicant);
    expect(documents).toEqual([]);
  });
});
describe('Dummy mode: custom preloaded documents', () => {
  test('loading a single default document', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });

    loadExistingApplicant(dummyClient, {
      preloadedIndividual: {
        documents: [{}] as Document[],
        individual: {},
      },
    });
    const applicantClient = new ApplicantClient(dummyClient);
    const { documents } = await applicantClient.load();

    const expectedDocument1 = new Document();
    expectedDocument1.idType = 'OTHER';
    expectedDocument1.idNumber = expect.stringMatching(/\d+/);
    expectedDocument1.gender = null;
    expectedDocument1.country = 'AUS';
    expectedDocument1.ocrResult = {};
    expectedDocument1.documentId = expect.stringMatching('mockpreloaded');

    expect(documents).toEqual([expectedDocument1]);
  });
  test('loading a single custom document', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });

    loadExistingApplicant(dummyClient, {
      preloadedIndividual: {
        documents: [
          { idType: 'PASSPORT', country: 'BRA', ocrResult: { status: OCRStatus.WAITING_BACK } },
        ] as Document[],
        individual: {},
      },
    });
    const applicantClient = new ApplicantClient(dummyClient);
    const { documents } = await applicantClient.load();

    const expectedDocument1 = new Document();
    expectedDocument1.idType = 'PASSPORT';
    expectedDocument1.idNumber = expect.stringMatching(/\d+/);
    expectedDocument1.gender = null;
    expectedDocument1.country = 'BRA';
    expectedDocument1.ocrResult = { status: OCRStatus.WAITING_BACK };
    expectedDocument1.documentId = expect.stringMatching('mockpreloaded');

    expect(documents).toEqual([expectedDocument1]);
  });
});
