/**
 * modules will "define" each of the modules in the SDK, by
 * 1) importing the index script of each, which will call "defineModule" and install each of their initialise functions into the (untyped) global object of initialise functions
 * 2) importing the ModuleDefinition type of each of them and analysing them all and reexporting a Modules global type with all details extracted from each
 * 3) exporting a Modules global object with all initialise functions, but now typed with the Modules global type
 *
 * For that reason, code inside modules cannot access the typed global object of initialise functions directly, but they may use the factory functions "component" and "flow".
 */
export * from "./modules";
