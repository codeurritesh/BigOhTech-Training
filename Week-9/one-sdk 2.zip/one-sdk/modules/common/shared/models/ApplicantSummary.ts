import { Kvp } from "./general";
import { KvpList } from "./KvpList";

import { IIssue, IIssueAction } from "./TApplicantIssue";
export interface ITransactionStatus {
  type: string;
  label: string;
  key: string;
}
export class TransactionStatus {
  type: string;
  label: string;
  key: string;
  constructor(t?: ITransactionStatus) {
    this.type = t?.type || "";
    this.label = t?.label || "";
    this.key = t?.key || "";
  }

  toJSON(): ITransactionStatus {
    return { ...this };
  }
}

export interface IRiskLevelPayload {
  term: string;
  label: string;
  key: string;
}

export interface IRiskLevelConstructor {
  term: string;
  label: string;
  key: string;
}

export class RiskLevel implements IRiskLevelPayload {
  term: string;
  label: string;
  key: string;

  constructor(t?: IRiskLevelConstructor) {
    this.term = t?.term || "";
    this.label = t?.label || "";
    this.key = t?.key || "";
  }

  toJSON(): IRiskLevelPayload {
    return { ...this };
  }

  static fromJSON(payload: IRiskLevelPayload): RiskLevel {
    return new RiskLevel({ ...payload });
  }
}
type IAlertList = IIssueAction | IIssue;
type IStringOrNull = string | null;
interface IApplicantSummaryPayload {
  entityId: IStringOrNull;
  entityName: IStringOrNull;
  extraData: Kvp[];
  requestId: IStringOrNull;
  timestamp: IStringOrNull;
  applicantStatus: ITransactionStatus;
  riskLevel: IRiskLevelPayload;
  username: IStringOrNull;
  customerReference: IStringOrNull;
  createdDate: IStringOrNull;
  alertList: IAlertList[];
  assignee: IStringOrNull;
  entityType: IStringOrNull;
  profileName: IStringOrNull;
  isMonitoringEnabled: boolean;
}

export interface IApplicantSummaryConstructor {
  entityId: IStringOrNull;
  entityName: IStringOrNull;
  extraData: KvpList;
  requestId: IStringOrNull;
  timestamp: IStringOrNull;
  applicantStatus: ITransactionStatus;
  riskLevel: RiskLevel;
  username: IStringOrNull;
  customerReference: IStringOrNull;
  createdDate: IStringOrNull;
  alertList: IAlertList[];
  assignee: IStringOrNull;
  entityType: IStringOrNull;
  profileName: IStringOrNull;
  isMonitoringEnabled: boolean;
}

export class ApplicantSummary {
  entityId: IStringOrNull;
  entityName: IStringOrNull;
  requestId: IStringOrNull;
  timestamp: IStringOrNull;
  applicantStatus: ITransactionStatus;
  username: IStringOrNull;
  customerReference: IStringOrNull;
  createdDate: IStringOrNull;
  alertList: IAlertList[];
  assignee: IStringOrNull;
  extraData: KvpList;
  riskLevel: RiskLevel;
  entityType: IStringOrNull;
  profileName: IStringOrNull;
  isMonitoringEnabled: boolean;
  constructor(a: IApplicantSummaryConstructor) {
    this.entityId = a.entityId || "";
    this.entityName = a.entityName || "";
    this.requestId = a.requestId || "";
    this.timestamp = a.timestamp || "";
    this.riskLevel = a.riskLevel;
    this.applicantStatus = a.applicantStatus;
    this.username = a.username || "";
    this.customerReference = a.customerReference || null;
    this.createdDate = a.createdDate || "";
    this.assignee = a.assignee || "";
    this.extraData = a.extraData || new KvpList();
    this.alertList = a.alertList || [];
    this.entityType = a.entityType ?? null;
    this.profileName = a.profileName ?? null;
    this.isMonitoringEnabled = a.isMonitoringEnabled || false;
  }

  toJSON(): IApplicantSummaryPayload {
    const { extraData, riskLevel } = this;

    return {
      ...this,
      extraData: extraData.toJSON(),
      riskLevel: riskLevel.toJSON(),
    };
  }

  static fromJSON(payload: IApplicantSummaryPayload): ApplicantSummary {
    return new ApplicantSummary({
      ...payload,
      extraData: KvpList.fromJSON(payload.extraData),
      riskLevel: RiskLevel.fromJSON(payload.riskLevel),
    });
  }
}
