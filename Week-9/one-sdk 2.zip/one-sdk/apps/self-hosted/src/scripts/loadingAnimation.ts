const loadingElement = document.querySelector('#loader') as HTMLDivElement;
export function setLoading(loading: boolean) {
  loadingElement.style.display = loading ? 'block' : 'none';
}
