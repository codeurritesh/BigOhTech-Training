import { ReactiveStore } from "@module/common";
import { mkAddConsents } from "@module/individual/actions/consents";

describe("individual::addConsents", () => {
  test("Providing consent appends consent to applicant's list", async () => {
    const individualState$ = new ReactiveStore({
      consentsGiven: [],
    });
    const consentsGiven$ = individualState$.getRootAccessors("consentsGiven");
    const addConsent = mkAddConsents({
      consentsGiven$,
    });
    expect(consentsGiven$.getValue()).toEqual([]);
    addConsent("general");
    expect(consentsGiven$.getValue()).toEqual(["general"]);
    addConsent("documents");
    expect(consentsGiven$.getValue()).toEqual(["general", "documents"]);
  });
});
