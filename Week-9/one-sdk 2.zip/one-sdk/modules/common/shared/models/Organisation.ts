import { Nullable } from "./general";
import { User } from "./User";

// missing field users in organisationpayload
export type OrganisationPayload = {
  id: Nullable<number>;
  parentId: Nullable<number>;
  customerId: Nullable<string>;
  customerChildId: Nullable<string>;
  name: Nullable<string>;
  nickName: Nullable<string>;
  authType: Nullable<string>;
  isRoot: Nullable<boolean>;
  denyOldPasswordCount: Nullable<number>;
  timezone: Nullable<string>;
  parent: Nullable<OrganisationPayload>;
  children: OrganisationPayload[];
  organisations: OrganisationPayload[];
  users: User[];
};
export class Organisation {
  id: Nullable<number> = null;
  parentId: Nullable<number> = null;
  customerId: Nullable<string> = null;
  customerChildId: Nullable<string> = null;
  name: Nullable<string> = null;
  nickName: Nullable<string> = null;
  authType: Nullable<string> = null;
  isRoot: Nullable<boolean> = null;
  denyOldPasswordCount: Nullable<number> = null;
  timezone: Nullable<string> = null;
  parent: Nullable<Organisation> = null;
  children: Organisation[] = [];
  users: User[] = [];
  organisations: Organisation[] = [];
  toJSON(): OrganisationPayload {
    const { parent, children, users, organisations, ...primitives } = this;
    return {
      ...primitives,
      users,
      parent: parent && parent.toJSON(),
      children: children.map((c) => c.toJSON()),
      organisations: organisations.map((o) => o.toJSON()),
    };
  }
  static fromJSON(payload: OrganisationPayload): Organisation {
    const instance = new Organisation();
    instance.id = payload.id;
    instance.isRoot = payload.isRoot;
    instance.name = payload.name;
    instance.nickName = payload.nickName;
    instance.organisations = payload.organisations?.map((p) => Organisation.fromJSON(p)) ?? [];
    instance.parent = payload.parent && Organisation.fromJSON(payload.parent);
    instance.children = payload.children?.map((p) => Organisation.fromJSON(p)) ?? [];
    instance.parentId = payload.parentId;
    instance.timezone = payload.timezone;
    instance.customerChildId = payload.customerChildId;
    instance.customerId = payload.customerId;
    instance.users = payload.users;

    return instance;
  }
}
