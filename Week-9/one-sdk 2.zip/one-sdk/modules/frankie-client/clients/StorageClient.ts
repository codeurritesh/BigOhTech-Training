/**
 * May be used to abstract quick storage. May be implemented as a wrapper for LocalStorage
 * OR as a wrapper for a backend API which stores temporary data in redis
 */

import { BaseClient } from "./BaseClient";

export class StorageClient extends BaseClient {
  async retrieveAndDelete<Type>(key: string): Promise<{ value: Type }> {
    const keyPairRetrieveEndpoint = `/data/v1/key-value/${key}`;
    return this.frankie
      .get<{ value: Type }>(keyPairRetrieveEndpoint, {
        params: {
          delete: true,
        },
      })
      .then((d) => d.data);
  }
}
