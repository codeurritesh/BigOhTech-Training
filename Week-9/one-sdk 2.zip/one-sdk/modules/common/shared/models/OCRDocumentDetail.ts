export type TOcrItem = { [field: string]: Nullable<string | boolean | number> };
import { Nullable } from "./general";
import { KvpList } from "./KvpList";
import { IReportAttributePayload, ReportAttribute } from "./ReportAttributes";

interface IOCRDocumentDetailPayload {
  documentId: string | null;
  ocrReportDocumentId: string | null;
  checkDate: string | null;
  result: string | null;
  checkStatus: string | null;
  ocrItems: TOcrItem;
  checkResultItems: IReportAttributePayload[];
  mismatchFields: string[];
  ocrResult: string | null;
  hasSimplifiedResult: boolean;
  confidenceLevel: string | null;
}

interface IOCRDocumentDetailConstructor {
  documentId: string | null;
  ocrReportDocumentId: string | null;
  checkDate: string | null;
  result: string | null;
  checkStatus: string | null;
  ocrItems: KvpList;
  checkResultItems: ReportAttribute[];
  mismatchFields: string[];
  ocrResult: string | null;
  hasSimplifiedResult: boolean;
  confidenceLevel: string | null;
}

export class OCRDocumentDetail implements IOCRDocumentDetailPayload {
  documentId: string;
  ocrReportDocumentId: string;
  checkDate: string;
  result: string;
  checkStatus: string;
  ocrResult: string;
  ocrItems: TOcrItem;
  checkResultItems: ReportAttribute[];
  mismatchFields: string[];
  hasSimplifiedResult: boolean;
  confidenceLevel: string;
  constructor(payload?: IOCRDocumentDetailConstructor) {
    this.documentId = payload?.documentId || "";
    this.ocrReportDocumentId = payload?.ocrReportDocumentId || "";
    this.checkDate = payload?.checkDate || "";
    this.result = payload?.result || "";
    this.checkStatus = payload?.checkStatus || "";
    this.mismatchFields = payload?.mismatchFields || [];
    this.checkResultItems = payload?.checkResultItems || [];
    this.ocrResult = payload?.ocrResult || "";
    this.ocrItems = filterOcrScannedDetails(payload?.ocrItems || new KvpList()) || {};
    this.hasSimplifiedResult = payload?.hasSimplifiedResult || false;
    this.confidenceLevel = payload?.confidenceLevel || "";
  }

  toJSON(): IOCRDocumentDetailPayload {
    const checkResultItems: IReportAttributePayload[] = this.checkResultItems.map((i) => i.toJSON());

    return {
      ...this,
      checkResultItems,
    };
  }

  static fromJSON(payload: IOCRDocumentDetailPayload): OCRDocumentDetail {
    const extraData = KvpList.fromObject(payload.ocrItems);
    const checkResultItems = payload.checkResultItems.map((m) => ReportAttribute.fromJSON(m));

    return new OCRDocumentDetail({
      ...payload,
      ocrItems: extraData,
      checkResultItems,
    });
  }
}

function filterOcrScannedDetails(entityData: KvpList): TOcrItem {
  const ocrRegex = new RegExp(`^ocr_scanned`);
  const ocrDetails = entityData.filterKvpKeyByRegex(ocrRegex).transformed || [];
  const ocrItemsObject = KvpList.fromJSON(ocrDetails).toObject();

  return ocrItemsObject;
}
