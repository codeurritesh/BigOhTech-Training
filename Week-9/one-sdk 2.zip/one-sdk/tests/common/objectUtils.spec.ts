import { cloneValue, deepFreeze, naiveObjectComparison } from "@module/common/modules/objectUtils";

describe("deepFreeze", () => {
  test("Frozen objects can't be edited directly", () => {
    const frozen = deepFreeze({
      property: "value",
    });
    const catchException = jest.fn();
    try {
      frozen.property = "changed";
    } catch (e) {
      catchException(e);
    }
    expect(catchException).toHaveBeenCalledWith(
      expect.objectContaining({
        message: expect.stringMatching("read only"),
      })
    );
  });
});

describe("naiveObjectComparison", () => {
  const rawObject = () => ({ a: "a" });
  test("Equal values", () => {
    expect(naiveObjectComparison(null, null)).toBe(true);
    expect(naiveObjectComparison("a", "a")).toBe(true);
    expect(naiveObjectComparison(0, 0)).toBe(true);
    expect(naiveObjectComparison({}, {})).toBe(true);
    expect(naiveObjectComparison(rawObject(), rawObject())).toBe(true);
    expect(naiveObjectComparison(new Proxy(rawObject(), {}), new Proxy(rawObject(), {}))).toBe(true);
    expect(naiveObjectComparison({ toJSON: () => rawObject() }, { toJSON: () => rawObject() })).toBe(true);
    expect(naiveObjectComparison([{}], [{}])).toBe(true);
    expect(naiveObjectComparison([rawObject()], [rawObject()])).toBe(true);
    expect(naiveObjectComparison([new Proxy(rawObject(), {})], [new Proxy(rawObject(), {})])).toBe(true);
    expect(naiveObjectComparison([{ toJSON: () => rawObject() }], [{ toJSON: () => rawObject() }])).toBe(true);
    expect(naiveObjectComparison([{ a: "a" }, { b: "b" }], [{ a: "a" }, { b: "b" }])).toBe(true);
  });
  test("Different values", () => {
    expect(naiveObjectComparison(null, rawObject())).toBe(false);
    expect(naiveObjectComparison("a", "b")).toBe(false);
    expect(naiveObjectComparison(0, 1)).toBe(false);
    expect(naiveObjectComparison({ a: "a" }, { b: "a" })).toBe(false);
    expect(naiveObjectComparison([{ a: "a" }, { b: "b" }], [{ b: "b" }, { a: "a" }])).toBe(false);
  });
});

describe("cloneValue", () => {
  test("Clones values correctly", () => {
    expect(cloneValue(null)).toBe(null);
    expect(cloneValue(undefined)).toBe(undefined);
    expect(cloneValue("a")).toBe("a");
    expect(cloneValue(["a"])).toMatchObject(["a"]);
    expect(cloneValue({ clone: () => "a value" })).toBe("a value");
    expect(cloneValue([null])).toMatchObject([null]);
    expect(cloneValue([{ clone: () => "a value" }])).toMatchObject(["a value"]);
    expect(cloneValue([[{ clone: () => "a value" }]])).toMatchObject([["a value"]]);
    expect(cloneValue({ a: null })).toEqual({ a: null });
    expect(cloneValue({ a: "a" })).toEqual({ a: "a" });
    expect(cloneValue({ a: ["a"] })).toEqual({ a: ["a"] });
    expect(cloneValue({ a: { clone: () => "a value" } })).toEqual({ a: "a value" });
  });
  test("Non clonable instances throw error", () => {
    const errorThrown = jest.fn();
    try {
      cloneValue(new Date(), true);
    } catch (e) {
      errorThrown(e);
    }
    expect(errorThrown).toHaveBeenCalledWith(
      expect.objectContaining({
        message: expect.stringContaining("Non clonable instance of class 'Date'"),
      })
    );
  });
  test("Non clonable instances return same reference directly", () => {
    const cloned = new Date("2022/08/25");
    expect(cloneValue(cloned, false)).toBe(cloned);
  });
});
