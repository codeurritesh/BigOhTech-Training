export const StorageKeys = <const>{
  TOKEN: "onesdk-session",
};
