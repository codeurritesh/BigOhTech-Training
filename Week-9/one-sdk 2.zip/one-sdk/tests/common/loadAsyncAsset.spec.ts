import { loadAsyncAsset } from "@module/common/modules/loadAsyncAsset";

describe("loadAsyncAsset", () => {
  beforeEach(() => {
    document.head.innerHTML = "";
    document.body.innerHTML = "";
  });
  test("add script to the body", async () => {
    loadAsyncAsset("https://test-url.com", "script");
    const script = document.body.getElementsByTagName("script")?.[0];
    expect(script).toBeTruthy();
    expect(script.src).toMatch("https://test-url.com");
  });
  test("add script to the head", async () => {
    loadAsyncAsset("https://test-url.com", "style");
    const style = document.head.getElementsByTagName("link")?.[0];
    expect(style).toBeTruthy();
    expect(style.href).toMatch("https://test-url.com");
  });
});
