import type { AccessFunction, AccessorsDictionary } from '@module/common';
import type { EventHub } from '@module/common';
import type { ModuleDefinition } from '@module/common/types';
import type { OCRStatus } from '@module/frankie-client/clients/OCRClient';

import type { Events } from './events';
import type { PartialDeep } from 'type-fest';

export type OCRModule = ModuleDefinition<{
  module: {
    category: 'component';
    name: 'ocr';
    context: {
      mount(domElementOrSelector: string | HTMLElement): void;
      start(): void;
      access: AccessFunction<PublicAccessors>;
      isPreloaded: () => boolean;
      statuses: Readonly<typeof OCRStatus>;
    };
    events: Events;
    options: PartialDeep<Omit<OCRRecipeOptions, 'provider'>>;
    recipe: {
      ocr: OCRRecipeOptions;
    };
  };
  wrapper: {
    vendors: ['dummy-ocr', 'incode', 'onfido'];
    loadType: 'sync';
    options: {
      eventHub: EventHub<Events>;
      mountElement: HTMLElement;
    };
  };
}>;

export type PublicAccessors = AccessorsDictionary<{
  readonly status: OCRStatus;
  readonly isPreloaded: boolean;
}>;

type OCRRecipeOptions = {
  provideReviewScreen?: boolean;
  maxDocumentCount?: number;
  provider:
    | {
    name: 'ocrlabs';
    tx_id: string;
  }
    | {
    name: 'onfido' | 'incode';
    sdkVersion?: string;
  };
};
