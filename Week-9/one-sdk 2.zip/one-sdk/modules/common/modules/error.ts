import { GlobalEvents } from '@module/sdk/types';
import { OneSDKError } from '../errors/OneSDKError.class';
import { EventHub } from './eventHub';

export const mkErrorEmitter = (globalEventHub: EventHub<GlobalEvents>, options: unknown) => (message: string) => {
  globalEventHub.emit('error', new OneSDKError(`${message}. Look for 'payload' in this event object.`, options));
  throw new Error(message);
};
