#!/bin/bash
# If release is a version number v*.*.* with optional suffix -suffix, break it down and use path as vMajor.minor[-suffix]
# argument two might specify extra options
#   --major-only Returns numeric major component, if version string is valid
#   --suffix-only Returns string of suffix component, if version string is valid and contains one
release=$1
option=$2

versionPattern='^v([0-9]+\.)([0-9]+\.)([0-9]+)(-.+)?$'
if [[ $release =~ $versionPattern ]]; then
  vMajor=`echo $release | cut -d'.' -f1`
  minor=`echo $release | cut -d'.' -f2`

  if [[ $option == "--major-only" ]]; then
    echo $vMajor;
    exit;
  fi;

  if [[ $release == *"-"* ]]; then
    suffix=`echo $release | cut -d'-' -f2`;
  else
    suffix=""
  fi

  if [[ $option == "--suffix-only" ]]; then
    echo $suffix;
    exit;
  fi;


  if [ ! -z "$suffix" ]; then vMajorMinor="$vMajor.$minor-$suffix";
  else vMajorMinor="$vMajor.$minor"
  fi;

  echo $vMajorMinor;
# if release name isnt a semver string and caller isnt explicitly requesting a major semver substring
# return the release name itself
elif [ -z "$option" ]; then
  echo $release;
fi;