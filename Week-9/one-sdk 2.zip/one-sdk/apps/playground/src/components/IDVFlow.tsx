import { useEffect, useRef, useState } from 'react';

import type { OneSdkContext } from '@frankieone/one-sdk';
import { IDVStatus, wildcardEventLogger } from '@frankieone/one-sdk';

import { FullScreenContainer } from './LoadingContainer';

const errorStatuses = [
  IDVStatus.PROVIDER_OFFLINE,
  IDVStatus.DOCUMENTS_INVALID,
  IDVStatus.WAITING_DOC_UPLOAD,
  IDVStatus.WAITING_SELFIE_UPLOAD,
  IDVStatus.AWAITING_CONSENT,
];
const failedStatuses = [IDVStatus.FAILED];
const successfulStatuses = [IDVStatus.COMPLETE];
const processingStatuses = [IDVStatus.INCOMPLETE];

export const IDVFlow = ({ oneSdk }: { oneSdk: OneSdkContext }) => {
  const idv = useRef(oneSdk.flow('idv')).current;

  const [mounted, setMounted] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | false>(false);
  const [success, setSuccess] = useState(false);
  const [failed, setFailed] = useState(false);
  const [results, setResults] = useState(null);

  const hasResults = Boolean(results);
  const hasMessage = typeof message === 'string';

  // Interpret results
  const onResultsReceived = (results: {
    checkStatus: IDVStatus;
    message?: string;
  }) => {
    setSuccess(false);
    setMessage(false);
    setFailed(false);
    setResults(results);

    if (successfulStatuses.includes(results.checkStatus)) setSuccess(true);
    if (errorStatuses.includes(results.checkStatus)) setMessage('Error status...');
    if (failedStatuses.includes(results.checkStatus)) setFailed(true);
    if (results.message) setMessage(results.message);
  };

  // Start and end IDV
  const startIDV = () => {
    idv.mount('#idv-el');
  };
  const endIDV = () => {
    setMounted(false);
  };

  // Attach event listeners
  // TODO: Event listeners now do different things based on if "mount" or "start" was called, but here we treat them all the same. Fix that below.
  useEffect(() => {
    idv.on('*', wildcardEventLogger);
    // Before detection
    // 1) When ready to display UI, make sure any change in styles is applied accordingly
    const ready = () => {
      setMounted(true);
    };
    // After detection
    // 2.1) After detection is completed successfully, we can remove additional styles
    const onDetectionComplete = () => setMounted(false);
    // 2.2) Same for detection failed, but with an added error state
    const onDetectionFailed = () => {
      endIDV();
      setMessage('Detection failed');
    };
    // On successful detection
    // 3.1) When results are received, remove loading and additional styles
    // Then we display the results and the Form component
    const onResults = (results) => {
      endIDV();
      onResultsReceived(results);
    };
    // 3.2) When "processing", no results will be displayed as this is an async result
    const onProcessing = () => {
      endIDV();
      setMessage('Processing...');
    };

    // On Error
    // 4.1) input_required suggests you could try running the flow again
    const onInputRequired = (info, status) => {
      endIDV();
      setMessage(`Something didn't go quite well...`);
      setResults({
        checkStatus: status,
      });
    };
    // 4.2) error suggests something really bad happened and trying again isn't going to fix it
    const onError = (e: {
      payload: { errorStatus: IDVStatus };
      message: string;
    }) => {
      endIDV();
      onResultsReceived({
        checkStatus: e.payload.errorStatus,
        message: e.message,
      });
    };
    idv.on('ready', ready);
    idv.on('detection_complete', onDetectionComplete);
    idv.on('detection_failed', onDetectionFailed);
    idv.on('results', onResults);
    idv.on('processing', onProcessing);
    idv.on('input_required', onInputRequired);
    idv.on('error', onError);

    idv.on('loading', setLoading);

    return () => {
      idv.off('ready', ready);
      idv.off('detection_complete', onDetectionComplete);
      idv.off('detection_failed', onDetectionFailed);
      idv.off('results', onResults);
      idv.off('processing', onProcessing);
      idv.off('input_required', onInputRequired);
      idv.off('error', onError);
      idv.off('loading', setLoading);
    };
  }, [idv]);

  return (
    <>
      {success && <h3>Success!</h3>}
      {failed && <h3>Failed!</h3>}
      {message && <h4>{message}</h4>}
      {hasResults && !message && !success && !failed &&
        <h3>No results yet. We will need a manual validation.</h3>}
      {hasResults && <p>{JSON.stringify(results, null, 2)}</p>}
      {
        <button disabled={isLoading || mounted} onClick={startIDV}>
          {isLoading ? 'Loading...' : 'Start IDV Flow'}
        </button>
      }
      <FullScreenContainer id="idv-el" mounted={mounted} loading={isLoading} />
    </>
  );
};
