export function Instructions() {
  return (
    <div>
      <p>
        This playground offers a mocked version of the OneSdk. The UI below mimicks real use case our customers may
        implement themselves. <br />
        As a <b>S</b>oftware <b>D</b>evelopment <b>K</b>it, the SDK doesnt actually provide an application, but only
        some tools with which customers will build their own application. The UI below is a simple program which uses
        the OneSdk, just like customers would.
      </p>
      <h3>How to use it</h3>
      <ol>
        <li>
          Open your browser&apos;s developer tools. Usually you do that pressing f12, or by right clicking anywhere on
          the page and selecting &quot;inspect&quot;;
        </li>
        <li>Look for the tab &quot;Console&quot;</li>
        <li>
          If you&apos;re using Chrome, to the right of the &quot;Filter&quot; input you see a dropdown with &quot;Log
          levels&quot;. Select all of them, but ensure you select &quot;Verbose&quot; in particular; <br />
          This will allow us to see &quot;hidden logs&quot;. If you&apos;re using a different browser, figure out how to
          view all detailed logs.
        </li>
        <li>
          Refresh the page and notice special logs saying &quot;Executing mock request ...&quot;. Those tell you what
          mock requests are occuring, aka what backend functionality is being fake-triggered at that point
        </li>
        <li>
          Another log to keep an eye for is the &quot;data_updated&quot; events, which tells you some internal data was
          changed, either by the OneSdk, or by the user. These are triggered whenever you make any change to any data,
          including changing a single letter in the name field
        </li>
        <li>
          Follow the forms below and keep an eye for those fake requests and error messages in the console. That&apos;s
          how you validate the OneSdk is behaving as expected.
        </li>
        <li>
          Since <b>updateDocument</b> is out of this scope, you can only <b>addDocument</b> for complete document
          details. No &quot;live&quot; data update will happen for documents (aka, no data_updated event for every
          single change. Only when clicking &quot;Add Document&quot;).
        </li>
      </ol>
    </div>
  );
}
