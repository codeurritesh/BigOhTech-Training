const spacing = {
  none: '0px',
  xs: '2px',
  sm: '4px',
  1.5: '6px',
  2: '8px',
  md: '8px',
  lg: '12px',
  xl: '16px',
  '2xl': '20px',
  '3xl': '24px',
  '4xl': '32px',
  '5xl': '56px',
};

const spacingObject = {
  'object-sm': '1.25rem',
  'object-md': '2rem',
  'object-lg': '3rem',
};

const outlineWidth = {
  3: '3px',
};

export default {
  spacing,
  spacingObject,
  outlineWidth,
};
