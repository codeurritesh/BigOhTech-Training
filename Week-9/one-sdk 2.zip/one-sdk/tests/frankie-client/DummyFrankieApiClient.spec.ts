import axios from 'axios';
import mockAxiosInstance from 'jest-mock-axios';

import { mkEventHub } from '@module/common';
import { DummyFrankieApiClient } from '@module/frankie-client/DummyFrankieApiClient';

jest.mock('axios', () => {
  return {
    create: jest.fn().mockImplementation(function () {
      return mockAxiosInstance;
    }),
    AxiosError: jest.fn().mockImplementation(function (statusText, codeString, config) {
      return {
        toJSON: () => ({
          code: codeString,
          message: statusText,
          config,
        }),
      };
    }),
  };
});
describe('Dummy Frankie Client', () => {
  beforeEach(() => {
    mockAxiosInstance.mockClear();
  });
  const mkClient = () => new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
  test('Initialise DummyFrankieApiClient configures axios with dummy base url', async () => {
    const baseURLSetter = jest.fn();
    Object.defineProperty(mockAxiosInstance.defaults, 'baseURL', {
      set: baseURLSetter,
    });
    mkClient();

    expect(axios.create).toHaveBeenCalledWith();
    expect(baseURLSetter).toHaveBeenCalledWith('https://dummy.com');
  });
  test('Initialise DummyFrankieApiClient exposes same methods as FrankieApiClient, but all return empty values', async () => {
    const dummy = mkClient();
    const dummyReturns = {
      data: {},
      headers: {},
      status: 200,
      statusText: 'OK',
    };
    await expect(dummy.get('some-url')).resolves.toMatchObject(dummyReturns);
    await expect(dummy.delete('some-url')).resolves.toMatchObject(dummyReturns);
    await expect(dummy.post('some-url', { data: true })).resolves.toMatchObject(dummyReturns);
    await expect(dummy.put('some-url', { data: true })).resolves.toMatchObject(dummyReturns);
  });
  test('A stub when not found defaults to default values 200 + empty body', async () => {
    const dummy = mkClient();
    dummy.stubResponse(
      { url: '/some-stubbed-url', method: 'put' },
      {
        data: { someStubbedData: 'valuehere' },
        status: 400,
      },
    );

    await expect(dummy.put('/some-different-url')).resolves.toMatchObject({
      data: {},
      status: 200,
    });
  });
  test("It's possible to stub a response for url defined as regex", async () => {
    const dummy = mkClient();
    dummy.stubResponse({ url: /some\/url\/(\d+)/, method: 'put' }, (config) => ({
      data: { testUrl: 'put' + config.url },
      status: 200,
    }));
    dummy.stubResponse({ url: /some\/url\/(\d+)/, method: 'get' }, (config) => ({
      data: { testUrl: 'get' + config.url },
      status: 200,
    }));

    await expect(dummy.put('/some/url/123')).resolves.toMatchObject({
      data: { testUrl: 'put/some/url/123' },
      status: 200,
    });
    // doesn't match, due to the letter A
    await expect(dummy.put('/some/url/123A')).resolves.toMatchObject({
      data: {},
      status: 200,
    });
    await expect(dummy.get('/some/url/123')).resolves.toMatchObject({
      data: { testUrl: 'get/some/url/123' },
      status: 200,
    });
  });
  test('Its possible to stub DummyFrankieApiClient responses without method, which applies to all methods', async () => {
    const dummy = mkClient();
    const response = {
      config: { data: { someStubbedData: true } },
      status: 400,
      statusText: 'Error!',
    };
    const mkError = (method: string) => {
      return {
        config: {
          method,
          url: '/some-stubbed-url',
          data: response.config.data,
        },
        message: response.statusText,
        code: '400',
      };
    };
    dummy.stubResponse({ url: '/some-stubbed-url' }, response);

    await expect(dummy.get('/some-stubbed-url').catch((e) => e.toJSON())).resolves.toEqual(mkError('get'));
    await expect(dummy.put('/some-stubbed-url').catch((e) => e.toJSON())).resolves.toEqual(mkError('put'));
    await expect(dummy.post('/some-stubbed-url').catch((e) => e.toJSON())).resolves.toEqual(mkError('post'));
    await expect(dummy.delete('/some-stubbed-url').catch((e) => e.toJSON())).resolves.toEqual(mkError('delete'));
  });
  test("It's possible to stub DummyFrankieApiClient responses for specific methods", async () => {
    const dummy = mkClient();
    dummy.stubResponse(
      { url: '/some-stubbed-url', method: 'put' },
      {
        data: { someStubbedData: 'valuehere' },
        status: 400,
        statusText: 'ERROR!',
      },
    );

    const errorPromise = dummy.put('/some-stubbed-url').catch((e) => {
      throw e.toJSON();
    });
    await expect(errorPromise).rejects.toMatchObject({
      code: '400',
      message: 'ERROR!',
    });
    await expect(dummy.get('/some-stubbed-url')).resolves.toMatchObject({
      data: {},
      status: 200,
    });
  });

  test("It's possible to stub redirects for side effects only, which cancels the redirection", () => {
    const dummy = mkClient();
    const sideEffect = jest.fn();
    dummy.stubResponse({ url: 'www.google.com', method: 'redirect' }, () => {
      sideEffect();
      return null;
    });

    dummy.redirect(new URL('http://www.google.com'));

    expect(sideEffect).toHaveBeenCalled();
  });
  test("It's possible to stub redirects for mapping to a different url", () => {
    const dummy = mkClient();
    const sideEffect = jest.fn();
    dummy.stubResponse({ url: 'www.google.com', method: 'redirect' }, () => {
      sideEffect();
      return new URL('https://www.different.url');
    });

    dummy.redirect(new URL('http://www.google.com'));

    expect(sideEffect).toHaveBeenCalled();
    expect(window.location).toBeAt('https://www.different.url');
  });
  test("It's possible to stub redirects using url as regex pattern", () => {
    const dummy = mkClient();
    const sideEffect = jest.fn();
    dummy.stubResponse({ url: /www.+/, method: 'redirect' }, (url: URL) => {
      sideEffect(url);
      return new URL('https://www.different.url');
    });

    dummy.redirect(new URL('http://www.google.com'));

    expect(sideEffect).toHaveBeenCalledWith(new URL('http://www.google.com/'));
    expect(window.location).toBeAt('https://www.different.url');
  });
});
