import { config } from "dotenv-flow";

config();
// Add missing "orientation" to native readonly object "screen"
// readonly objects need to be reinjected first, so they are not readonly anymore
// before injecting new properties
const originalScreen = window.screen;
delete window.screen;
Object.defineProperty(originalScreen, "orientation", {
  value: {
    type: "landscape-primary",
  },
});
Object.defineProperty(window, "screen", {
  value: originalScreen,
});
