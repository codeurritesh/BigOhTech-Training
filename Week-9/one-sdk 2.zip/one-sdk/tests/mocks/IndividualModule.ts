import type { IndividualModule } from '@frankieone/one-sdk';
import type { Dictionary } from '@types';

import { mockAcessorsDictionary } from './ReactiveStore';

export function mockIndividualModule(opts?: { accessState: Dictionary }) {
  const publicAccessors = mockAcessorsDictionary(opts?.accessState ?? {});
  return {
    addDocument: jest.fn(),
    updateDocument: jest.fn(),
    access: (fieldname: string) => publicAccessors[fieldname] ?? {},
    search: jest.fn().mockResolvedValue({}),
    addConsent: jest.fn(),
    addAddress: jest.fn(),
    updateAddress: jest.fn(),
    isPersisted: jest.fn(),
    submit: jest.fn(),
  } as unknown as IndividualModule['moduleContext'];
}
