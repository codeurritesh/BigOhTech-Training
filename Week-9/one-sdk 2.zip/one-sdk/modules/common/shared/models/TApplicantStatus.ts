import { TStatusType } from "./api";

export type TApplicantStatus = { type: TStatusType | null; label: string; key: string; action?: string };
