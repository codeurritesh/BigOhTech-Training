import { KvpList } from "../models/KvpList";
import { IIssue, IIssueAction, TIssueType } from "../models/TApplicantIssue";

export function mapBackendAlert(backendTerm: string): IIssue | IIssueAction {
  let term: string = backendTerm.toLowerCase(),
    type: TIssueType = "alert";
  const extra: any = {};

  switch (term) {
    case "fraud":
    case "frd":
      term = "fraud";
      break;
    case "partial":
    case "p":
    case "ptl":
      term = "partial";
      break;
    case "media":
    case "m":
      term = "media";
      break;
    case "watchlist":
    case "watchlists":
    case "wl":
      term = "watchlist";
      break;
    case "sanctions":
    case "sanction":
    case "s":
      term = "sanction";
      break;
    case "blacklist":
    case "bl":
      term = "blacklist";
      break;
    case "duplicate":
    case "dup":
      term = "duplicate";
      break;
    case "risk":
    case "rsk":
      term = "rsk";
      break;
  }

  // categorize terms
  if (["media", "m"].includes(term)) type = "warning";

  if (
    [
      "404",
      "500",
      "sanctions",
      "s",
      "sanction",
      "error",
      "404",
      "500",
      "ptl",
      "watchlist",
      "wl",
      "pep",
      "partial",
      "kyc",
      "att-pht",
      "att-idv",
      "fraud",
    ].includes(term)
  )
    type = "alert";

  if (["duplicate", "blacklist", "bl", "dup"].includes(term)) {
    type = "action";

    switch (term) {
      case "duplicate":
      case "dup":
        extra.label = "Duplicate";
        extra.action = "duplicate";
        break;
      case "blacklist":
      case "bl":
        extra.label = "Blocklist";
        extra.action = "blacklist";
        break;
    }
  }

  if (["clear"].includes(term)) type = "success";

  for (let i = 1; i < 5; i++) {
    if ([`pepclass${i}`, `pep-class-${i}`].includes(term)) term = `pep-class-${i}`;
  }
  /// make term variations consistent

  const alert: IIssue = {
    term,
    type,
  };
  if (alert.type === "action") {
    (alert as IIssueAction).extra = extra;
  }
  return alert;
}
export const appendIssueWhenMissingCheck = (extraData: KvpList, alertList: (IIssue | IIssueAction)[]) => {
  if (alertList.length !== 0) return; //only append missing check when there is nothing on the alertList
  //Do a check for kvp MissingChecks, if it is missing pep or pep_media, it will show the alert message, AML hasn't performed
  const missingChecks = extraData.findKvpValue("Info.MissingChecks") || "";
  if (["pep", "pep_media"].find((term) => missingChecks.match(term))) {
    alertList.push(mapBackendAlert("missing_check"));
  }
};
