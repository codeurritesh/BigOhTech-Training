// This import is only used internally. DummyFrankieApiClient is not exported from OneSDK
import jwtEncode from 'jwt-encode';
import { useState, useEffect } from 'react';

import type {
  Accessors,
  ReadonlyAccessors,
  Environments,
  OneSdkConfiguration,
  FrankieApiClient,
} from '@frankieone/one-sdk';
import OneSdk, { DummyFrankieApiClient, SdkMode } from '@frankieone/one-sdk';

export const telemetryEventLogger = ({ eventName, ...payload }) => console.log('telemetry', eventName, payload);
// We should provide the hook similar to below "useIndividualField"
export const useOneSdkState = <T>(accessors: Accessors<T>): [T, (v: T) => void] => {
  const { observable, setValue, getValue } = accessors;
  const [state, setState] = useState<T>(getValue());

  useEffect(() => {
    const subscription = observable.subscribe((value) => setState(value));
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return [state, setValue];
};
export const useReadonlyOneSdkState = <T>(accessors: ReadonlyAccessors<T>): T => {
  const { observable, getValue } = accessors;
  const [state, setState] = useState<T>(getValue());

  useEffect(() => {
    const subscription = observable.subscribe((value) => setState(value));
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return state;
};
export type FrankieSessionOptions = {
  environment: Environments;
  appReference: string;
} & Partial<{
  useRandomReference: boolean; // true only
  useEntityId: string;
  useReference: string;
  preset: string;
}>;
export function mkFrankieSession(
  mode: OneSdkConfiguration['mode'],
  options: FrankieSessionOptions,
): Promise<{ token: string }> {
  const modeName = typeof mode === 'string' ? mode : mode.modeName;
  const { useEntityId, useReference } = options;
  const sessionCredentials = useEntityId
    ? { entityId: useEntityId }
    : useReference
    ? { reference: useReference }
    : { reference: `onesdk-${new Date().toISOString()}` };

  let frankie: FrankieApiClient;
  if (modeName === SdkMode.DUMMY) {
    // Using Dummy client so this request is also logged with the other internal dummy requests
    const dummy = new DummyFrankieApiClient({ globalEventHub: OneSdk.utils.mkEventHub() });

    dummy.stubResponse(
      { url: '/auth/v2/machine-session', method: 'post' },
      {
        title: 'Create session with entity id',
        data: {
          token: jwtEncode(
            {
              data: {
                environment: 'https://some-environment.com',
                sessionId: `some-session-id-${Math.random().toString(16).substring(2, 12)}`,
                ...sessionCredentials,
                organisation: {
                  customerId: 'customer-id',
                },
              },
            },
            'secret',
          ),
        },
      },
    );
    frankie = dummy;
  } else frankie = new OneSdk.FrankieApiClient();

  return frankie
    .login(
      {
        customerID: process.env.PUBLIC_CUSTOMER_ID,
        customerChildID: process.env.PUBLIC_CUSTOMER_CHILD_ID,
        apiKey: process.env.PUBLIC_CUSTOMER_API_KEY,
      },
      sessionCredentials,
      { environment: options.environment, preset: options.preset },
    )
    .then((t) => ({ token: t }));
}
