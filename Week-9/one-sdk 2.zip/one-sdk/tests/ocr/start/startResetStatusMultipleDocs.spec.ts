import { Document } from '@module/common/shared/models/Document';
import { OCRStatus } from '@module/frankie-client/clients/OCRClient';
import { resetCurrentStatus } from '@module/ocr/actions/start';
import { mockAccessors } from '@tests/mocks/ReactiveStore';

import { mkStartMethod } from './utils';

describe('start::reset status with maxDocumentCount provided', () => {
  test('When maxDocumentCount is 2, and 2 OCR documents (DL and DL) are found, expect to load the latest document with its ocr status (WAITING_BACK)', async () => {
    const {
      dependencies,
      status$,
      document$,
      isPreloaded$,
      individual,
    } = mkStartMethod({ maxDocumentCount: 2 });
    const documentsData = [
      [
        'test-id1',
        'DRIVERS_LICENCE',
        OCRStatus.COMPLETE,
        '2023-10-16T02:00:00Z',
      ],
      [
        'test-id2',
        'DRIVERS_LICENCE',
        OCRStatus.WAITING_BACK,
        '2023-10-16T03:00:00Z',
      ],
    ] as const;
    const documents = documentsData.map(([id, idType, ocrStatus, runDate]) => {
      const document = new Document();
      document.documentId = id;
      document.idType = idType;
      document.ocrResult = {
        status: ocrStatus,
        runDate,
      };
      document.verified = { manual: null, electronic: null };
      return document;
    });
    individual.access.mockImplementation(() =>
      mockAccessors({ documents }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_BACK);
    expect(document$.setValue).toHaveBeenCalledWith(documents[1]);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(true);
  });
  test('When maxDocumentCount is 2, and 2 OCR documents (PASSPORT and DL) are found, expect to load the latest document with its ocr status (WAITING_BACK)', async () => {
    const {
      dependencies,
      status$,
      document$,
      isPreloaded$,
      individual,
    } = mkStartMethod({ maxDocumentCount: 2 });
    const documentsData = [
      ['test-id1', 'PASSPORT', OCRStatus.COMPLETE, '2023-10-16T02:00:00Z'],
      [
        'test-id2',
        'DRIVERS_LICENCE',
        OCRStatus.WAITING_BACK,
        '2023-10-16T03:00:00Z',
      ],
    ] as const;
    const documents = documentsData.map(([id, idType, ocrStatus, runDate]) => {
      const document = new Document();
      document.documentId = id;
      document.idType = idType;
      document.ocrResult = {
        status: ocrStatus,
        runDate,
      };
      document.verified = { manual: null, electronic: null };
      return document;
    });
    individual.access.mockImplementation(() =>
      mockAccessors({
        documents: [...documents],
      }),
    );
    individual.access.mockImplementation(() =>
      mockAccessors({ documents }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_BACK);
    expect(document$.setValue).toHaveBeenCalledWith(documents[1]);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(true);
  });
  test('When maxDocumentCount is 2, and 2 OCR documents are found,  expect to load the latest document with its ocr status (WAITING_FRONT)', async () => {
    const {
      dependencies,
      status$,
      document$,
      isPreloaded$,
      individual,
    } = mkStartMethod({ maxDocumentCount: 2 });
    const documentsData = [
      ['test-id1', OCRStatus.COMPLETE, '2023-10-16T02:00:00Z'],
      ['test-id2', OCRStatus.WAITING_FRONT, '2023-10-16T03:00:00Z'],
    ] as const;
    const documents = documentsData.map(([id, ocrStatus, runDate]) => {
      const document = new Document();
      document.documentId = id;
      document.ocrResult = {
        status: ocrStatus,
        runDate,
      };
      document.verified = { manual: null, electronic: null };
      return document;
    });
    individual.access.mockImplementation(() =>
      mockAccessors({ documents }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(documents[1]);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(true);
  });
  test('When maxDocumentCount is 3, and 2 OCR completed documents are found, expect to start a new flow', async () => {
    const {
      dependencies,
      status$,
      document$,
      isPreloaded$,
      individual,
    } = mkStartMethod({ maxDocumentCount: 3 });
    const documentsData = [
      ['test-id1', OCRStatus.COMPLETE, '2023-10-16T02:00:00Z'],
      ['test-id2', OCRStatus.COMPLETE, '2023-10-16T03:00:00Z'],
    ] as const;
    const documents = documentsData.map(([id, ocrStatus, runDate]) => {
      const document = new Document();
      document.documentId = id;
      document.ocrResult = {
        status: ocrStatus,
        runDate,
      };
      document.verified = { manual: null, electronic: null };
      return document;
    });
    individual.access.mockImplementation(() =>
      mockAccessors({ documents }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(new Document());
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(false);
  });
  test('When maxDocumentCount is 2, and 1 existing complete OCR document is found, expect to start a new flow', async () => {
    const {
      dependencies,
      status$,
      document$,
      isPreloaded$,
      individual,
    } = mkStartMethod({ maxDocumentCount: 2 });
    const document = new Document();
    document.documentId = 'test-id';
    document.ocrResult = {
      status: OCRStatus.COMPLETE,
    };
    document.verified = { manual: null, electronic: null };
    individual.access.mockImplementation(() =>
      mockAccessors({ documents: [document] }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(new Document());
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(false);
  });
  test('When maxDocumentCount is 1, and 1 existing complete OCR document is found, expect to load that document', async () => {
    const {
      dependencies,
      status$,
      document$,
      isPreloaded$,
      individual,
    } = mkStartMethod({ maxDocumentCount: 1 });
    const document = new Document();
    document.documentId = 'test-id';
    document.ocrResult = {
      status: OCRStatus.COMPLETE,
    };
    document.verified = { manual: null, electronic: null };
    individual.access.mockImplementation(() =>
      mockAccessors({ documents: [document] }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.COMPLETE);
    expect(document$.setValue).toHaveBeenCalledWith(document);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(true);
  });
  test('When maxDocumentCount is 1, and 1 existing uncompleted OCR document is found, expect to load that document', async () => {
    const {
      dependencies,
      status$,
      document$,
      isPreloaded$,
      individual,
    } = mkStartMethod({ maxDocumentCount: 1 });
    const document = new Document();
    document.documentId = 'test-id';
    document.ocrResult = {
      status: OCRStatus.WAITING_FRONT,
    };
    document.verified = { manual: null, electronic: null };
    individual.access.mockImplementation(() =>
      mockAccessors({ documents: [document] }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(document);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(true);
  });
  test(`When maxDocumentCount is -1, and 1 existing complete OCR document is found, expect to start a new flow`, async () => {
    const {
      dependencies,
      status$,
      document$,
      isPreloaded$,
      individual,
    } = mkStartMethod({ maxDocumentCount: -1 });
    const document = new Document();
    document.documentId = 'test-id';
    document.ocrResult = {
      status: OCRStatus.COMPLETE,
    };
    document.verified = { manual: null, electronic: null };
    individual.access.mockImplementation(() =>
      mockAccessors({ documents: [document] }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(new Document());
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(false);
  });
});
