declare module '*.scss' {
  const contents: string;
  // eslint-disable-next-line import/no-default-export
  export default contents;
}
declare module '*.css' {
  const contents: string;
  // eslint-disable-next-line import/no-default-export
  export default contents;
}
declare module '*.html' {
  const contents: string;
  // eslint-disable-next-line import/no-default-export
  export default contents;
}
