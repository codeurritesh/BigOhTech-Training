import { CDN_URL, VERSION_PLACEHOLDER, BFF_URL } from '../constants';

export async function loadOneSDK(cdnVersion: string): Promise<OneSdk> {
  const script = document.createElement('script');
  script.src = CDN_URL.replace(VERSION_PLACEHOLDER, cdnVersion);
  script.async = true;
  document.body.appendChild(script);
  return new Promise((resolve, reject) => {
    script.onload = () => resolve(window.OneSdk);
    script.onerror = reject;
  });
}
export async function exchangeShortToken(shortToken: string | null) {
  if (!shortToken) throw new Error('Not authorized');

  const response = await fetch(`${BFF_URL}/auth/v1/sessions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `delegate ${shortToken}`,
    },
    body: JSON.stringify({}),
  });

  return response.headers.get('token')!;
}
