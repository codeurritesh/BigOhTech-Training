import { Document } from '@module/common/shared/models/Document';
import type {
  FormIOOnboardingDataScheme,
} from '@module/form/vendors/formio/formioSdk';
import {
  assignFormioDataToIndividualModule,
} from '@module/form/vendors/formio/transformers/assignFormioDataToIndividualModule';
import { mockIndividualModule } from '@tests/mocks/IndividualModule';

describe('transformerFormioToIndividualModule', () => {
  test('Complete formio data', () => {
    const individualModule = mockIndividualModule({
      accessState: {
        name: {
          givenName: 'firstName',
          familyName: 'lastName',
          middleName: 'middleName',
        },
        dateOfBirth: '2000-10-10',
        documents: [],
        addresses: [],
      },
    });
    assignFormioDataToIndividualModule(
      {
        basicPiiForm: {
          data: {
            entityId: 'entityId',
            firstName: 'firstName',
            middleName: 'middleName',
            lastName: 'lastName',
            dateOfBirth: '2000-10-10',
          },
        },
        documents: [
          {
            genericDocument: {
              data: {
                documentId: 'documentId',
                idType: 'DRIVERS_LICENCE',
                issuingCountry: 'issuingCountry',
                dl_region: 'dl_region',
                dl_idNumber: 'dl_idNumber',
                dl_cardNumber: 'dl_cardNumber',
              },
            },
          },
        ],
        addressComponentForm: {
          data: {
            useManualAddress: false,
            residentialAddress: {
              formatted_address: 'formatted_address',
              address_components: [
                {
                  long_name: 'Australia',
                  short_name: 'AU',
                  types: ['country'],
                },
              ],
            },
          },
        },
      } as FormIOOnboardingDataScheme,
      individualModule,
    );
    // test accessors setValue function called for each field
    expect(individualModule.access('name').setValue).toHaveBeenCalledWith({
      givenName: 'firstName',
      familyName: 'lastName',
      middleName: 'middleName',
      displayName: '',
    });
    expect(individualModule.access('dateOfBirth').setValue).toHaveBeenCalledWith('2000-10-10');
    expect(individualModule.updateDocument).toHaveBeenCalledWith(
      'documentId',
      expect.objectContaining(
        Object.assign(new Document(), {
          idType: 'DRIVERS_LICENCE',
          country: 'issuingCountry',
          documentId: 'documentId',
          region: 'dl_region',
          idNumber: 'dl_idNumber',
          extraData: {
            document_number: 'dl_cardNumber',
          },
        }),
      ),
    );
    expect(individualModule.addAddress).toHaveBeenCalledWith(
      expect.objectContaining({
        longForm: 'formatted_address',
        country: 'AUS',
      }),
    );
  });
});
