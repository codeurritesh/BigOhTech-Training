import type { EventHub, EventsDictionary } from '@module/common/modules/eventHub';
import type { Dictionary, EmptyObject, Field } from '@types';

import type { ModuleCategory } from './categories';
import type { ModuleContext, ModuleInstance } from './contextObject';
import type { ModuleInitialiseFunction } from './initialiseFunction';
import type { WrapperInitialiseFunction } from '../oneSDKVendorWrappers';

/**
 * Provide a type-safe way to define all details about a module in a single location.
 * ModuleDefinition takes a clear object type where all the module's details are defined, relabels them so they are more easily accessed later (no nesting) and
 * infer other types such as the initialise functions
 */
export type ModuleDefinition<Definition extends Parameters = Parameters> = {
  moduleName: Field<Definition, 'module', 'name'>;
  category: Field<Definition, 'module', 'category'>;
  /** All the options exclusive to this module. This is the same object passed as a second argument to the factory functions
   * "component" and "flow" */
  moduleOptions: Field<Definition, 'module', 'options', undefined>;
  /** The definition of the object returned by the 'raw' module initialisation function. This doesn't
   * include the extra context injected by 'defineModule' */
  moduleContext: Field<Definition, 'module', 'context'>;
  moduleEvents: Field<Definition, 'module', 'events', Dictionary<never>>;
  /** Module instance, defined by joining 'moduleContext' + event listener for the events in 'moduleEvents' and 'instanceName', defined at runtime */
  moduleInstance: ModuleInstance<
    ModuleContext<Field<Definition, 'module', 'context'>, Field<Definition, 'module', 'events'>>
  >;
  /** Union of strings representing the different vendor names for this module.
   *  The provided array will be transformed to a union type, so this can be used as a type, or default to undefined */
  vendorName: Field<Definition, 'wrapper', 'vendors', undefined, Field<Definition, 'wrapper', 'vendors'>[number]>;
  /** All the options provided to the vendor wrappers under this module. All wrappers take the same options, if any. */
  wrapperOptions: Field<Definition, 'wrapper', 'options', undefined>;
  /** The definition of the object that must be returned by the wrapper initilise function. Not all modules require extended
   * interactions with wrappers beyond initialisation, so they might not require an object to interact with them and may simply be 'void'. */
  wrapperContext: Field<Definition, 'wrapper', 'context', void>;
  /** Wrappers will be asynchronous most of the time, but just in case a wrapper initialisation function needs to be synchronous, that can be set here. */
  wrapperLoadType: Field<Definition, 'wrapper', 'loadType', 'sync'>;
  /** The subset of the recipe configuration expected by this module */
  recipeConfiguration: Field<Definition, 'module', 'recipe', Dictionary<unknown>>;
  // TODO: Remove definition for initialisation functions below and convert them into types that take ModuleDefinition as a parameter
  /** The module's initialise function, before it has extra parameters injected by 'defineModule' */
  moduleInitialiseFunction: ModuleInitialiseFunction<
    Field<Definition, 'module', 'category'>,
    ExtendedModuleContext<
      Field<Definition, 'module', 'category'>,
      Field<Definition, 'module', 'events'>,
      Field<Definition, 'module', 'context'>
    >,
    Field<Definition, 'module', 'options', void>
  >;
  wrapperInitialiseFunction: WrapperInitialiseFunction<
    Field<Definition, 'wrapper', 'options', undefined>,
    Field<Definition, 'wrapper', 'context', void>,
    Field<Definition, 'wrapper', 'loadType'>,
    InjectedModuleParameters<
      Field<Definition, 'module', 'category'>,
      Field<Definition, 'module', 'events'>,
      Field<Definition, 'module', 'recipe'>
    >
  >;
};
// TODO: Field helper isn't working. Check todo in utilities.types.ts
// Potentially return to old implementation

// Module definition parameters
// Parameters are split in module and wrapper
// Wrapper parameters are optional, as not every module actually wraps a vendor
// Note: The type of any missing field is defined as "unknown". Read more about optional types below.
//
// Some of the nested parameters may be optional. In that case, simply
//    1) make it optional by adding a "?" after its name
//    2) declare the type it would take in case it were provided
//    3) Choose a default type for it using the helper "Default"
//
//    OBS:  Don't attempt to include the default type for optional fields with a "default parameter syntax" ie: "A extends B = defaultType"

type Parameters = {
  module: ModuleSignature;
  wrapper?: WrapperSignature;
};
type ModuleSignature = {
  category: ModuleCategory;
  name: string;
  options?: Dictionary;
  context: object;
  events?: EventsDictionary;
  recipe?: Dictionary;
};
type WrapperSignature = {
  vendors: string[];
  options?: Dictionary;
  context?: unknown;
  loadType?: 'sync' | 'async';
};

// TODO: Review if types below can be improved or removed all together. These can be removed once the initialisation function is removed from ModuleDefinition
// We can probably remove them when we remove the "private" and "setup" categories

/** Any extra parameters that may be injected into the initialise function by "defineModule" should be present below */
export type InjectedModuleParameters<
  Cat,
  Events extends EventsDictionary,
  Recipe extends Dictionary = EmptyObject,
> = Cat extends CategoryWithListener
  ? {
      localEventHub: EventHub<Events>;
      recipe: Recipe;
    }
  : object;
type CategoryWithListener = 'component' | 'flow' | 'private';
/**
 * Logic for resolving a module's context object based on their category
 * If category is either "component", "flow", or "private", wrap provided context in ModuleContext (add common methods to it)
 * Otherwise, use the provided context as is
 */
type ExtendedModuleContext<
  Cat extends ModuleCategory,
  Events extends EventsDictionary,
  Context extends object,
> = Cat extends CategoryWithListener ? ModuleContext<Context, Events> : Context;
