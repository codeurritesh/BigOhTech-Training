import type { OneSdkContext } from '@frankieone/one-sdk';
import OneSdk from '@frankieone/one-sdk';
import type { EventHub } from '@module/common';
import type { Applicant } from '@module/common/shared/models/Applicant';
import type { InjectedState, ModeObject } from '@module/common/types';
import { getInitialiser } from '@module/config/modules';
import { ApplicantClient } from '@module/frankie-client/clients/ApplicantClient';
import type IndividualModule from '@module/individual';
import { SessionContext } from '@module/session/SessionContext';
import { mockFrankieClient } from '@tests/mocks/FrankieClient';
import { mockSessionContext } from '@tests/mocks/SessionContext';
import { optionalParameters } from '@tests/testUtils/functionUtilities';
import { jwtWithReference } from '@tests/testUtils/tokens';

const InitialiseIndividual = optionalParameters<typeof IndividualModule>(
  jest.requireActual('@module/individual').default,
);
const mockedInitialiseIndividual = jest.fn().mockReturnValue({ on: (_, cb: () => void) => cb() });

jest.mock('@module/config/modules', () => ({
  getInitialiser: jest.fn().mockImplementation((key: string) => {
    if (key === 'individual') {
      return mockedInitialiseIndividual;
    }
    if (key === 'session') return () => mockSessionContext();
    return jest.fn();
  }),
}));

describe('Individual initialisation', () => {
  test('Initialising OneSdk initialises Individual module internally as a singleton', async () => {
    await OneSdk({
      mode: OneSdk.modes.DUMMY,
      session: {
        token: jwtWithReference,
      },
    });

    expect(getInitialiser).toHaveBeenCalledWith('individual');
    expect(mockedInitialiseIndividual).toHaveBeenCalledWith(
      expect.objectContaining(<InjectedState>{
        oneSdkInstance: expect.any(Object),
        frankieClient: expect.any(Object),
        globalEventHub: expect.any(Object),
        mode: expect.objectContaining({ modeName: expect.any(String) }),
        recipe: expect.objectContaining({ name: expect.any(String) }),
        session: expect.any(SessionContext),
        telemetry: true,
      }),
    );
  });
  test('During initialisation, individual module will attempt to load any existing applicant', async () => {
    const mockedLoadMethod = jest.spyOn(ApplicantClient.prototype, 'load').mockResolvedValue({
      applicant: <Applicant>{},
      documents: [],
    });
    const { frankieClient } = mockFrankieClient({ sessionType: 'entityId' });
    InitialiseIndividual({
      frankieClient,
      recipe: {
        name: 'auto',
      },
      session: {} as SessionContext,
      globalEventHub: {} as EventHub,
      mode: {} as ModeObject,
      oneSdkInstance: {} as OneSdkContext,
      telemetry: false,
    });

    expect(mockedLoadMethod).toHaveBeenCalled();
  });
});
