export type UserPayload = User;
export interface User {
  id: number;
  organizationId: number | null;
  username: string;
  password: string;
  salt: string;
  realname: string | null;
  email: string;
  isActive: boolean;

  // @Column("timestamp without time zone", {
  //   name: "logged_at",
  //   nullable: true,
  //   default: () => "NULL::timestamp without time zone"
  // })
  // loggedAt: Date | null;

  // @Column("timestamp without time zone", { name: "created_at" })
  // createdAt: Date;

  // @Column("timestamp without time zone", {
  //   name: "updated_at",
  //   nullable: true,
  //   default: () => "NULL::timestamp without time zone"
  // })
  // updatedAt: Date | null;

  // @Column("timestamp without time zone", {
  //   name: "deleted_at",
  //   nullable: true,
  //   default: () => "NULL::timestamp without time zone"
  // })
  // deletedAt: Date | null;

  // @Column("boolean", { name: "is_locked", default: () => "false" })
  // isLocked: boolean;

  // @Column("smallint", { name: "psw_wrong_attempts_count", default: () => "0" })
  // pswWrongAttemptsCount: number;

  // @Column("uuid", { name: "latest_child_viewed", nullable: true })
  // latestChildViewed: string | null;

  // @OneToMany(
  //   () => PasswordHistory,
  //   passwordHistory => passwordHistory.user,
  //   { eager: true }
  // )
  // passwordHistory: PasswordHistory[];

  // @ManyToMany(
  //   () => Role,
  //   role => role.users,
  //   { eager: true }
  // )
  // roles: Role[];

  // @ManyToOne(
  //   () => Organization,
  //   organization => organization.users,
  //   { eager: true }
  // )
  // @JoinColumn([{ name: "organization_id", referencedColumnName: "id" }])
  // organization: Organization;

  // get activeOrganization(): Organization | null {
  //   // is parent viweing as child, so return latest child organization
  //   let org: Organization | null;
  //   if(!this.isChildOrganization && !!this.isViewingAsChild) {
  //     const findOrganizationByChildId = o => o.customerChildId === this.latestChildViewed;
  //     org = this.organization.children.find(findOrganizationByChildId) || null;
  //   // otherwise return organization id
  //   } else {
  //     org = this.organization;
  //   }
  //   return org;
  // }
  // get isChildOrganization(): boolean {
  //   return this.organization?.isChildOrganization;
  // }
  // get isViewingAsChild() : boolean {
  //   return (!!this.isChildOrganization || !!this.latestChildViewed);
  // }
  // get activeChildId() : string | null {
  //   if (this.isChildOrganization) {
  //     return <string>this.organization.customerChildId;
  //   } else {
  //     return this.latestChildViewed || null;
  //   }
  // }
  // get activeOrganizationId(): number | null {
  //   // is parent viweing as child, so return latest child organization id
  //   return this.activeOrganization?.id || null;
  // }
  // get actions() {
  //   const actions = this.roles?.reduce((arr: string[], role) => {
  //     const localActions = role.permissions.map(p => p.action);
  //     arr.push(...localActions);
  //     return arr;
  //   }, []);
  //   return actions;
  // }
  // get roleNames() {
  //   return this.roles?.map(r => r.role) || [];
  // }
  // hasPermission(action: string) {
  //   return this.actions.includes(action);
  // }
  // hasRole(role: string) {
  //   return this.roleNames.includes(role);
  // }
  // toJSON(){
  //   return {
  //     id: this.id,
  //     organizationId: this.organizationId,
  //     username: this.username,
  //     realname: this.realname,
  //     email: this.email,
  //     roles: this.roleNames,
  //     actions: this.actions,
  //     isChildOrganization: this.isChildOrganization,
  //     activeChildCustomerId: this.latestChildViewed,
  //     locked: this.isLocked,
  //     isActive: this.isActive,
  //     loggedAt: {
  //       date: this.updatedAt
  //     },
  //     createdAt: {
  //       date: this.createdAt
  //     }
  //   }
  // }
  // static async getUserAndOrganizationByUsername(username: string): Promise<User | undefined> {
  //   const db = LocalDBService.getInstance();
  //   const repository = db.getRepository<User>(User);
  //   const organizationRepository = db.getRepository<Organization>(Organization);
  //   const user: User | undefined = await repository.findOne({
  //     where: {
  //       username,
  //       isActive: true,
  //       deletedAt: null
  //     }
  //   });

  //   if (user && user.organization) {
  //     const organization = (await organizationRepository.findOne({
  //       where: {
  //         id: user.organization.id
  //       }
  //     }));
  //     if(!organization) return user

  //     const children = await (async () => {
  //       if (organization && organization.isChildOrganization) return [];
  //       return organizationRepository.find({
  //         where: {
  //           customerId: organization?.customerId,
  //           customerChildId: Not(IsNull())
  //         }
  //       });
  //     })();
  //     const parent = (await organizationRepository.findOne({
  //       where: {
  //         id: user.organization?.parentId
  //       }
  //     }))!;
  //     const users = (await repository.find({
  //       where: {
  //         organizationId: organization?.id,
  //         deletedAt: IsNull()
  //       }
  //     }));

  //       organization.parent = parent;
  //       organization.children = children;
  //       organization.users = users;
  //       user.organization = organization;

  //   }

  //   return user;
  // }
}


export type TUser = {
  id?: number;
  organizationId?: number | null;
  username?: string;
  password?: string;
  realname?: string | null;
  email?: string;
  isActive?: boolean;
  loggedAt?: Date | null;
  createdAt?: Date;
  updatedAt?: Date | null;
  deletedAt?: Date | null;
  isLocked?: boolean;
  latestChildViewed?: string | null;
  [field: string] : any;
}