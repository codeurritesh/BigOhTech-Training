import { AxiosError } from 'axios';

import type { EventHub } from '@module/common';
import { mkEventHub } from '@module/common';
import type { InjectedState, ModeObject } from '@module/common/types';
import {
  getSingpassURL,
  hasAllAuthorisationParams,
  initialise as wrapperInitialise,
} from '@module/federation/vendors/Singpass';
import type { FrankieApiClient } from '@module/frankie-client';
import type { OneSdkContext, RecipeParsed } from '@module/sdk/types';
import type { SessionContext } from '@module/session/SessionContext';
import { mockEventHub } from '@tests/mocks/EventHub';
import { optionalParameters } from '@tests/testUtils/functionUtilities';
import type { AnyFunction } from '@types';

import { waitFor } from '../testUtils/asyncUtils';

import type { AxiosResponse } from 'axios';

const wrapper = optionalParameters(wrapperInitialise);

describe('Federation Singpass', () => {
  test('Without any of the expected params, Singpass wrapper redirects to singpass login. Production environment.', () => {
    const singpassConfig = {
      environment: 'production',
      redirect_url: 'https://redirect.com',
      client_id: 'client_id-value',
      attributes: 'attributes-value',
      purpose: 'purpose-value',
    };
    const redirect = jest.fn();
    window.location.href = 'http://www.address.com';
    wrapper(
      {
        frankieClient: <FrankieApiClient>(<unknown>{
          redirect,
        }),
        session: <SessionContext>{ sessionId: 'sessionId-value' },
        recipe: <RecipeParsed>{
          idps: {
            singpass: singpassConfig,
          },
        },

        globalEventHub: {} as EventHub,
        localEventHub: {} as EventHub,
        mode: {} as ModeObject,
        moduleMeta: {
          instanceName: '',
          moduleName: 'federation',
        },
        oneSdkInstance: {} as OneSdkContext,

        telemetry: false,
      },
      {
        eventHub: mkEventHub(),
      },
    );
    const url = redirect.mock.calls[0][0] as URL;
    expect(url.origin).toBe('https://api.myinfo.gov.sg');
    expect(url.searchParams.get('redirect_uri')).toBe(singpassConfig.redirect_url);
    expect(url.searchParams.get('client_id')).toBe(singpassConfig.client_id);
    expect(url.searchParams.get('attributes')).toBe(singpassConfig.attributes);
    expect(url.searchParams.get('purpose')).toBe(singpassConfig.purpose);
  });
  test('Environment x url mapping', () => {
    expect(getSingpassURL('production')).toEqual(new URL('https://api.myinfo.gov.sg/com/v3/authorise'));
    expect(getSingpassURL('test')).toEqual(new URL('https://test.api.myinfo.gov.sg/com/v3/authorise'));
    expect(getSingpassURL('sandbox')).toEqual(new URL('https://sandbox.api.myinfo.gov.sg/com/v3/authorise'));
  });

  test('Authorisation failing with errorCode is emitted with the error event', async () => {
    const params = new URLSearchParams();
    const sessionId = 'session-id';
    params.set('code', 'value');
    params.set('state', sessionId);

    window.location.href = `http://www.address.com?code=value&state=${sessionId}`;

    const errorResponse = new AxiosError();
    errorResponse.response = <AxiosResponse>{
      data: {
        errorCode: 'VENDOR_BAD_REQUEST',
        message: 'Could not fetch profile from singpass',
        sessionId: 'some-uu-id',
        error: {
          message: 'VALIDATION_ERROR',
        },
      },
      status: 404,
      statusText: 'Some generic error message',
    };
    const getMock = jest.fn().mockRejectedValue(errorResponse);
    const eventHub = mockEventHub();
    await wrapper(
      {
        session: <SessionContext>{ sessionId },
        frankieClient: <FrankieApiClient>(<unknown>{
          get: getMock,
        }),

        globalEventHub: {} as EventHub,
        localEventHub: {} as EventHub,
        mode: {} as ModeObject,
        moduleMeta: {
          instanceName: '',
          moduleName: 'federation',
        },
        oneSdkInstance: {} as OneSdkContext,
        recipe: {} as RecipeParsed,
        telemetry: false,
      },
      {
        eventHub,
      },
    );
    expect(eventHub.emit).toHaveBeenCalledWith(
      'error',
      expect.objectContaining({
        message: 'Failed sending authorisation: "Could not fetch profile from singpass"',
        payload: {
          errorCode: 'VENDOR_BAD_REQUEST',
        },
      }),
    );
  });
  test('Approval failing with errorCode is emitted with the error event', async () => {
    const params = new URLSearchParams();
    const sessionId = 'session-id';
    params.set('code', 'value');
    params.set('state', sessionId);

    window.location.href = `http://www.address.com?code=value&state=${sessionId}`;

    const errorResponse = new AxiosError();
    errorResponse.response = <AxiosResponse>{
      data: {
        errorCode: 'VENDOR_BAD_REQUEST',
        message: 'Could not store profile as an entity',
        sessionId: 'some-uu-id',
        error: {
          message: 'VALIDATION_ERROR',
        },
      },
      status: 404,
      statusText: 'Some generic error message',
    };
    const getMock = jest.fn().mockResolvedValue({
      data: { individual: {}, status: 'success' },
    });
    const postMock = jest.fn().mockRejectedValue(errorResponse);

    const eventHub = mockEventHub<{
      results: [unknown, unknown, AnyFunction];
    }>();

    // Setup events for testing before initiating the authorisation flow
    // Once results event is triggered, call approve to follow into the second part of the flow
    // Tests should happen once the "error" event is triggered
    eventHub.on('results', (_1, _2, approve) => approve());
    eventHub.on('error', () => {
      expect(eventHub.emit).toHaveBeenCalledWith(
        'error',
        expect.objectContaining({
          message: 'Failed sending confirmation: "Could not store profile as an entity"',
          payload: {
            errorCode: 'VENDOR_BAD_REQUEST',
          },
        }),
      );
    });
    // Initialise flow
    await wrapper(
      {
        session: <SessionContext>{ sessionId },
        frankieClient: <FrankieApiClient>(<unknown>{
          get: getMock,
          post: postMock,
        }),

        globalEventHub: {} as EventHub,
        localEventHub: {} as EventHub,
        mode: {} as ModeObject,
        moduleMeta: {
          instanceName: '',
          moduleName: 'federation',
        },
        oneSdkInstance: {} as OneSdkContext,
        recipe: {} as RecipeParsed,
        telemetry: false,
      },
      {
        eventHub,
      },
    );
    // Only end tests after the error event is triggered
    return waitFor(null, eventHub, 'error');
  });

  test('If url params contains no error, has authCode and state matches sessionId, it hasAllAuthorizationParams', () => {
    //   if (error) throw new Error(errorInfo ?? "Internal server error");
    // if (authCode && !stateMatches)
    //   throw new Error(
    //     "A different session is being used to initialise the OneSDK than the one used at the beginning of the federation flow."
    //   );

    // return authCode && stateMatches;
    const params = new URLSearchParams();
    const sessionId = 'session-id';
    params.set('code', 'value');
    params.set('state', sessionId);
    const options = <InjectedState>{
      session: <SessionContext>{ sessionId },
    };
    expect(hasAllAuthorisationParams(params, options)).toBe(true);
  });
  test('If url params contains no error, has authCode and state doesnt match sessionId, it throws error', () => {
    //   if (error) throw new Error(errorInfo ?? "Internal server error");
    // if (authCode && !stateMatches)
    //   throw new Error(
    //     "A different session is being used to initialise the OneSDK than the one used at the beginning of the federation flow."
    //   );

    // return authCode && stateMatches;
    const params = new URLSearchParams();
    const sessionId = 'session-id';
    const otherSessionId = 'session-id-diff';
    params.set('code', 'value');
    params.set('state', otherSessionId);
    const shared = <InjectedState>{
      session: <SessionContext>{ sessionId },
    };
    expect(() => hasAllAuthorisationParams(params, shared)).toThrow(
      'A different session is being used to initialise the OneSDK than the one used at the beginning of the federation flow.',
    );
  });
  test('check data_extracted_successfully event includes entity ID', async () => {
    const params = new URLSearchParams();
    const sessionId = 'session-id';
    params.set('code', 'value');
    params.set('state', sessionId);

    window.location.href = `http://www.address.com?code=value&state=${sessionId}`;
    const getMock = jest.fn().mockResolvedValue({
      data: { individual: {}, status: 'success' },
    });
    const postMock = jest.fn().mockResolvedValue({
      data: { entityId: 'testEntityId' },
    });

    const eventHub = mockEventHub<{
      results: [unknown, unknown, AnyFunction];
      data_extracted_successfully: [{ entityId: string }];
    }>();

    // Setup events for testing before initiating the authorisation flow
    // Once results event is triggered, call approve to follow into the second part of the flow
    eventHub.on('results', (_1, _2, approve) => approve());
    eventHub.on('data_extracted_successfully', ({ entityId }) => {
      expect(entityId).toBe('testEntityId');
    });
    // Initialise flow
    await wrapper(
      {
        session: <SessionContext>{ sessionId },
        frankieClient: <FrankieApiClient>(<unknown>{
          get: getMock,
          post: postMock,
        }),
        globalEventHub: {} as EventHub,
        localEventHub: {} as EventHub,
        mode: {} as ModeObject,
        moduleMeta: {
          instanceName: '',
          moduleName: 'federation',
        },
        oneSdkInstance: {} as OneSdkContext,
        recipe: {} as RecipeParsed,
        telemetry: false,
      },
      {
        eventHub,
      },
    );
  });
});
