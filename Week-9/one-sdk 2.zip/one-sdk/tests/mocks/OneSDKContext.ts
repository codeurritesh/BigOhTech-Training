import type { IndividualModule, OneSdkContext } from '@frankieone/one-sdk';
import type { SessionContext } from '@module/session/SessionContext';

import { mockIndividualModule } from './IndividualModule';
import { mockSessionContext } from './SessionContext';

type Dependencies = {
  component: jest.Mock;
  flow: jest.Mock;
  session: (ctx: SessionContext) => SessionContext;
  individual: (ctx: IndividualModule['moduleContext']) => IndividualModule['moduleContext'];
};

export function mockOneSDKContext(providers?: Partial<Dependencies>) {
  const dependencies: Dependencies = Object.assign(
    {
      component: jest.fn().mockReturnValue({ on: jest.fn(), off: jest.fn() }),
      flow: jest.fn(),
      session: (v) => v,
      individual: (v) => v,
    },
    providers,
  );

  const component = dependencies.component;
  const flow = dependencies.flow;
  const session = dependencies.session(mockSessionContext());
  const individual = dependencies.individual(mockIndividualModule());

  return {
    component,
    flow,
    session,
    individual: () => individual,
  } as unknown as {
    component: typeof component;
    flow: typeof flow;
    session: typeof session;
    individual: typeof individual;
  } & OneSdkContext;
}
