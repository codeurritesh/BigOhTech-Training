// hard coded list of supported vendors which maps directly to a vendor wrapper
export const VendorList = ["singpass"] as const;
export type Vendor = typeof VendorList[number];
