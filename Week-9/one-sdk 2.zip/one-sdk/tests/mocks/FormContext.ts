export function mockFormContext() {
  return {
    mount: jest.fn(),
    on: jest.fn(),
    off: jest.fn(),
  };
}
