import { Dictionary } from "../models/general";

type ReadMethod<ReturnType = any, ObjectType = Dictionary<ReturnType>> = (o: ObjectType, path: string) => ReturnType;
const DEFAULT_READ_METHOD: ReadMethod<any, any> = (o, i) => o[i];

export function getDot<ObjectType>(
  path: string,
  obj: ObjectType,
  readMethod: ReadMethod<any, ObjectType> = DEFAULT_READ_METHOD
) {
  const splitPath = path.split(".");
  try {
    return splitPath.reduce(readMethod, obj) ?? null;
  } catch {
    return null;
  }
}
