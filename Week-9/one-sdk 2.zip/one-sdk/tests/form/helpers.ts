import type { EventHub } from '@module/common';
import { Document } from '@module/common/shared/models/Document';
import { promisifyForm } from '@module/common/vendors/form/promisifyForm';
import {
  useFormToReviewResults,
} from '@module/common/vendors/form/useForm';
import type { OneSdkContext } from '@module/types';
import { mockEventHub } from '@tests/mocks/EventHub';
import { mockFormContext } from '@tests/mocks/FormContext';
import { mockOneSDKContext } from '@tests/mocks/OneSDKContext';

type Providers = {
  oneSdkInstance?: (v: OneSdkContext) => OneSdkContext;
  localEventHub?: (v: EventHub) => EventHub;
  mountElement?: (v: HTMLElement) => HTMLElement;
  shouldAttachForm?: boolean;
  // Allowing extra properties to be passed to the results object
  // This will test that the results object is simply passed through
  results?: { document: Document; entityId: string } & Record<string, unknown>;
  reviewedDocument?: Document;
};

/** Runs the useFormToReviewResults so the tests can focus on what matters.
 * Provide overrides to the dependencies as an object of "provider" functions, which take
 * the default value as parameter and return the new value, which will be used to execute the function.
 */
export function execute(overrides: Providers = {}) {
  const deps: Required<Providers> = Object.assign(
    {
      shouldAttachForm: false,
      results: { document: new Document(), entityId: '123' },
      reviewedDocument: new Document(),
      oneSdkInstance: (v: OneSdkContext) => v,
      localEventHub: (v: EventHub) => v,
      mountElement: (v: HTMLElement) => v,
    },
    overrides,
  );
  const formInstance = mockFormContext();
  const oneSdkInstance = deps.oneSdkInstance(
    // The provided OneSDKInstance will be pre configured to return the form
    // instance when component('form') is called
    (() => {
      const oneSDK = mockOneSDKContext();
      oneSDK.component.mockReturnValue(formInstance);
      return oneSDK;
    })(),
  );
  const localEventHub = deps.localEventHub(mockEventHub());
  const mountElement = deps.mountElement(document.createElement('div'));
  const shouldAttachForm = deps.shouldAttachForm;

  // When promisifyForm is called with the Form instance, trigger the
  // "ready" events and then resolve to the reviewedDocument object
  if (isMocked(promisifyForm)) {
    promisifyForm.mockImplementationOnce((formInstance) => {
      formInstance.on.mock.calls
        .filter(([ev]) => ev === 'ready')
        .forEach(([, cb]) => cb({ domElement: document.createElement('div') }));
      return Promise.resolve(deps.reviewedDocument);
    });
  }

  const useForm = useFormToReviewResults({
    oneSdkInstance,
    localEventHub,
    mountElement,
    attachForm: shouldAttachForm,
  });
  const results = deps.results;

  useForm(results);

  return {
    oneSdkInstance,
    localEventHub,
    mountElement,
    shouldAttachForm,
    results,
    findEventEmissions: (eventName: string) => {
      return (localEventHub.emit as jest.Mock).mock.calls.filter(([evName]) => evName === eventName);
    },
  };
}

const isMocked = (module: unknown): module is jest.Mock => Boolean(module && (module as jest.Mock).mock);
