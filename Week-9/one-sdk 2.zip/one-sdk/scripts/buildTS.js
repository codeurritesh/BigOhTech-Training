/* eslint-disable no-console */
import { execSync } from 'child_process';
import commandLineArgs from 'command-line-args';
import { writeFileSync } from 'fs';
import meta from '../modules/meta.json' assert { type: 'json' };
import packageMeta from '../package.json' assert { type: 'json' };

const options = commandLineArgs([
  { name: 'tsconfig', alias: 'c', type: String },
  { name: 'type', alias: 't', type: String },
]);

const { tsconfig: tsconfigPath, type: moduleType } = options;

const module = moduleTypeToModuleConfig(moduleType);
const outDir = `dist/${moduleType}`;

try {
  // Update meta data
  // TODO: Investigate why we needed this meta.json file.
  // The meta.json file is used to store the current version of the build, so it can be read at run time.
  // This would be better done by injecting the value statically at build time. The typescript compiler doesn't support that.
  // TODO: Use webpack to build, BUT NOT BUNDLE typescript into javascript. This is so the types maintain the correct references.
  // Webpack can then inject the version as a constant.
  // NOTE: Whatever is done about it needs to work on customers build systems too. They will use build setups that we can't predict.
  // For that reason, injecting the version at our build time is the best option.
  meta.version = packageMeta.version;
  writeFileSync('./modules/meta.json', JSON.stringify(meta));
  // Build modules
  execSync(
    `npx tsc --project "${tsconfigPath}" -m "${module}" --outDir "${outDir}" && \
    npx tsc --project "${tsconfigPath}" -m "${module}" --outDir "${outDir}" --declaration --allowJS false --emitDeclarationOnly && \
    npx resolve-tspaths -p "${tsconfigPath}"`,

    { encoding: 'utf8' },
  );
  console.log(`\n----\n${module} files emitted to directory ${outDir}\n----\n`);
} catch (error) {
  console.error(error);
}

function moduleTypeToModuleConfig(moduleType) {
  if (moduleType === 'esm') return 'ES2022';
  if (moduleType === 'cjs') return 'commonjs';
  throw new Error(`Unrecognized module type "${moduleType}"`);
}
