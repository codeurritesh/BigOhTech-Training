import merge from 'lodash.merge';

import { mkVendorLoader } from '@module/common';
import { defineModule } from '@module/common/modules/defineModule';

import { validateConfiguration } from './validateConfiguration';

import type { FormModule } from './definition';

export default defineModule<FormModule>('form', (globalState, options = {}) => {
  validateConfiguration(globalState);

  const { recipe: { form: { provider } }, localEventHub } = globalState;

  // initialise root config if it's missing
  provider.config ??= {};

  // merge the root config with runtime config
  Object.assign(provider.config, merge(provider.config, options));

  const vendorName = provider?.name ?? 'legacy';
  const loadForm = mkVendorLoader({
    sharedConfiguration: globalState,
    vendorName,
    vendorLoader: {
      legacy: () => import(/* webpackChunkName: 'form-legacy' */ './vendors/legacy'),
      formio: () => import(/* webpackChunkName: 'form-formio' */ './vendors/formio'),
      react: () => import(/* webpackChunkName: 'form-react' */ './vendors/react'),
    },
  });
  const mount: FormModule['moduleContext']['mount'] = (mountElement) => {
    const htmlElement: HTMLElement =
      typeof mountElement === 'string' ? document.querySelector(mountElement)! : mountElement;
    return loadForm({
      vendorWrapperOptions: {
        eventHub: localEventHub,
        mountElement: htmlElement,
      },
    });
  };
  return {
    mount,
    provider: vendorName,
  };
});
