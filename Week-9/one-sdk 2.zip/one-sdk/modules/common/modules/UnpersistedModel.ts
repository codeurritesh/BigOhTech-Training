/* istanbul ignore file */
import { Clonable, isClonable } from "./objectUtils";

/**
 * Wrap a model object with a temporary reference, while the model isn't persisted and receives a permanent "id" from the backend service
 * This wrapper is also clonable, allowing it to be immutable across state changes
 * @param model Original model
 * @param ref Temporary reference to wrap model
 * @returns The wrapped model with a new property "unpersisted" of type { ref: RefType, unwrap: () => OriginalModel }
 */
export function wrapUnpersistedModel<Type extends object, RefType>(
  model: Type,
  ref: RefType
): UnpersistedModel<Type, RefType> & Clonable<Type> {
  return new Proxy(model, {
    get: (t, p) => {
      if (p === "unpersisted") {
        return {
          ref,
          unwrap: () => model,
        };
      }
      if (p === "clone") {
        const clone = isClonable<Type>(t) ? t.clone() : t;
        return () => wrapUnpersistedModel(clone, ref);
      }

      return t[p];
    },
  }) as UnpersistedModel<Type, RefType> & Clonable<Type>;
}
export type UnpersistedModel<Type = unknown, RefType = number> = Type & {
  unpersisted: { ref: RefType; unwrap: () => Type };
};
type ExtractRefType<Model extends UnpersistedModel> = Model extends UnpersistedModel<unknown, infer RefType>
  ? RefType
  : never;
export const isUnpersistedModel = <ModelType>(
  m: UnpersistedModel<ModelType, unknown> | ModelType
): m is UnpersistedModel<ModelType, ExtractRefType<UnpersistedModel>> => Boolean((m as UnpersistedModel).unpersisted);

export const nextNumericRef = <T>(list: (UnpersistedModel<T> | T)[]): number => {
  const allRefs = list.filter(isUnpersistedModel).map((d) => d.unpersisted.ref);
  const nextRef = Math.max(0, Math.max(...allRefs)) + 1;
  return nextRef;
};
