import type { OneSDKError } from '@module/common/errors/OneSDKError.class';
import type { KeyOf, Override } from '@types';

//----[ Common events, which all eventHub instances support

type DefaultEvents = {
  error: [OneSDKError];
  warning: [{ message: string; payload?: unknown }];
  info: [{ message: string; payload?: unknown }];
  loading: [loadingState: boolean, context: { message: string }];
};
/**
 * Common events dictionary. This is different to the (Unknown)EventsDictionary dictionary
 * The unkonwn events dictionary is used to accept any dictionary of events.
 * The common events dictionary includes the default events (error, warning, info) and the wildcard event (*)
 *
 * CommonEvents extends EventsDictionary
 * @see EventsDictionary
 **/
export type CommonEvents<Events extends EventsDictionary = DefaultEvents> =
  DefaultEvents & {
  '*': [{ eventName: KeyOf<Events>; arguments: unknown[] }];
};

//----[ Event Hub instance

export type EventHub<Events extends EventsDictionary = CommonEvents> = {
  on: OnMethod<Events>;
  off: OffMethod<Events>;
  emit: EmitMethod<Events>;
  hasListenersFor: HasListenersMethod<Events>;
  map: MapMethod<Events>;
};

//----[ Event Hub methods

/** "on" takes an event name and a callback to attach to the event emitter */
type OnMethod<Events extends EventsDictionary> = <
  EventName extends KeyOfExtendedEvents<Events>
>(
  eventName: EventName | EventName[],
  listener: EventListenerCallback<ExtendedEvents<Events>[EventName]>
) => void;
/**
 * "off" has two signatures: 1) without parameters, when no events are specified 2) when they are.
 * In the first case, all event handlers are removed.
 * ! Do not use this yet. Global event handler "off" method has unintended side effects. Modules use the exposed event hub to emit internal events and calling off() will break the events chain.
 * TODO: Make sure to create an internal eventHub for each module, which pipes events into the publicly exposed eventHub.
 * TODO: do the event hub piping in "mkEventListener", where instead of using an event hub's listener methods directly, use a proxy (piped event hub) instead.
 * In the second case, only the specified event handler is removed.
 */
type OffMethod<Events extends EventsDictionary> = {
  /**
   * DO NOT USE THIS YET. Global event handler "off" method has unintended side effects.
   * @deprecated Not deprecated, just not stable. Do not use this yet.
   **/
  (): void;
  <EventName extends KeyOfExtendedEvents<Events>>(
    eventName: EventName | EventName[],
    listener: EventListenerCallback<ExtendedEvents<Events>[EventName]>
  ): void;
};
/**  "emit" takes an event name and any number of arguments to emit with the event. */
type EmitMethod<Events extends EventsDictionary> = <
  EventName extends KeyOfExtendedEvents<Events>
>(
  eventName: EventName,
  ...args: ExtendedEvents<Events>[EventName]
) => void;
/** "hasListenersFor" takes an event name and returns a boolean indicating if there are any listeners for that event. */
type HasListenersMethod<Events extends EventsDictionary> = <
  EventName extends KeyOfExtendedEvents<Events>
>(
  eventName: EventName
) => boolean;
/**
 * Map will reemit an event from the current event hub to a second event hub.
 * It has signatures for two different scenarios:
 * 2) When the target/proxied event name is the same as the original event name
 * 1) When the target/proxied event name is different to the original event name

 * In the first case, the event name needs to be supported by both event hubs<br>
 * In the second case, the origin event name needs to be supported by the origin event hub and the target event name needs to be supported by the target event hub.<br>
 */
type MapMethod<Events extends EventsDictionary> = {
  // When a second event name is not provided, the first event name needs to be present in both eventhub objects
  <
    EventName extends KeyOfExtendedEvents<ProxyEvents>,
    ProxyEvents extends EventsDictionary
  >(
    eventName: EventName | EventName[],
    proxyEventHub: EventHub<ProxyEvents>
  ): void;
  // If a second event name is provided, then the proxy event name needs to match the supported proxy event hub events
  <
    EventName extends KeyOfExtendedEvents<Events>,
    ProxyEvents extends EventsDictionary,
    ProxyEventName extends KeyOfExtendedEvents<ProxyEvents>
  >(
    eventName: EventName | EventName[],
    proxyEventHub: EventHub<ProxyEvents>,
    proxyEventName: ProxyEventName
  ): void;
};

//----[ Event Listener instance
// TODO: Allow map to be used on EventListener too
export type EventListener<Events extends EventsDictionary = CommonEvents> =
  Omit<EventHub<Events>, 'emit' | 'intercept' | 'hasListenersFor' | 'map'>;

//----[ Helpers

/**
 * Unkonwn events dictionary. This is different to the CommonEvents(Dictionary)
 * The unkonwn events dictionary is used to accept any dictionary of events.
 * The common events dictionary includes the default events (error, warning, info) and the wildcard event (*)
 *
 * CommonEvents extends EventsDictionary
 * @see CommonEvents
 **/
export type EventsDictionary = Record<string, unknown[]>;
export type EventListenerCallback<Arguments extends unknown[]> = (
  ...args: Arguments
) => void;
// Every EventHub automatically accepts the events described in "CommonEvents", the  "ExtendedEvents"
// Common events may be overriden by the events dictionary provided to the EventHub
export type ExtendedEvents<Events extends EventsDictionary> = Override<
  CommonEvents<Events>,
  Events
>;
export type KeyOfExtendedEvents<Events extends EventsDictionary> = KeyOf<
  ExtendedEvents<Events>
>;
// EventListener
type EventsFromHub<Hub extends EventHub> = Hub extends EventHub<infer Events>
  ? Events
  : never;
export type ListenerFromEmitter<Hub extends EventHub> = EventListener<
  EventsFromHub<Hub>
>;
