import { FrankieApiClient } from "@module/frankie-client";
import mockAxiosInstance from "jest-mock-axios";

jest.mock("axios", () => {
  return {
    create: jest.fn().mockImplementation(function () {
      return mockAxiosInstance;
    }),
  };
});
const mkClient = () => new FrankieApiClient();
// skipping test while backend api is fixed
describe("Frankie api client loader", () => {
  test("Loading Configuration client with { recipe: string }, asyncrhonously loads, initialises and returns instance containing recipe", async () => {
    const mockedPayload = {
      "test-recipe": { configuration: "yes" },
    };
    const frankie = mkClient();
    const config = await frankie.loadClient("configuration", { recipe: "test-recipe" });
    const configurationPromise = config.load();
    mockAxiosInstance.mockResponse({ data: mockedPayload });
    expect(mockAxiosInstance.get).toHaveBeenCalledWith("/onesdk/v1/config", {
      params: {
        item: "test-recipe",
        itemType: "object",
      },
    });
    await expect(configurationPromise).resolves.toBe(mockedPayload["test-recipe"]);
  });
});
