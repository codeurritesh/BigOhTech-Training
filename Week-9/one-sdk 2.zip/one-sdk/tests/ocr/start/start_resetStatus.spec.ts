import { Document } from '@module/common/shared/models/Document';
import { OCRStatus } from '@module/frankie-client/clients/OCRClient';
import { URL_PARAM } from '@module/frankie-client/DummyFrankieApiClient';
import { resetCurrentStatus } from '@module/ocr/actions/start';
import { mockAccessors } from '@tests/mocks/ReactiveStore';

import { mkStartMethod } from './utils';

describe('start::reset status', () => {
  test('When not preloading any document, set status to WAITING_FRONT, document to new document and isPreloaded to false', async () => {
    const { dependencies, status$, document$, isPreloaded$, individual } = mkStartMethod();
    individual.access.mockImplementation(() => mockAccessors({ documents: [] }));
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(new Document());
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(false);
  });
  test('When preloading documents without ocr, set status to WAITING_FRONT, document to new document and isPreloaded to false', async () => {
    const { dependencies, status$, document$, isPreloaded$, individual } = mkStartMethod();
    individual.access.mockImplementation(() => mockAccessors({ documents: [{ idType: 'PASSPORT' }] }));
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(new Document());
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(false);
  });
  test('When preloading documents with ocr, but also with verfied.manual = false, set status to WAITING_FRONT, document to new document and isPreloaded to false', async () => {
    const { dependencies, status$, document$, isPreloaded$, individual } = mkStartMethod();
    individual.access.mockImplementation(() =>
      mockAccessors({
        documents: [
          { idType: 'PASSPORT' },
          {
            ocrResult: {
              status: OCRStatus.COMPLETE,
            },
            verified: {
              manual: false,
              electronic: null,
            },
          },
        ],
      }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(new Document());
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(false);
  });
  test('When preloading documents with ocr, but also with verfied.electronic = false && verified.manual != true, set status to WAITING_FRONT, document to new document and isPreloaded to false', async () => {
    const { dependencies, status$, document$, isPreloaded$, individual } = mkStartMethod();
    individual.access.mockImplementation(() =>
      mockAccessors({
        documents: [
          { idType: 'PASSPORT' },
          {
            ocrResult: {
              status: OCRStatus.COMPLETE,
            },
            verified: {
              manual: null,
              electronic: false,
            },
          },
        ],
      }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(new Document());
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(false);
  });
  test('When preloading documents with ocr, but ocr status is a failure (-PROVIDER_OFFLINE), set status to WAITING_FRONT, document to found document and isPreloaded to true', async () => {
    const { dependencies, status$, document$, isPreloaded$, individual } = mkStartMethod();
    const preloadedDocument = {
      ocrResult: {
        status: OCRStatus.DOCUMENTS_UPLOAD_FAILED,
      },
      verified: {
        manual: null,
        electronic: null,
      },
    };
    individual.access.mockImplementation(() =>
      mockAccessors({
        documents: [{ idType: 'PASSPORT' }, preloadedDocument],
      }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(preloadedDocument);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(true);
  });
  test('When preloading documents with ocr, but ocr status is WAITING_OCR, 1) rerun ocr and if results are a failure or another WAITING_OCR, set status to WAITING_FRONT, document to new document and isPreloaded to false', async () => {
    const { dependencies, status$, document$, isPreloaded$, individual, frankieClient, client } = mkStartMethod();
    const foundDocument = new Document();
    foundDocument.documentId = 'test-id';
    foundDocument.ocrResult = {
      status: OCRStatus.WAITING_OCR_RUN,
    };
    foundDocument.verified = {
      manual: null,
      electronic: null,
    };
    individual.access.mockImplementation(() =>
      mockAccessors({
        documents: [{ idType: 'PASSPORT' }, foundDocument],
      }),
    );
    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'put' },
      {
        data: {
          ocrDocument: foundDocument,
          documentStatus: OCRStatus.DOCUMENTS_INVALID,
        },
      },
    );
    await resetCurrentStatus(dependencies);
    expect(client.rerun).toHaveBeenCalledWith('test-id');
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(new Document());
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(false);
  });
  test('When preloading documents with ocr, but ocr status is WAITING_OCR, 1) rerun ocr and if results are a PROVIDER_OFFLINE, interrupt flow', async () => {
    const { dependencies, individual, client, interruptOCR } = mkStartMethod();
    const foundDocument = new Document();
    foundDocument.documentId = 'test-id';
    foundDocument.ocrResult = {
      status: OCRStatus.WAITING_OCR_RUN,
    };
    foundDocument.verified = {
      manual: null,
      electronic: null,
    };
    individual.access.mockImplementation(() =>
      mockAccessors({
        documents: [{ idType: 'PASSPORT' }, foundDocument],
      }),
    );

    jest.spyOn(client, 'rerun').mockResolvedValue({
      ocrDocument: new Document(),
      documentStatus: OCRStatus.PROVIDER_OFFLINE,
    });

    await resetCurrentStatus(dependencies);
    expect(client.rerun).toHaveBeenCalledWith('test-id');
    expect(interruptOCR).toHaveBeenCalledWith({
      message: `Provider is offline. Either switch providers and restart or skip OCR temporarily. Status '${OCRStatus.PROVIDER_OFFLINE}'`,
      payload: expect.any(Error),
    });
  });
  test('When preloading documents with ocr, but ocr status is WAITING_OCR, 1) rerun ocr and if results are WAITING_FRONT, WAITING_BACK or COMPLETE, set status to received status, document to found document and isPreloaded to true', async () => {
    const { dependencies, status$, document$, isPreloaded$, individual, frankieClient, client } = mkStartMethod();
    const foundDocument = new Document();
    foundDocument.documentId = 'test-id';
    foundDocument.ocrResult = {
      status: OCRStatus.WAITING_OCR_RUN,
    };
    foundDocument.verified = {
      manual: null,
      electronic: null,
    };
    individual.access.mockImplementation(() =>
      mockAccessors({
        documents: [{ idType: 'PASSPORT' }, foundDocument],
      }),
    );
    frankieClient.stubResponse({ url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/ocr`), method: 'put' }, () => {
      foundDocument.ocrResult.status = OCRStatus.WAITING_BACK;
      return {
        data: {
          ocrDocument: foundDocument,
          status: OCRStatus.WAITING_BACK,
        },
      };
    });
    await resetCurrentStatus(dependencies);
    expect(client.rerun).toHaveBeenCalledWith('test-id');
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_BACK);
    expect(document$.setValue).toHaveBeenCalledWith(foundDocument);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(true);
  });
  test('When preloading documents with ocr status is WAITING_FRONT or WAITING_BACK, set status to received status, document to found document and isPreloaded to true', async () => {
    const { dependencies, status$, document$, isPreloaded$, individual } = mkStartMethod();
    const foundDocument = new Document();
    foundDocument.documentId = 'test-id';
    foundDocument.ocrResult = {
      status: OCRStatus.WAITING_FRONT,
    };
    foundDocument.verified = {
      manual: null,
      electronic: null,
    };
    individual.access.mockImplementation(() =>
      mockAccessors({
        documents: [{ idType: 'PASSPORT' }, foundDocument],
      }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.WAITING_FRONT);
    expect(document$.setValue).toHaveBeenCalledWith(foundDocument);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(true);
  });
  test('When preloading documents with ocr status is COMPLETE, set status to received status, document to found document and isPreloaded to true', async () => {
    const { dependencies, status$, document$, isPreloaded$, individual } = mkStartMethod();
    const foundDocument = new Document();
    foundDocument.documentId = 'test-id';
    foundDocument.ocrResult = {
      status: OCRStatus.COMPLETE,
    };
    foundDocument.verified = {
      manual: null,
      electronic: null,
    };
    individual.access.mockImplementation(() =>
      mockAccessors({
        documents: [{ idType: 'PASSPORT' }, foundDocument],
      }),
    );
    await resetCurrentStatus(dependencies);
    expect(status$.setValue).toHaveBeenCalledWith(OCRStatus.COMPLETE);
    expect(document$.setValue).toHaveBeenCalledWith(foundDocument);
    expect(isPreloaded$.setValue).toHaveBeenCalledWith(true);
  });
});
