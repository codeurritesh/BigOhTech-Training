import type { BiometricsModule } from '@module/biometrics';
import type { FormModule } from '@module/form/definition';
import type { IDVModule } from '@module/idv/definition.types';
import type { OCRModule } from '@module/ocr';
import type { WorkflowModule } from '@module/workflow/definition.types';

import type { PartialDeep } from 'type-fest';

// Recipe configuration may be split into optional "services" as well as root level configurations
// eslint-ignore-next-line
// prettier-ignore
export type RecipeConfiguration = PartialDeep<
  RecipeNameConfiguration &
  BiometricsModule['recipeConfiguration'] &
  DeviceRecipeConfiguration &
  IDVModule['recipeConfiguration'] &
  OCRModule['recipeConfiguration'] &
  FederationRecipeConfiguration &
  FormModule['recipeConfiguration'] &
  WorkflowModule['recipeConfiguration']
>;

type RecipeNameConfiguration = {
  name: string;
};
// TODO: Extract recipe configuration for each module into their own parseConfiguration files
type DeviceRecipeConfiguration = {
  deviceCharacteristics: {
    provider: {
      name: 'sardine' | 'threatmetrix';
      clientID: string;
      environment: 'production' | 'sandbox';
    };
  };
};

type FederationRecipeConfiguration = {
  idps: {
    singpass?: {
      environment: 'production' | 'sandbox' | 'test';
      client_id: string;
      attributes: string;
      purpose: string;
      state: string;
      redirect_url: string;
    };
    google?: {
      redirect_url: string;
      clientId: string;
    };
  };
  federation?: keyof RecipeConfiguration['idps'];
};
