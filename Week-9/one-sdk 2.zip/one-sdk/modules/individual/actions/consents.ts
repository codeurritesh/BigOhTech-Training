import { Accessors } from "@module/common";

export const mkAddConsents = (deps: { consentsGiven$: Accessors<string[]> }) => (type: string) => {
  const { consentsGiven$ } = deps;
  const consents = consentsGiven$.getValue();
  consents.push(type);
  consentsGiven$.setValue(consents);
};
