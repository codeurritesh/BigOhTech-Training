import { Nullable } from "./general";

export type TPayload = {
  applicantSubmitSplitConsent?: boolean;
  applicantSubmissionForceCheck?: boolean;
  optionalFields?: TOptionalFields;
  blockList?: TBlockListConfig;
  biometrics?: TBiometricsConfig;
  sendKycLink?: TSendKycLink;
  alwaysAllowManualPass?: boolean;
  additionalFields?: TAdditionalFields;
  transactionMonitoring?: TTransactionMonitoring;
};

export type TTransactionMonitoring = {
  sardineTransactionURL: Nullable<string>;
  sardineSessionURL: Nullable<string>;
};

export type TSendKycLink = {
  kycSMSHeaderText: Nullable<string>;
  kycSMSContent: Nullable<string>;
  kycSmartUIURL: Nullable<string>;
  kycSMSLinkExpiry: Nullable<number>;
  kycSMSLinkConfig?: Nullable<any>;
};

export type TAdditionalFields = {
  buddhistDOB: Nullable<boolean>;
  nativeName: Nullable<boolean>;
};

export type TOptionalFields = {
  givenName: boolean;
  familyName: boolean;
  dateOfBirth: boolean;
  phoneNumber: boolean;
  email: boolean;
  consents: boolean;
  address: boolean;
  document: boolean;
};
interface IPortalFeatureConfig {
  applicantSubmitSplitConsent: boolean;
  applicantSubmissionForceCheck: boolean;
  optionalFields: TOptionalFields;
  blockList: TBlockListConfig;
  biometrics?: TBiometricsConfig;
  alwaysAllowManualPass?: boolean;
}

export type TBlockListConfig = {
  firstNameOptional: boolean;
  lastNameOptional: boolean;
  dobOptional: boolean;
};

export type TBiometricsConfig = {
  SMSContent: Nullable<string>;
  SMSHeaderText: Nullable<string>;
  SMSExpiryInHours: Nullable<number>;
};

export class PortalFeatureConfig implements IPortalFeatureConfig {
  applicantSubmitSplitConsent = false;
  applicantSubmissionForceCheck = false;
  alwaysAllowManualPass = false;

  optionalFields = {
    givenName: false,
    familyName: false,
    dateOfBirth: false,
    phoneNumber: false,
    email: false,
    consents: false,
    address: false,
    document: false,
  };

  blockList: TBlockListConfig = {
    firstNameOptional: false,
    lastNameOptional: false,
    dobOptional: false,
  };

  biometrics: TBiometricsConfig = {
    SMSContent: null,
    SMSHeaderText: null,
    SMSExpiryInHours: null,
  };

  additionalFields: TAdditionalFields = {
    buddhistDOB: null,
    nativeName: null,
  };

  sendKycLink: TSendKycLink = {
    kycSmartUIURL: null,
    kycSMSHeaderText: null,
    kycSMSContent: null,
    kycSMSLinkExpiry: null,
    kycSMSLinkConfig: null,
  };

  transactionMonitoring: TTransactionMonitoring = {
    sardineTransactionURL: null,
    sardineSessionURL: null,
  };

  constructor(payload: TPayload) {
    this.applicantSubmitSplitConsent = payload.applicantSubmitSplitConsent || false;
    this.applicantSubmissionForceCheck = payload.applicantSubmissionForceCheck || false;
    this.alwaysAllowManualPass = payload.alwaysAllowManualPass || false;

    const { optionalFields, blockList, biometrics, sendKycLink, additionalFields, transactionMonitoring } = payload;

    if (optionalFields) {
      for (const key in optionalFields) {
        this.optionalFields[key] = optionalFields[key] || false;
      }
    }
    if (blockList) {
      this.blockList.firstNameOptional = blockList.firstNameOptional;
      this.blockList.lastNameOptional = blockList.lastNameOptional;
      this.blockList.dobOptional = blockList.dobOptional;
    }
    if (biometrics) {
      this.biometrics.SMSContent = biometrics.SMSContent;
      this.biometrics.SMSHeaderText = biometrics.SMSHeaderText || null;
      this.biometrics.SMSExpiryInHours = biometrics.SMSExpiryInHours || null;
    }
    if (sendKycLink) {
      this.sendKycLink.kycSmartUIURL = sendKycLink.kycSmartUIURL;
      this.sendKycLink.kycSMSHeaderText = sendKycLink.kycSMSHeaderText;
      this.sendKycLink.kycSMSContent = sendKycLink.kycSMSContent;
      this.sendKycLink.kycSMSLinkExpiry = sendKycLink.kycSMSLinkExpiry;
      this.sendKycLink.kycSMSLinkConfig = sendKycLink.kycSMSLinkConfig;
    }

    if (additionalFields) {
      this.additionalFields.buddhistDOB = additionalFields.buddhistDOB;
      this.additionalFields.nativeName = additionalFields.nativeName;
    }

    if (transactionMonitoring) {
      this.transactionMonitoring.sardineTransactionURL = transactionMonitoring.sardineTransactionURL;
      this.transactionMonitoring.sardineSessionURL = transactionMonitoring.sardineSessionURL;
    }
  }

  toJSON() {
    return { ...this };
  }

  static fromJSON(payload: TPayload) {
    return new PortalFeatureConfig(payload);
  }
}
