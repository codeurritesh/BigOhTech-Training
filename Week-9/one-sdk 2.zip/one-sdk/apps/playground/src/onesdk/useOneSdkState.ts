/* eslint-disable react-hooks/rules-of-hooks */
import { useEffect, useState } from 'react';

import type { Accessors, ReadonlyAccessors } from '@frankieone/one-sdk';

// TODO: Refactor this to DRY
type Setter<T> = (v: T) => void;
// export function useOneSdkState<T>(accessors: ReadonlyAccessors<T>): [T];
// export function useOneSdkState<T>(accessors: Accessors<T>): [T, Setter<T>];
export function useOneSdkState<T>(accessors: Accessors<T> | ReadonlyAccessors<T>): [T, Setter<T>?] {
  // accessors types are always guaranteed to be the same. ie an accessors object is always either readonly or readwrite
  // Therefore the condition below is safe and guaranteed to execute hooks always at the same worder
  if (!isWritable(accessors)) return useReadonlyOneSdkState(accessors);

  const { observable, getValue, setValue } = accessors;
  const [state, setState] = useState<T>(getValue());

  useEffect(() => {
    const subscription = observable.subscribe((value) => setState(value));
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return [state, setValue];
}
function useReadonlyOneSdkState<T>(accessors: ReadonlyAccessors<T>): [T, Setter<T>] {
  const { observable, getValue } = accessors;
  const [state, setState] = useState<T>(getValue());

  useEffect(() => {
    const subscription = observable.subscribe((value) => setState(value));
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const warningMessage = `Attempting to write to a readonly accessor '${accessors.property}'`;
  return [state, () => console.warn(warningMessage)];
}

const isWritable = <T>(a: Accessors<T> | ReadonlyAccessors<T>): a is Accessors<T> =>
  typeof (a as Accessors<T>).setValue !== 'undefined';
