import { mkEventHub } from '@module/common';
import type { IAddressPayload } from '@module/common/shared/models/Address';
import type { IApplicantPayload } from '@module/common/shared/models/Applicant';
import { Applicant } from '@module/common/shared/models/Applicant';
import { CheckSummary } from '@module/common/shared/models/CheckSummary';
import type { IDocumentPayload } from '@module/common/shared/models/Document';
import { Document } from '@module/common/shared/models/Document';
import { DummyFrankieApiClient } from '@module/frankie-client';
import { ApplicantClient } from '@module/frankie-client/clients/ApplicantClient';

import { mockSessionContext } from '../../mocks/SessionContext';
import { jwtWithEntityId, jwtWithReference } from '../../testUtils/tokens';

describe('Stubbed Applicant client', () => {
  test('if using entity id, load executes a search request and returns applicant and documents shared models', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    frankie.session = mockSessionContext(jwtWithEntityId);
    const applicantClient = new ApplicantClient(frankie);
    const stubbedData = getStubData();
    const searchRequested = jest.fn();
    frankie.stubResponse({ url: '/data/v2/applicant/', method: 'get' }, (config) => {
      searchRequested(config.params);
      return { data: stubbedData };
    });
    const payload = await applicantClient.load();
    expect(searchRequested).toHaveBeenCalledWith(
      expect.objectContaining({
        entityId: 'some-id',
      }),
    );
    expect(payload.applicant).toMatchObject(Applicant.fromJSON(stubbedData.applicant));
    expect(payload.documents).toMatchObject(stubbedData.documents.map(Document.fromJSON));
  });
  test('if using reference, load executes a search request, updates local entity id and returns applicant and documents shared models', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    frankie.session = mockSessionContext(jwtWithReference);
    const applicantClient = new ApplicantClient(frankie);
    const stubbedData = getStubData();
    const searchRequested = jest.fn();
    frankie.stubResponse({ url: '/data/v2/applicant/', method: 'get' }, (config) => {
      searchRequested(config.params);
      return { data: stubbedData };
    });
    const payload = await applicantClient.load();
    expect(searchRequested).toHaveBeenCalledWith(
      expect.objectContaining({
        reference: 'some-reference',
      }),
    );
    expect(applicantClient.reference).toBe('some-reference');
    expect(applicantClient.entityId).toBe('random-entityid');
    expect(payload.applicant).toMatchObject(Applicant.fromJSON(stubbedData.applicant));
    expect(payload.documents).toMatchObject(stubbedData.documents.map(Document.fromJSON));
  });
  test('load throws exception when searching by entity id and its not found', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    const applicantClient = new ApplicantClient(frankie);

    frankie.stubResponse(
      { url: '/data/v2/applicant/', method: 'get' },
      {
        status: 404,
        statusText: 'Applicant not found',
      },
    );
    const loadPromise = applicantClient.load().catch((e) => {
      throw e.toJSON();
    });
    await expect(loadPromise).rejects.toMatchObject({ code: '404', message: 'Applicant not found' });
  });
  test('load throws exception when searching by reference and its not found', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    const applicantClient = new ApplicantClient(frankie);

    frankie.stubResponse(
      { url: '/data/v2/applicant/', method: 'get' },
      {
        status: 404,
        statusText: 'Applicant not found',
      },
    );

    const loadPromise = applicantClient.load().catch((e) => {
      throw e.toJSON();
    });
    await expect(loadPromise).rejects.toMatchObject({ code: '404', message: 'Applicant not found' });
  });
  test('createApplicant returns entityId and requestId', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    const applicantClient = new ApplicantClient(frankie);
    const factory = jest.fn(() => {
      return {
        data: {
          entityId: 'entity id',
          requestId: 'request id',
        },
      };
    });
    frankie.stubResponse(
      {
        url: '/data/v2/applicants/',
      },
      factory,
    );

    const payload = await applicantClient.createApplicant({
      applicant: new Applicant(),
      documents: [],
    });
    expect(factory).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          applicant: expect.anything(),
          documents: expect.anything(),
        }),
      }),
    );
    expect(payload).toEqual({
      entityId: 'entity id',
      requestId: 'request id',
    });
  });
  test('updateApplicant returns entityId and requestId', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    frankie.session = mockSessionContext(jwtWithEntityId);
    const applicantClient = new ApplicantClient(frankie);

    frankie.stubResponse(
      { url: /\/data\/v2\/applicants\/\S+/, method: 'put' },
      {
        data: {
          entityId: 'entity id',
          requestId: 'request id',
        },
      },
    );

    const payload = await applicantClient.updateApplicant({
      applicant: new Applicant(),
      documents: [],
    });
    expect(payload).toEqual({
      entityId: 'entity id',
      requestId: 'request id',
    });
  });
  test('getLatestCheckResults returns CheckResults object', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    frankie.session = mockSessionContext(jwtWithEntityId);
    const applicantClient = new ApplicantClient(frankie);
    const checkSummary = CheckSummary.default();
    const urlCapture = jest.fn();
    frankie.stubResponse({ url: /data\/v2\/applicants\/(\S+)/, method: 'get' }, (config) => {
      urlCapture(config.url);
      return {
        data: {
          applicant: new Applicant().toJSON(),
          documents: [],
          checkSummary: checkSummary.toJSON(),
        },
      };
    });

    const payload = await applicantClient.getLatestCheckResults();
    expect(urlCapture).toHaveBeenCalledWith('/data/v2/applicants/some-id');
    expect(payload).toMatchObject({
      kycMethod: 'electronic',
      alertList: [],
      status: { type: 'unchecked', label: 'Unchecked', key: 'UNCHECKED' },
    });
  });
  test('trigger checks calls /checks endpoint and then getLatestCheckResults to return a CheckResults object', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    frankie.session = mockSessionContext(jwtWithEntityId);
    const applicantClient = new ApplicantClient(frankie);
    const checkSummary = CheckSummary.default();
    const urlCapture = jest.fn();
    frankie.stubResponse({ url: /data\/v2\/applicants\/(\S+)/, method: 'get' }, (config) => {
      urlCapture(config.url);
      return {
        data: {
          applicant: new Applicant().toJSON(),
          documents: [],
          checkSummary: checkSummary.toJSON(),
        },
      };
    });
    frankie.stubResponse({ url: /data\/v1\/applicants\/(\S+)\/checks/, method: 'post' }, (config) => {
      urlCapture(config.url);
      return {
        data: {
          applicant: new Applicant().toJSON(),
          documents: [],
          checkSummary: checkSummary.toJSON(),
        },
      };
    });

    const payload = await applicantClient.triggerChecks();
    expect(urlCapture).toHaveBeenNthCalledWith(1, '/data/v1/applicants/some-id/checks');
    expect(urlCapture).toHaveBeenNthCalledWith(2, '/data/v2/applicants/some-id');
    expect(payload).toMatchObject({
      kycMethod: 'electronic',
      alertList: [],
      status: { type: 'unchecked', label: 'Unchecked', key: 'UNCHECKED' },
    });
  });
  test('Endpoints that require entity id will fail without a local entity id', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    frankie.session = mockSessionContext(jwtWithReference);
    const applicantClient = new ApplicantClient(frankie);
    await expect(
      applicantClient.updateApplicant({
        applicant: new Applicant(),
        documents: [],
      }),
    ).rejects.toBeTruthy();
    await expect(applicantClient.getLatestCheckResults()).rejects.toBeTruthy();
    await expect(applicantClient.triggerChecks()).rejects.toBeTruthy();
  });
  test('Client initialised with reference will start using entity id after applicant is created', async () => {
    const frankie = new DummyFrankieApiClient({ globalEventHub: mkEventHub() });
    frankie.session = mockSessionContext(jwtWithReference);
    const applicantClient = new ApplicantClient(frankie);
    frankie.stubResponse({ url: /data\/v2\/applicants/, method: 'post' }, () => {
      return {
        data: {
          entityId: 'newentityid',
        },
      };
    });
    const urlCapture = jest.fn();
    frankie.stubResponse({ url: /data\/v2\/applicants\/\S+/, method: 'get' }, (config) => {
      urlCapture(config.url);
      return {
        data: {
          applicant: new Applicant().toJSON(),
          documents: [],
          checkSummary: CheckSummary.default().toJSON(),
        },
      };
    });
    await applicantClient.createApplicant({
      applicant: new Applicant(),
      documents: [],
    });
    await applicantClient.getLatestCheckResults();
    expect(urlCapture).toHaveBeenCalledWith('/data/v2/applicants/newentityid');
  });
});

function getStubData() {
  const applicantPayload = {
    entityId: 'random-entityid',
    name: {
      givenName: 'Alice',
      familyName: 'Someone',
    },
    addresses: [
      { addressId: 'random', streetName: 'some street', streetNumber: '100U', addressType: 'BUSINESS' },
      { addressId: 'random', streetName: 'some street', streetNumber: '200U', addressType: 'RESIDENTIAL1' },
    ] as IAddressPayload[],
    dateOfBirth: '1990-12-01',
    profile: null,
  } as IApplicantPayload;
  const documentsPayload = [
    { country: 'NZL', idType: 'PASSPORT', idNumber: 'ABC101010', documentId: 'random-doc-id' },
  ] as IDocumentPayload[];
  return {
    applicant: applicantPayload,
    documents: documentsPayload,
  };
}
