import { Dictionary } from "@types";
import base64 from "base-64";
import { RiskLevel } from "./ApplicantSummary";
import { TAssociationRole } from "./AssociatedParty";
import { Nullable } from "./general";
import { IIssue, IIssueAction } from "./TApplicantIssue";

export interface UboReportPdfData {
  readonly reportType: string;
  checkSummary: CheckResult[];
  targetCompany: Organisation;
  reportCreatedAt: string;
  frankieId: string;
  beneficialOwners: {
    individuals: Individual[];
    nonIndividuals: Organisation[];
    linkedCompanies: Organisation[];
  };
  associatedParties: Entity[];
  investigatedCompanies: Organisation[];
  screened: {
    individuals: Individual[];
    companies: Organisation[];
  };
  suppliedData: {
    entityName: string | null;
    acn: string | null;
    entityType: string | null;
    abn: string | null;
    customerId: string | null;
    arbn: string | null;
    checkType: string | null;
  };
  annualReport: null | string;
  hasBreakingError: boolean;
  helpers?: Dictionary;
}
export type PartialUboReportPdfData = Partial<UboReportPdfData>;

export type EntityId = string;
export type MediaData = {
  date: string;
  snippet: string;
  title: string;
  url: string;
};
export type MarginsObject = { top: number; right: number; bottom: number; left: number };

export type Entity = Organisation | Individual;
export type CheckType = "m" | "s" | "pep" | "wl";
export type AMLCriteria = IndividualAmlCriteria | OrganisationAmlCriteria;
export interface AmlCheckDefinitionPayload {
  checkTypes: CheckType[];
}
export interface IsEntity {
  entityId: EntityId;
  theEntityType: string;
  name: string;
  uuid: string;
}
export interface IndividualAmlCriteriaPayload extends AmlCheckDefinitionPayload {
  name: {
    given: string;
    middle: string;
    family: string;
  };
}
export interface OrganisationAmlCriteriaPayload extends AmlCheckDefinitionPayload {
  name: string;
}

export class AmlCheckDefinition implements AmlCheckDefinitionPayload {
  checkTypes: CheckType[];
  constructor(d: AmlCheckDefinitionPayload) {
    this.checkTypes = d.checkTypes;
  }
  get checkTypeNames(): string[] {
    const mapAlertToTitle = (alert: CheckType) => {
      switch (alert) {
        case "m":
          return "Adverse Media";
        case "s":
          return "Sanctions";
        case "wl":
          return "Watchlists";
        case "pep":
          return "PEP";
        default:
          return "-";
      }
    };
    return this.checkTypes.map(mapAlertToTitle);
  }
}
export class IndividualAmlCriteria extends AmlCheckDefinition implements IndividualAmlCriteriaPayload {
  name: {
    given: string;
    middle: string;
    family: string;
  };
  constructor(d: IndividualAmlCriteriaPayload) {
    super(d);
    this.name = {
      given: d.name.given || "",
      middle: d.name.middle || "",
      family: d.name.family || "",
    };
  }
}
export class OrganisationAmlCriteria extends AmlCheckDefinition implements OrganisationAmlCriteriaPayload {
  name: string;
  constructor(d: OrganisationAmlCriteriaPayload) {
    super(d);
    this.name = d.name;
  }
}
export interface AMLResultSetPayload<Criteria extends AMLCriteria> {
  results: AMLMatch[] | null;
  criteria: Criteria;
}
export class AMLResultSet<Criteria extends AMLCriteria> implements HasAmlStatus, AMLResultSetPayload<Criteria> {
  public amlStatusReader: AMLStatusReader;
  public criteria: Criteria;
  public results: AMLMatch[] | null;
  constructor(d: AMLResultSetPayload<Criteria>) {
    this.results = d.results;
    this.criteria = d.criteria;
    this.amlStatusReader = new AMLStatusReader(d.results!);
  }
  get adverseMediaStatus() {
    return this.amlStatusReader.adverseMediaStatus;
  }
  get alerts() {
    return this.amlStatusReader.alerts;
  }
  get alertNames() {
    return this.amlStatusReader.alertNames;
  }
  get count() {
    return this.amlStatusReader.count;
  }
  get checkTypes() {
    return this.criteria.checkTypes;
  }
  get checkTypeNames() {
    return this.criteria.checkTypeNames;
  }
}
export interface ShareholdingOwnership {
  sharesHeld: number | null;
  isBeneficiallyHeld: boolean | null;
  jointHolding: boolean | null;
  shareClass: string | null;
}
export interface OwnershipObject {
  total: number | null;
  beneficiallyHeld: number | null;
  nonBeneficiallyHeld: number | null;
  shareholdings: ShareholdingOwnership[];
}
export interface IndividualPayload {
  name: string;
  aml: AMLResultSet<IndividualAmlCriteria>;
  kyc: KYCResults;
  addressLongForm: string;
  dateOfBirth: string;
  placeOfBirth: string;
  entityId: EntityId;
  profileType: string;
  customerReference: string;
  phoneNumber: string;
  emailAddress: string;
  roles?: TAssociationRole[];
  percentageHolding?: PercentageHolding;
}
export interface HasAddress {
  addressLongForm: string;
}
export interface HasDisplayableName {
  name: string;
}

export type PercentageHolding = {
  beneficially: number | null;
  nonBeneficially: number | null;
  jointly: number | null;
  total: number | null;
};

export class Individual
  implements
    IndividualPayload,
    IsEntity,
    HasKycStatus,
    HasAmlStatus,
    ShareHolder,
    OfficeHolder,
    HasAddress,
    HasDisplayableName
{
  entityId: EntityId;
  name: string;
  addressLongForm: string;
  ownership: Dictionary<OwnershipObject>;
  aml: AMLResultSet<IndividualAmlCriteria>;
  kyc: KYCResults;
  dateOfBirth: string;
  profileType: string;
  placeOfBirth: string;
  customerReference: string;
  phoneNumber: string;
  emailAddress: string;
  roles?: TAssociationRole[] = [];
  percentageHolding?: PercentageHolding;

  private startDate: string | null;
  private type: string | null;

  constructor(d: IndividualPayload) {
    this.entityId = d.entityId;
    this.name = d.name;
    this.ownership = {};
    this.aml = d.aml;
    this.kyc = d.kyc;
    this.addressLongForm = d.addressLongForm;
    this.dateOfBirth = d.dateOfBirth;
    this.placeOfBirth = d.placeOfBirth;
    this.type = null;
    this.startDate = null;
    this.profileType = d.profileType;
    this.customerReference = d.customerReference;
    this.phoneNumber = d.phoneNumber;
    this.emailAddress = d.emailAddress;
    this.roles = d.roles;
    this.percentageHolding = d.percentageHolding;
  }
  setEntityType(): ShareHolder {
    return this;
  }
  getEntityType(): string {
    return this.theEntityType;
  }
  setOwnership(ownership: Dictionary<OwnershipObject>): Individual {
    this.ownership = ownership;
    return this;
  }
  getOwnership(): Dictionary<OwnershipObject> {
    return this.ownership;
  }
  getOfficeholderStartDate(): string {
    return this.startDate || "";
  }
  getOfficeholderType(): string {
    return this.type || "";
  }
  setOfficeholderStartDate(date: string) {
    this.startDate = date;
    return this;
  }
  setOfficeholderType(type: string) {
    const mapType = (type: string) => {
      switch (type) {
        case "DR":
          return "Director";
        case "SR":
          return "Secretary";
        default:
          return type;
      }
    };
    this.type = mapType(type);
    return this;
  }
  isOwnershipNonUbo(organisationId: EntityId) {
    const ownershipObject = this.ownership[organisationId];
    const total = ownershipObject?.total || 0;
    return total < 25;
  }

  get amlCount(): number {
    return this.aml.count;
  }
  get adverseMediaStatus(): AdverseMediaStatus {
    return this.aml.adverseMediaStatus;
  }
  get alerts(): string[] {
    return this.aml.alerts;
  }
  get alertNames(): string[] {
    return this.aml.alertNames;
  }
  get kycStatus(): KYCStatus {
    return this.kyc.status;
  }
  get theEntityType(): string {
    return "INDIVIDUAL";
  }
  get uuid(): string {
    // wrongfully built uuid. What's the purpose of this value?
    return base64.encode(`${this.name}`);
  }
  get checkTypes(): string[] {
    return this.aml.checkTypes;
  }
  get checkTypeNames(): string[] {
    return this.aml.checkTypeNames;
  }
}
export interface AMLResultsPayload {
  matches: AMLMatch[];
}
interface HasAmlStatus {
  adverseMediaStatus: AdverseMediaStatus;
  alerts: string[];
  alertNames: string[];
}
export class AMLStatusReader implements HasAmlStatus {
  static readonly AML_FAILING_ORDER = ["POT_MATCH", "NO_MATCH"];
  constructor(public results: HasAmlStatus[] | null) {}
  /**
   * From the match list, find out if media is included to determine adverse media status
   */
  get adverseMediaStatus() {
    if (this.results === null) return new AdverseMediaStatus(null);
    if (this.results.length === 0) return new AdverseMediaStatus("NO_MATCH");

    const getStatusPoints = (status: string | null): number => {
      const index = AMLStatusReader.AML_FAILING_ORDER.indexOf(status!);
      if (index === -1) return Infinity;
      return index;
    };
    const getStatusCode = (k: HasAmlStatus) => k.adverseMediaStatus?.code || null;
    const getItemPoints = (k: HasAmlStatus) => getStatusPoints(getStatusCode(k));
    const subtractItems = (a: HasAmlStatus, b: HasAmlStatus) => getItemPoints(a) - getItemPoints(b);

    const sortedItems = this.results.sort(subtractItems);
    return sortedItems[0].adverseMediaStatus;
  }
  get alerts() {
    if (!this.results) return [];
    const allAlerts = this.results.map((r) => r.alerts).flat() as string[];
    const set = new Set(allAlerts);
    return Array.from(set);
  }
  get alertNames() {
    if (!this.results) return [];
    const allAlerts = this.results.map((r) => r.alertNames).flat() as string[];
    const set = new Set(allAlerts);
    return Array.from(set);
  }
  get count() {
    if (!this.results) return 0;
    return this.results.length;
  }
}
export interface HasKycStatus {
  kycStatus: KYCStatus;
}
export class KYCStatusReader {
  static readonly KYC_FAILING_ORDER = ["FAIL", "WARN", "PASS"];
  constructor(public results: HasKycStatus[] | null) {}
  get kycStatus(): KYCStatus {
    if (this.results === null) return new KYCStatus(null);
    if (this.results.length === 0) return new KYCStatus(null);

    const getStatusPoints = (status: string | null): number => {
      const index = KYCStatusReader.KYC_FAILING_ORDER.indexOf(status!);
      if (index === -1) return Infinity;
      return index;
    };
    const getStatusCode = (k: HasKycStatus) => k.kycStatus?.code || null;
    const getItemPoints = (k: HasKycStatus) => getStatusPoints(getStatusCode(k));
    const subtractItems = (a: HasKycStatus, b: HasKycStatus) => getItemPoints(a) - getItemPoints(b);

    const sortedItems = this.results.sort(subtractItems);
    return sortedItems[0].kycStatus;
  }
}
export class AMLResult implements AMLResultsPayload, HasAmlStatus {
  matches: AMLMatch[];
  amlStatusReader: AMLStatusReader;
  constructor(d: AMLResultsPayload) {
    this.matches = d.matches;
    this.amlStatusReader = new AMLStatusReader(d.matches);
  }
  get adverseMediaStatus() {
    return this.amlStatusReader.adverseMediaStatus;
  }
  get alerts() {
    return this.amlStatusReader.alerts;
  }
  get alertNames() {
    return this.amlStatusReader.alertNames;
  }
  get matchCount() {
    return this.amlStatusReader.count;
  }
  get count() {
    return this.amlStatusReader.count;
  }
}
export interface KYCResultsPayload {
  status: KYCStatus;
  sources: string[];
  issuesList: (IIssue | IIssueAction)[];
  riskLevel: RiskLevel;
}
export class KYCResults implements KYCResultsPayload {
  status: KYCStatus;
  sources: string[];
  issuesList: (IIssue | IIssueAction)[];
  riskLevel: RiskLevel;
  constructor(d: KYCResultsPayload) {
    this.status = d.status;
    this.sources = d.sources;
    this.issuesList = d.issuesList;
    this.riskLevel = d.riskLevel;
  }
}
export interface OrganisationPayload {
  name: string;
  abrExtract: ABRExtract;
  asicExtract: ASICExtract;
  industry: Industry;
  giin: string | null;
  addresses: Address[];
  officeHolders: Entity[] | null;
  shareHolders: Entity[] | null;
  kyc: KYCResults;
  aml: AMLResultSet<OrganisationAmlCriteria> | null;
  stock?: StockInformation | null;
  entityId: EntityId;
  roles?: TAssociationRole[];
  percentageHolding?: PercentageHolding;
}
export type KYBReportTemplate = "SINGLE-LEVEL" | "SINGLE-LEVEL-AML" | "UBO";
export class Organisation
  implements OrganisationPayload, IsEntity, HasAmlStatus, ShareHolder, OfficeHolder, HasAddress, HasDisplayableName
{
  entityId: EntityId;
  name: string;
  abrExtract: ABRExtract;
  asicExtract: ASICExtract;
  industry: Industry;
  giin: string | null;
  addresses: Address[];
  officeHolders: Entity[] | null;
  shareHolders: Entity[] | null;
  stock?: StockInformation | null;
  aml: AMLResultSet<OrganisationAmlCriteria> | null;
  kyc: KYCResults;
  roles?: TAssociationRole[] = [];
  percentageHolding?: PercentageHolding;

  private entityType = "ORGANISATION";
  private ownership: Dictionary<OwnershipObject>;
  private startDate: string | null;
  private type: string | null;

  constructor(d: OrganisationPayload) {
    this.name = d.name;
    this.abrExtract = d.abrExtract;
    this.asicExtract = d.asicExtract;
    this.industry = d.industry;
    this.giin = d.giin;
    this.addresses = d.addresses;
    this.kyc = d.kyc;
    this.officeHolders = d.officeHolders;
    this.shareHolders = d.shareHolders;
    this.aml = d.aml;
    this.stock = d.stock;
    this.ownership = {};
    this.entityId = d.entityId;
    this.startDate = null;
    this.type = null;
    this.roles = d.roles;
    this.percentageHolding = d.percentageHolding;

    this.entityTypeCode; // calling this interrupts pdf generation when asic type is missing (look getter below) !!!
  }
  setOfficeholderType(type: string) {
    this.type = type;
    return this;
  }
  getOfficeholderType(): string {
    return this.type || "";
  }
  setOfficeholderStartDate(date: string) {
    this.startDate = date;
    return this;
  }
  getOfficeholderStartDate(): string {
    return this.startDate || "";
  }

  setEntityType(type: string): Organisation {
    this.entityType = type;
    return this;
  }
  getEntityType() {
    return this.theEntityType!;
  }
  setOwnership(ownership: Dictionary<OwnershipObject>): Organisation {
    this.ownership = ownership;
    return this;
  }
  getOwnership(): Dictionary<OwnershipObject> {
    return this.ownership;
  }

  get addressLongForm(): string {
    if (this.addresses.length === 0) return "";
    return this.addresses[0].longForm;
  }
  get amlCount(): number {
    return this.aml?.count ?? 0;
  }
  get checkTypes(): string[] {
    return this.aml?.checkTypes ?? [];
  }
  get checkTypeNames(): string[] {
    return this.aml?.checkTypeNames ?? [];
  }
  get adverseMediaStatus(): AdverseMediaStatus {
    return this.aml?.adverseMediaStatus ?? new AdverseMediaStatus(null);
  }
  get alerts(): string[] {
    return this.aml?.alerts ?? [];
  }
  get alertNames(): string[] {
    return this.aml?.alertNames ?? [];
  }
  get theEntityType(): string {
    return this.entityType;
  }
  get abn(): string {
    return this.abrExtract?.abn;
  }
  get acn(): string {
    return this.asicExtract?.acn;
  }
  get arbn(): string {
    return this.asicExtract?.arbn;
  }
  get asicEntityType(): string {
    return this.asicExtract?.companyType;
  }
  get abrEntityType(): string {
    return this.abrExtract?.entityType;
  }
  get organisationType(): string {
    return this.asicEntityType || this.abrEntityType || "";
  }
  get entityTypeCode(): string {
    const upper = this.organisationType.toUpperCase() || this.asicExtract.companyTypeCode?.toUpperCase() || "";

    if (
      [
        upper === "PRV",
        upper === "APTY",
        upper === "IND",
        upper.search("PRIVATE") !== -1,
        upper.search("PROPRIETARY") !== -1,
        upper.search("INDIVIDUAL") !== -1,
      ].some(Boolean)
    )
      return "PRV";

    if ([upper === "PUB", upper === "APUB", upper.search("PUBLIC") !== -1].some(Boolean)) return "PUB";

    return upper;
  }
  get uuid(): string {
    return btoa(`${this.abn}${this.acn}`);
  }
}
export interface OfficeHolder {
  setOfficeholderType: (type: string) => OfficeHolder;
  getOfficeholderType: () => string;
  setOfficeholderStartDate: (date: string) => OfficeHolder;
  getOfficeholderStartDate: () => string;
}

export interface ShareHolder {
  setEntityType: (type: string) => ShareHolder;
  getEntityType: () => string;
  setOwnership: (ownership: Dictionary<OwnershipObject>) => ShareHolder;
  getOwnership: () => Dictionary<OwnershipObject>;
}

export class Address {
  type: string;
  longForm: string;
  startDate: string;
  constructor(d: { type: string; longForm: string; startDate: string }) {
    this.type = d.type;
    this.longForm = d.longForm;
    this.startDate = d.startDate;
  }
  get typeFormatted(): string {
    const nicefyAddressType = (code: string): string => {
      switch (code) {
        case "OTHER":
          return "Other";
        case "RESIDENTIAL1":
        case "RESIDENTIAL2":
        case "RESIDENTIAL3":
        case "RESIDENTIAL4":
        case "RESIDENTIAL":
          return "Residential";
        case "BUSINESS":
          return "Business";
        case "POSTAL":
          return "Postal";
        case "REGISTERED_OFFICE":
          return "Registered Office";
        case "PLACE_OF_BUSINESS":
          return "Place of Business";
        case "OFFICIAL_CORRESPONDANCE":
          return "Official Correspondance";
        default:
          return code;
      }
    };
    return nicefyAddressType(this.type);
  }
}
export class Industry {
  anzsic: string[];
  constructor(d: { anzsic: string[] }) {
    this.anzsic = d.anzsic;
  }
}

export type TBusinessName = {
  name: string;
  effectiveFrom: Nullable<string>;
  effectiveTo: Nullable<string>;
};

export type TABNStatus = {
  status: Nullable<string>;
  effectiveFrom: Nullable<string>;
};

export class ABRExtract {
  entityName: string;
  abn: string;
  registrationDate: string;
  entityStatus: string;
  entityType: string;
  gstStatus: string;
  location: string;
  businessNames: TBusinessName[];
  historicalBusinessNames: TBusinessName[];
  tradingNames: string[];
  abnLastUpdated: string;
  abnStatus: Nullable<TABNStatus>;

  constructor(d: {
    entityName: string;
    abn: string;
    registrationDate: string;
    entityStatus: string;
    entityType: string;
    gstStatus: string;
    location: string;
    businessNames: TBusinessName[];
    historicalBusinessNames: TBusinessName[];
    tradingNames: string[];
    abnLastUpdated: string;
    abnStatus: Nullable<TABNStatus>;
  }) {
    this.entityName = d.entityName;
    this.abn = d.abn;
    this.registrationDate = d.registrationDate;
    this.entityStatus = d.entityStatus;
    this.entityType = d.entityType;
    this.gstStatus = d.gstStatus;
    this.location = d.location;
    this.businessNames = d.businessNames;
    this.tradingNames = d.tradingNames;
    this.abnLastUpdated = d.abnLastUpdated;
    this.historicalBusinessNames = d.historicalBusinessNames;
    this.abnStatus = d.abnStatus;
  }
}
export class ASICExtract {
  static targetExtractDate: string;
  extractDate: string;
  companyName: string;
  acn: string;
  registrationDate: string;
  status: string;
  companyType: string;
  class: string;
  subClass: string;
  locality: string;
  stateOfRegistration: string;
  arbn: string;
  subClassCode: string;
  companyTypeCode: string;
  constructor(d: {
    extractDate: string;
    companyName: string;
    acn: string;
    registrationDate: string;
    status: string;
    companyType: string;
    class: string;
    subClass: string;
    locality: string;
    stateOfRegistration: string;
    arbn: string;
    subClassCode: string;
    companyTypeCode: string;
  }) {
    this.extractDate = d.extractDate;
    this.companyName = d.companyName;
    this.acn = d.acn;
    this.registrationDate = d.registrationDate;
    this.status = d.status;
    this.companyType = d.companyType;
    this.class = d.class;
    this.subClass = d.subClass;
    this.locality = d.locality;
    this.stateOfRegistration = d.stateOfRegistration;
    this.arbn = d.arbn;
    this.subClassCode = d.subClassCode;
    this.companyTypeCode = d.companyTypeCode;
  }
}
export class StockInformation {
  exchange: string;
  ticker: string;
  country: string;
  approved: boolean;
  screenshot: boolean | string;
  screenshotDate: string;
  constructor(d: {
    exchange: string;
    ticker: string;
    country: string;
    approved: boolean;
    screenshot: string | boolean;
    screenshotDate: string;
  }) {
    this.exchange = d.exchange;
    this.ticker = d.ticker;
    this.country = d.country;
    this.approved = d.approved;
    this.screenshot = d.screenshot;
    this.screenshotDate = d.screenshotDate;
  }
  addScreenshotBase64(base64) {
    this.screenshot = `data:${base64}`;
  }
}
export interface AMLMatchPayload {
  name: string;
  category: string;
  country: string;
  originalCountryText: string;
  countries: string[];
  dateOfBirth: string;
  aka: string[];
  associates: Associate[];
  mediaReferences: MediaReference[];
}
export class AMLMatch implements AMLMatchPayload, HasAmlStatus {
  name: string;
  category: string;
  country: string;
  originalCountryText: string;
  countries: string[];
  dateOfBirth: string;
  aka: string[];
  associates: Associate[];
  mediaReferences: MediaReference[];
  constructor(d: AMLMatchPayload) {
    this.name = d.name;
    this.category = d.category;
    this.country = d.country;
    this.originalCountryText = d.originalCountryText;
    this.countries = d.countries;
    this.dateOfBirth = d.dateOfBirth;
    this.aka = d.aka;
    this.associates = d.associates;
    this.mediaReferences = d.mediaReferences;
  }
  get alerts(): string[] {
    const alerts: string[] = [];
    if (this.mediaReferences.length > 0) alerts.push("m");
    return alerts;
  }
  get alertNames() {
    const mapAlertToTitle = (alert: string) => {
      switch (alert) {
        case "m":
          return "Adverse Media";
        default:
          return "-";
      }
    };
    return this.alerts.map(mapAlertToTitle);
  }
  get adverseMediaStatus() {
    const hasMediaIssues = this.mediaReferences.length > 0;
    const code = hasMediaIssues ? "POT_MATCH" : "NO_MATCH";
    return new AdverseMediaStatus(code);
  }
}
export class MediaReference {
  at: string;
  title: string;
  url: string;
  constructor(d: { at: string; title: string; url: string }) {
    this.at = d.at;
    this.title = d.title;
    this.url = d.url;
  }
}
export class Associate {
  constructor(public association: string, public name: string) {}
}

type ComposedLabel = [string, string]; // composed of ui element

export class CheckResult {
  constructor(public status: Badge, public text: string) {}
}
export abstract class Badge {
  constructor(public code: string | null) {}
  abstract get label(): ComposedLabel | string;
  abstract get type(): "success" | "warn" | "fail" | null;

  isEmpty(): boolean {
    return !this.code;
  }
  asBadgeMixin() {
    let badgeObject: {
      label: ComposedLabel | string;
      type: string;
    } | null = null;
    if (!this.isEmpty()) {
      badgeObject = {
        label: this.label,
        type: this.type!,
      };
    }
    return ["badge", badgeObject];
  }
}
export type PassedStatusCodes = "PASS" | "FAIL" | "WARN" | null;
export class PassedStatus extends Badge {
  constructor(code: PassedStatusCodes) {
    super(code);
  }
  get label(): ComposedLabel {
    switch (this.code) {
      case "PASS":
        return ["icon", "checked"];
      case "WARN":
        return ["icon", "warn"];
      case "FAIL":
        return ["icon", "failed"];
      default:
        return ["icon", "warn"];
    }
  }
  get type() {
    switch (this.code) {
      case "PASS":
        return "success";
      case "WARN":
        return "warn";
      case "FAIL":
        return "fail";
      default:
        return null;
    }
  }
}
export class AdverseMediaStatus extends Badge {
  constructor(code: "NO_MATCH" | "POT_MATCH" | null) {
    super(code);
  }
  get label(): string {
    switch (this.code) {
      case "POT_MATCH":
        return "Potential Match";
      case "NO_MATCH":
        return "No Match";
      default:
        return "Invalid Status";
    }
  }
  get type() {
    switch (this.code) {
      case "POT_MATCH":
        return "warn";
      case "NO_MATCH":
        return "success";
      default:
        return null;
    }
  }
}
export class KYCStatus extends Badge {
  constructor(code: PassedStatusCodes) {
    super(code);
  }
  get label(): string {
    switch (this.code) {
      case "PASS":
        return "Pass";
      case "WARN":
        return "Partial Match";
      case "FAIL":
        return "Fail";
      default:
        return "Invalid Status";
    }
  }
  get type() {
    switch (this.code) {
      case "PASS":
        return "success";
      case "WARN":
        return "warn";
      case "FAIL":
        return "fail";
      default:
        return null;
    }
  }
}
