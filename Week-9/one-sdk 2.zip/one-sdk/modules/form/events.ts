import type { Modules } from '@config';
import type { Applicant } from '@module/common/shared/models/Applicant';
import type { Document } from '@module/common/shared/models/Document';

import type { FormModule } from './definition';
import type { React_Form_IDS } from './vendors/react/types/pages.type';

type Vendor = FormModule['vendorName'];

export type EventPayload = {
  componentName: Modules['moduleName'];
  provider: Vendor;
  inputInfo: { formName: React_Form_IDS; type?: 'ocr' | 'manual' };
};

export type FormEvents = {
  loaded: [{ domElement: HTMLElement; provider: string }];
  ready: [{ domElement: HTMLElement }];
  results: [
    {
      documents: Document[];
      applicant: Applicant;
      entityId: string;
    }
  ];
  navigation: [{ page: string }];
  builtin_loaded: EventPayload[];
  builtin_ready: EventPayload[];
  builtin_failed_loading: { message?: string }[];
};
