import { getDot } from "../utils/dotNotation";
import { HasValidation, UINodeType, ValidationMessageDictionary, ValidationMessageUnit } from "./Blueprint";
import { DynamicUIComponent } from "./DynamicUIComponent";
import { Dictionary } from "./general";

type UIBlueprintOptions = { ref?: string } & (
  | {
      root: DynamicUIComponent;
      children?: Dictionary<UINodeType>;
    }
  | {
      root?: DynamicUIComponent;
      children: Dictionary<UINodeType>;
    }
);
const mkRandomRef = () => Math.floor(Math.random() * 99999999999).toString(16);
// const isDynamicComponent = (c: UINodeType): c is DynamicUIComponent => (c as DynamicUIComponent).isDynamicComponent;
export class UIBlueprint implements HasValidation<ValidationMessageDictionary> {
  readonly isUIBlueprint = true;
  private _ref: string;
  private _root: DynamicUIComponent | null;
  private _children: Dictionary<UINodeType>;

  constructor(options: UIBlueprintOptions) {
    this._ref = options.ref ?? mkRandomRef();
    this._root = options.root ?? null;
    this._children = reassignRefs(options.children ?? {});
  }

  ref(): string {
    return this._ref;
  }
  root(): DynamicUIComponent | null {
    return this._root;
  }
  children(): Dictionary<UINodeType> {
    return this._children;
  }
  setChildren(children: Dictionary<UINodeType>) {
    this._children = children;
  }

  getChild(path: string): UINodeType {
    const dotReadMethod = (blue: UIBlueprint, child: string) => blue._children[child];
    return getDot(path, this, dotReadMethod) as UINodeType;
  }
  private getParentOf(path: string) {
    // split path into array of child keys
    const splitPath = path.split(".");
    // if path only contains one key, then parent is current blueprint
    if (splitPath.length === 1) return this;
    // otherwise, lose the last child key
    splitPath.pop();
    // join remaining keys again, resulting in path to parent
    const pathToParent = splitPath.join(".");
    const lastParent = this.getChild(pathToParent) as UIBlueprint;
    return lastParent;
  }
  setRef(ref: string) {
    this._ref = ref;
  }
  setChild(path: string, child: UINodeType): boolean {
    const isBlueprint = (node: UINodeType): node is UIBlueprint => (node as UIBlueprint)?.isUIBlueprint;
    const parent = this.getParentOf(path);
    const childKey = path.split(".").pop() as string;
    if (childKey && isBlueprint(parent)) {
      parent._children[childKey] = child;
      return true;
    }
    return false;
  }
  removeChild(path: string): boolean {
    const isBlueprint = (node: UINodeType): node is UIBlueprint => (node as UIBlueprint)?.isUIBlueprint;
    const parent = this.getParentOf(path);
    const childKey = path.split(".").pop() as string;
    if (childKey && isBlueprint(parent)) {
      delete parent._children[childKey];
      return true;
    }
    return false;
  }
  isValid(): ValidationMessageDictionary {
    const dictPrepended = (
      v: ValidationMessageDictionary | ValidationMessageUnit,
      childKey: string
    ): ValidationMessageDictionary => {
      // -> dictPrepend is the overall isValid value for the whole tree of nodes
      // -- any errors on the tree are returned as a dictionary of "dot.notation": "error message" | false
      // -- valid tree structures are returned as simply boolean true
      // -> v is the value of each childKey.isValid()

      // if value is true, isValid result remain true
      if (v === true) return true;
      // if value of child already is a dictionary of "isValid" values (for deep tree structures),
      // prepend keys with childKey, since childKey is the key to the root of this existing dictionary
      // this will build the dot notation dictionary keys
      if (typeof v === "object") {
        const keys = Object.keys(v);
        const val = (k) => v[k];
        return keys.reduce((obj, k) => {
          obj[`${childKey}.${k}`] = val(k);
          return obj;
        }, {});
      }
      // if value of child.isValid is string or boolean false,
      // than child is an invalid leaf and its value should be returned as a dictionary
      return { [childKey]: v };
    };
    const mergeChildrenIsValidResult = (
      merged: ValidationMessageDictionary,
      childKey: string
    ): ValidationMessageDictionary => {
      const child = this._children[childKey];
      const value = typeof child === "string" ? true : child.isValid();
      const parsedValue = dictPrepended(value, childKey);
      const isObject = (v: any): v is Dictionary => typeof v === "object";
      const isBool = (v: any): v is boolean => typeof v === "boolean";
      // if both are objects, merge them
      if (isObject(parsedValue) && isObject(merged))
        return {
          ...merged,
          ...parsedValue,
        };
      // if one is object and the other is a boolean, return the object
      if (isObject(parsedValue) && isBool(merged)) return parsedValue;
      if (isObject(merged) && isBool(parsedValue)) return merged;

      return merged;
    };
    const keys = Object.keys(this._children);
    return keys.reduce(mergeChildrenIsValidResult, true);
  }

  toJSON(): UIBlueprintOptions {
    return JSON.parse(
      JSON.stringify({
        root: this._root,
        children: this._children,
      })
    );
  }
  static fromJSON(payload: UIBlueprintOptions): UIBlueprint {
    return new UIBlueprint(payload);
  }
  clone(): UIBlueprint {
    return UIBlueprint.fromJSON(this.toJSON());
  }
}
function reassignRefs(children: Dictionary<UINodeType>) {
  const keys = Object.keys(children);
  const reassignedRefs = keys.reduce((obj: Dictionary<UINodeType>, key: string) => {
    const node: UINodeType = children[key];
    if (typeof node !== "string") node.setRef(key);
    obj[key] = node;
    return obj;
  }, {});
  return reassignedRefs;
}
// helpers for children array
// function validateChildren(children: Dictionary<UINodeType> | UINodeType[]): UINodeType[] {
//   const childArray: UINodeType[] = Array.isArray(children) ? children : assignKeysToRef(children);

//   ensureUniqueRefs(childArray);

//   return childArray;
// }
// function ensureUniqueRefs(children: UINodeType[]) {
//   const jsonIt = it => JSON.stringify(it);
//   const mkError = (i: number, iObj: DynamicUIComponent, j: number, jObj: DynamicUIComponent) => new Error(
//     `Child [${i}] contains a repeated ref to child [${j}], which not allowed for blueprints to index and find children unambiguously` +
//     `
//     ${i}: ${jsonIt(iObj)}
//     ${j}: ${jsonIt(jObj)}
//     `
//   );
//   const extractRef = (child: DynamicUIComponent) => child.ref();
//   const refs = children.filter(isDynamicComponent).map(extractRef);
//   refs.forEach((ref, i) => {
//     const get = (k: number) => children[k] as DynamicUIComponent;
//     const j = refs.indexOf(ref);
//     if (j !== i) throw mkError(i, get(i), j, get(j));
//   })
// }
// function assignKeysToRef(children: Dictionary<UINodeType>): UINodeType[] {

//   const keys = Object.keys(children);
//   return keys.map(k => {
//     const child = children[k];
//     if (isDynamicComponent(child)) {
//       child.setRef(k);
//     }
//     return child;
//   })
// }
