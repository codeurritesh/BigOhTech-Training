import type { JsonPrimitive } from 'type-fest';

export type EmptyValue = undefined | null | unknown;
export type Primitive = JsonPrimitive | bigint | symbol | undefined | null;
export type EmptyObject = Record<string, never>;
export type AnyObject = Record<string, unknown>;
export type ObjectWith<Keys extends string> = Record<Keys, unknown>;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type AnyFunction<Args extends unknown[] = unknown[], ReturnType = unknown> = (...args: Args) => ReturnType;
export type Dictionary<Value = unknown, Type extends 'read' | 'write' | 'readwrite' = 'write'> = Type extends 'read'
  ? _DictionaryRead<Value>
  : Type extends 'write'
  ? _DictionaryWrite<Value>
  : Type extends 'readwrite'
  ? _DictionaryReadWrite<Value>
  : never;

export type _DictionaryRead<Value> = {
  readonly [x: string]: Value;
};
export type _DictionaryWrite<Value> = {
  [x: string]: Value;
};
export type _DictionaryReadWrite<Value> = _DictionaryRead<Value> & _DictionaryWrite<Value>;
