export const v4 = () => "mocked-uuid-package-" + String(Math.floor(Math.random() * 99999)).padStart(5);
