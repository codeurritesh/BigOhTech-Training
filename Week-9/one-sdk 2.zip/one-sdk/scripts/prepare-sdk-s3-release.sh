#!/bin/bash
# takes build dist directory as argument $1
# uses environment variable BITBUCKET_DEPLOYMENT_ENVIRONMENT and returns a target bucket for one sdk
deployment=$BITBUCKET_DEPLOYMENT_ENVIRONMENT

# Define assets bucket. if deployment is prod-cdn, bucket is production, otherwise bucket is dev
if [[ $deployment == "prod-cdn" ]]; then
  oneSdkTargetBucket="assets-frankiefinancial-io-assetsstorebucket-1jp1njzhzyckc/one-sdk"
else
  oneSdkTargetBucket="frankie-assets-dev/one-sdk"
fi

echo "$oneSdkTargetBucket"
