import type { Applicant, IApplicantPayload } from "./Applicant";
import type { CheckSummary, ICheckSummaryPayload } from "./CheckSummary";
import type { IDocumentPayload } from "./Document";
import type { ISupportingDocumentPayload, SupportingDocument } from "./SupportingDocument";

export type TStatusType =
  | "failed"
  | "passed"
  | "fail_manual"
  | "pass_manual"
  | "refer"
  | "wait"
  | "unchecked"
  | "archived"
  | "inactive";
export declare interface IMachineCredential {
  customerId: string;
  customerChildId?: string | null;
  apiKey: string;
}
export declare interface IUserCredential {
  username: string;
  password: string;
}
export declare type IFrankieClientCredentials = IMachineCredential | IUserCredential;
export declare interface IApplicantInformation {
  applicant: Applicant;
  documents?: Document[];
  supportingDocuments?: SupportingDocument[];
}
export declare interface ICreateApplicantResponse {
  entityId: string;
  requestId: string;
}

export type SearchOptions = {
  reference: string;
  entityId: string;
};

export declare interface IUserRole {
  id: number;
  role: string;
  isHidden: boolean;
  permissions: [];
  createdAt: {
    date: Date;
  };
}

export declare interface ICreateUser {
  userData: ICreateUserData;
}

export declare interface ICreateUserData {
  realname: string;
  username: string;
  email: string;
  roleIds: number[];
}

export declare interface ITriggerChecksResponse {
  hasCreditHeaderIssue: boolean;
  detailLevel: TDetailLevel;
}

export declare interface IGetExternalIdvToken {
  token: string;
}

export declare type TDetailLevel = "full";

export declare interface IGetApplicantDetailsResponse {
  applicant: IApplicantPayload;
  documents: IDocumentPayload[];
  checkSummary: ICheckSummaryPayload;
}

export declare interface IGetApplicantInformationResponse {
  applicant: IApplicantPayload;
  documents: IDocumentPayload[];
  supportingDocuments: ISupportingDocumentPayload[];
}
export interface ICreateIDVTokenResponse {
  token: string;
  applicant: IApplicantPayload;
  documents: IDocumentPayload[];
  checkSummary: ICheckSummaryPayload;
  docTypesRequiredToCheck: IDocumentPayload["idType"][];
  idvTwoDocuments: boolean;
}
export interface IApplicantDetails {
  applicant: Applicant;
  documents: Document[];
  checkSummary: CheckSummary;
}
export interface IGetCommits {
  coreApiCommitId: string;
  adminApiCommitId: boolean;
}
export interface IAnalyticsData {
  [organizationId: string]: IOrganizationAnalytics;
}
export type IOrganizationAnalytics = {
  pass_rate: TPassRateAnalytics;
  risk_level: TRiskLevelAnalytics;
  issues: TIssueCount[];
};

export type TPassRateAnalytics = {
  passed: number;
  manually_passed: number;
  failed: number;
  manually_failed: number;
  needs_attention: number;
  unchecked: number;
  pending: number;
  duplicate: number;
  archived: number;
  inactive: number;
};
export type TRiskLevelAnalytics = {
  high: number;
  low: number;
  medium: number;
  unacceptable: number;
  unknown: number;
};
export type TIssueCount = {
  type: string;
  count: number;
};

export interface TEventPayload {
  entityId: string;
  customerReference: string;
  channel: string;
  customerId: string;
  customerChildId: string;
  sessionId: string;
  version: string;
  environment: string;
  browser: {
    name: string;
    version: string;
    userAgent: string;
    language: string;
  };
  device: {
    type: "desktop" | "tablet" | "mobile";
    screen: {
      height: number;
      width: number;
      availableHeight: number;
      availableWidth: number;
      colorDepth: number;
      orientation: OrientationType;
      pixelDepth: number;
    };
    model: string;
    osName: string;
    osVersion: string;
  } & Record<string, unknown>;
  data: Record<string, unknown>;
}
