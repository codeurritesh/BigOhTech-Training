import jwtEncode from 'jwt-encode';

import type { EventHub } from '@module/common';
import { mkEventHub } from '@module/common';
import type { InjectedState } from '@module/common/types';
import { ModeObject } from '@module/common/types';
import _FederationModule from '@module/federation';
import { parseConfiguration as _parseConfiguration } from '@module/federation/parseConfiguration';
import { FrankieApiClient } from '@module/frankie-client';
import type { OneSdkContext } from '@module/sdk/types';
import { SdkModes } from '@module/sdk/types';
import { SessionContext } from '@module/session/SessionContext';
import { optionalParameters } from '@tests/testUtils/functionUtilities';

import { mockEventHub } from '../mocks/EventHub';

const parseConfiguration = optionalParameters(_parseConfiguration);
const FederationModule = optionalParameters(_FederationModule);
const mkOneSdkInstance = (o: { isPreloaded: boolean }) => {
  return <OneSdkContext>{
    individual: () => ({
      isPreloaded: () => o.isPreloaded,
    }),
  };
};
describe('Federation initialisation', () => {
  test('Initialising component returns the module context successfully', () => {
    jest.spyOn(Date, 'now').mockReturnValue(1668681813365); // epoch in milliseconds
    const providedToken = jwtEncode(
      {
        data: {
          environment: 'https://some-environment.com',
          sessionId: 'some-session-id',
          reference: 'some-reference',
          organisation: {
            customerId: 'customer-id',
          },
        },
        exp: 1668681815, // epoch in seconds
      },
      'secret',
    );
    const federationModuleContext = FederationModule({
      mode: new ModeObject(SdkModes.DEV),
      moduleMeta: { moduleName: 'federation', instanceName: 'federation' },
      oneSdkInstance: mkOneSdkInstance({ isPreloaded: false }),
      globalEventHub: mockEventHub(),
      session: { token: providedToken } as SessionContext,
      recipe: {
        name: 'auto',
        federation: 'singpass',
        idps: {
          singpass: {
            redirect_url: 'https://fake.url',
            environment: 'production',
          },
        },
      },

      frankieClient: {} as FrankieApiClient,
      telemetry: false,
    });

    expect(federationModuleContext).toMatchObject({
      start: expect.any(Function),
      on: expect.any(Function),
      off: expect.any(Function),
    });
  });
  test('Initialising Federation with a stored token will update session to use that token', () => {
    jest.spyOn(Date, 'now').mockReturnValue(1668681813365); // epoch in milliseconds
    const providedToken = jwtEncode(
      {
        data: {
          environment: 'https://some-environment.com',
          sessionId: 'provided-session-id',
          reference: 'some-reference',
          organisation: {
            customerId: 'customer-id',
          },
        },
        exp: 1668681815, // epoch in seconds
      },
      'secret',
    );
    const storedToken = jwtEncode(
      {
        data: {
          environment: 'https://some-environment.com',
          sessionId: 'stored-session-id',
          reference: 'some-reference',
          organisation: {
            customerId: 'customer-id',
          },
        },
        exp: 1668681815, // epoch in seconds
      },
      'secret',
    );
    jest.spyOn(Storage.prototype, 'getItem').mockReset().mockReturnValue(JSON.stringify(storedToken));

    const frankieClientSetter = jest.fn();
    const sessionGetter = jest.fn().mockReturnValue({ token: providedToken });
    const sessionSetter = jest.fn().mockImplementation((value) => {
      sessionGetter.mockReturnValue(value);
    });

    FederationModule(<InjectedState>{
      mode: new ModeObject(SdkModes.DEV),
      moduleMeta: { moduleName: 'federation', instanceName: 'federation' },
      oneSdkInstance: mkOneSdkInstance({ isPreloaded: false }),
      globalEventHub: mkEventHub(),
      get session() {
        return sessionGetter();
      },
      set session(session) {
        sessionSetter(session);
      },
      set frankieClient(client) {
        frankieClientSetter(client);
      },
      recipe: {
        federation: 'singpass',
        idps: {
          singpass: {
            redirect_url: 'https://fake.url',
            environment: 'production',
          },
        },
      },
    });
    const [[frankieClient]] = frankieClientSetter.mock.calls;
    const [[sessionContext]] = sessionSetter.mock.calls;

    expect(frankieClient).toEqual(expect.any(FrankieApiClient));
    expect(frankieClient.token).toEqual(storedToken);
    expect(sessionContext).toEqual(expect.any(SessionContext));
    expect(sessionContext.token).toEqual(storedToken);
  });
  test('Initialising Federation without a stored token will leave session as is', () => {
    jest.spyOn(Date, 'now').mockReturnValue(1668681813365); // epoch in milliseconds
    const providedToken = jwtEncode(
      {
        data: {
          environment: 'https://some-environment.com',
          sessionId: 'provided-session-id',
          reference: 'some-reference',
          organisation: {
            customerId: 'customer-id',
          },
        },
        exp: 1668681815, // epoch in seconds
      },
      'secret',
    );
    jest.spyOn(Storage.prototype, 'getItem').mockReset();

    const frankieClientSetter = jest.fn();
    const sessionGetter = jest.fn().mockReturnValue({ token: providedToken });
    const sessionSetter = jest.fn().mockImplementation((value) => {
      sessionGetter.mockReturnValue(value);
    });

    FederationModule(<InjectedState>{
      mode: new ModeObject(SdkModes.DEV),
      moduleMeta: { moduleName: 'federation', instanceName: 'federation' },
      oneSdkInstance: mkOneSdkInstance({ isPreloaded: false }),
      globalEventHub: mkEventHub(),
      get session() {
        return sessionGetter();
      },
      set session(session) {
        sessionSetter(session);
      },
      set frankieClient(client) {
        frankieClientSetter(client);
      },
      recipe: {
        federation: 'singpass',
        idps: {
          singpass: {
            redirect_url: 'https://fake.url',
            environment: 'production',
          },
        },
      },
    });

    expect(frankieClientSetter).toHaveBeenCalledWith(
      expect.objectContaining({
        token: providedToken,
      }),
    );
    expect(sessionSetter).toHaveBeenCalledWith(
      expect.objectContaining({
        token: providedToken,
      }),
    );
  });
});

describe('Configuration parsing', () => {
  test("Missing 'federation' fails parsing", () => {
    expect(() => {
      parseConfiguration(<InjectedState>{
        recipe: {
          name: 'auto',
          idps: {
            singpass: {
              redirect_url: '',
              environment: 'production',
            },
          },
        },
        oneSdkInstance: mkOneSdkInstance({ isPreloaded: false }),
      });
    }).toThrow(/Missing 'recipe.federation'/i);
  });
  test("Missing idp for the configured 'federation' fails parsing", () => {
    expect(() => {
      parseConfiguration({
        recipe: {
          name: 'auto',
          federation: 'google' as 'singpass',
          idps: {
            singpass: {
              redirect_url: '',
              environment: 'production',
            },
          },
        },
        oneSdkInstance: mkOneSdkInstance({ isPreloaded: false }),
        globalEventHub: {} as EventHub,
        frankieClient: {} as FrankieApiClient,
        session: {} as SessionContext,
        mode: {} as ModeObject,
        moduleMeta: {
          instanceName: '',
          moduleName: 'individual',
        },
        telemetry: false,
      });
    }).toThrow(/Idp 'google' missing from 'recipe.idps' configuration/i);
  });
  test('Initialising federation with singpass idp missing redirect_url fails parsing', () => {
    expect(() => {
      parseConfiguration(<InjectedState>{
        recipe: {
          name: 'auto',
          federation: 'singpass',
          idps: {
            singpass: {},
          },
        },
        oneSdkInstance: mkOneSdkInstance({ isPreloaded: false }),
      });
    }).toThrow(/'singpass.redirect_url' is required/i);
  });
  test('Initialising federation with singpass idp with invalid url in redirect_url fails parsing', () => {
    expect(() => {
      parseConfiguration(<InjectedState>{
        recipe: {
          name: 'auto',
          federation: 'singpass',
          idps: {
            singpass: {
              redirect_url: '',
            },
          },
        },
        oneSdkInstance: mkOneSdkInstance({ isPreloaded: false }),
      });
    }).toThrow(/The specified 'singpass.redirect_url' needs to be a valid URL/i);
  });
  test('Initialising federation in production with singpass idp with insecure url in redirect_url fails parsing', () => {
    expect(() => {
      parseConfiguration(<InjectedState>{
        recipe: {
          name: 'auto',
          federation: 'singpass',
          idps: {
            singpass: {
              redirect_url: 'http://fake.url',
              environment: 'production',
            },
          },
        },
        oneSdkInstance: mkOneSdkInstance({ isPreloaded: false }),
      });
    }).toThrow(/The specified 'singpass.redirect_url' needs to be a secure https URL/i);
  });
  test('Initialising federation with an existing entity fails parsing', () => {
    expect(() => {
      parseConfiguration(<InjectedState>{
        recipe: {
          name: 'auto',
          federation: 'singpass',
          idps: {
            singpass: {
              redirect_url: '',
            },
          },
        },
        oneSdkInstance: mkOneSdkInstance({ isPreloaded: true }),
      });
    }).toThrow(/Federation component initialised with an existing entity/i);
  });
});
