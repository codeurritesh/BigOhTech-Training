import { IReportAttributePayload, ReportAttribute } from "./ReportAttributes";
interface IOCRReportPayload {
  checkDate: string;
  result: string;
  items: IReportAttributePayload[];
}

interface IOCRReportConstructor {
  checkDate: string | null;
  result: string | null;
  items?: ReportAttribute[];
}

export class OCRReport {
  checkDate: string;
  result: string;
  items?: ReportAttribute[];
  constructor(r?: IOCRReportConstructor) {
    this.checkDate = r?.checkDate || "";
    this.result = r?.result || "";
    this.items = r?.items;
  }

  toJSON(): IOCRReportPayload {
    const items: IReportAttributePayload[] = this.items.map((i) => i.toJSON());

    return {
      ...this,
      items,
    };
  }

  static fromJSON(payload: IOCRReportPayload): OCRReport {
    const items = payload?.items.map((m) => ReportAttribute.fromJSON(m));

    return new OCRReport({
      ...payload,
      items,
    });
  }
}
