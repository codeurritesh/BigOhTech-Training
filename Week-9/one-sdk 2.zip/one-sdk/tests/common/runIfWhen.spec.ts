import { mkEventHub, runIfWhen } from "@module/common";
describe("runIfWhen", () => {
  test("Returns a promise which Runs callback immediately when condition is true", () => {
    const callback = jest.fn().mockImplementation((v) => `${v}-returned`);
    const runner = runIfWhen({
      run: callback,
      condition: () => true,
    });
    const returned = runner("the-value");
    expect(callback).toHaveBeenCalledWith("the-value");
    return expect(returned).resolves.toBe("the-value-returned");
  });
  test("Returns a promise which doesn't run callback when condition is not true", () => {
    const callback = jest.fn().mockImplementation((v) => `${v}-returned`);
    const runner = runIfWhen({
      run: callback,
      condition: () => false,
    });
    const returned = runner("the-value");
    expect(callback).not.toHaveBeenCalled();
    expect(returned).toBe(undefined);
  });
  test("Returns a promise that will resolve when the event name passed in 'elseWaitFor' doesn't run callback when condition is not true", () => {
    const eventHub = mkEventHub();
    const callback = jest.fn().mockImplementation((v) => `${v}-returned`);
    const runner = runIfWhen({
      run: callback,
      condition: () => false,
      elseWaitFor: "waited-for",
      on: eventHub,
    });
    const returned = runner("the-value");
    expect(callback).not.toHaveBeenCalled();
    eventHub.emit("waited-for");
    expect(callback).toHaveBeenCalledWith("the-value");
    return expect(returned).resolves.toBe("the-value-returned");
  });
  test("Returns a promise that will resolve when the event name passed in 'elseWaitFor' doesn't run callback when condition is not true", () => {
    const eventHub = mkEventHub();
    const callback = jest.fn().mockImplementation((v) => `${v}-returned`);
    const runner = runIfWhen({
      run: callback,
      condition: () => false,
      elseWaitFor: "waited-for",
      on: eventHub,
      timeoutMilliSecond: 100,
    });
    const returned = runner("the-value");
    expect(callback).not.toHaveBeenCalled();
    return expect(returned).rejects.toBe("Timed out in 100 milliseconds.");
  });
});
