import { Document } from '@module/common/shared/models/Document';
import { mkAddDocument, mkUpdateDocument } from '@module/individual/actions/documents';

import { mockAccessors } from '../mocks/ReactiveStore';

const mkDocument = (details) => Object.assign(new Document(), details);
describe('Individual module: addDocument and updateDocument', () => {
  test('Documents array is updated with call to addDocument', async () => {
    const documents$ = mockAccessors<Document[]>({
      documents: [mkDocument({ idNumber: '1' }), mkDocument({ idNumber: '2' })],
    });
    const addDocument = mkAddDocument({ documents$ });
    addDocument(mkDocument({ idNumber: '3', country: 'BRA' }));

    expect(documents$.getValue()).toMatchObject([
      mkDocument({ idNumber: '1' }),
      mkDocument({ idNumber: '2' }),
      mkDocument({ idNumber: '3', country: 'BRA' }),
    ]);
  });
  test('Existing document with the same documentId is updated with a call to updateDocument', () => {
    const documents$ = mockAccessors<Document[]>({
      documents: [mkDocument({ idNumber: '1' }), mkDocument({ idNumber: '2', documentId: 'the-id' })],
    });
    const updateDocument = mkUpdateDocument({ documents$ });
    updateDocument('the-id', mkDocument({ idNumber: '3', country: 'BRA' }));

    expect(documents$.getValue()).toMatchObject([
      mkDocument({ idNumber: '1' }),
      mkDocument({ idNumber: '3', country: 'BRA', documentId: 'the-id' }),
    ]);
  });
  test('updateDocument with non existing document id will throw exception', () => {
    const documents$ = mockAccessors<Document[]>({
      documents: [mkDocument({ idNumber: '1' })],
    });
    const updateDocument = mkUpdateDocument({ documents$ });
    expect(() => updateDocument('the-id', mkDocument({ idNumber: '3', country: 'BRA' }))).toThrowError();

    expect(documents$.getValue()).toMatchObject([mkDocument({ idNumber: '1' })]);
  });
});
