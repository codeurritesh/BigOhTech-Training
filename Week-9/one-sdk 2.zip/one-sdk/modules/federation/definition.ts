import type { EventHub } from "@module/common";
import type { ModuleDefinition } from "@module/common/types";
import type { Events } from "./events";

export type FederationModule = ModuleDefinition<{
  module: {
    category: "component";
    name: "federation";
    context: {
      start: () => void;
    };
    events: Events;
  };
  wrapper: {
    vendors: ["singpass"];
    options: {
      eventHub: EventHub<Events>;
    };
    loadType: "async";
  };
}>;
