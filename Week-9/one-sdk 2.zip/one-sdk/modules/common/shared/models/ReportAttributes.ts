export interface IReportAttributePayload {
  key: string;
  title: string;
  value: boolean | null;
  items?: IReportAttributePayload[];
}

export interface IReportAttributeConstructor {
  key: string;
  title: string;
  value: boolean | null;
  items?: ReportAttribute[];
}

export class ReportAttribute implements IReportAttributePayload {
  key: string;
  title: string;
  value: boolean | null;
  items?: ReportAttribute[];
  constructor(attr: IReportAttributeConstructor) {
    this.key = attr.key || "";
    this.value = attr.value;
    this.title = attr.title || "";
    this.items = attr?.items || [];
  }

  toJSON(): IReportAttributePayload {
    const items: IReportAttributePayload[] = this.items.map((i) => i.toJSON());

    return {
      ...this,
      items,
    };
  }

  static fromJSON(payload: IReportAttributePayload): ReportAttribute {
    const items: ReportAttribute[] = payload?.items?.map((m) => ReportAttribute.fromJSON(m)) || [];

    return new ReportAttribute({
      ...payload,
      items,
    });
  }
}
