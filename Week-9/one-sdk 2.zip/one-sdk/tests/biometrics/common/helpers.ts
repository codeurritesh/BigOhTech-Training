import type { IDVStatus, OneSdkContext } from '@frankieone/one-sdk';
import BiometricsModule from '@module/biometrics';
import { mkEventHub } from '@module/common';
import type { Document } from '@module/common/shared/models/Document';
import type { ModeObject } from '@module/common/types';
import { URL_PARAM } from '@module/frankie-client/DummyFrankieApiClient';
import type { RecipeParsed } from '@module/sdk/types';
import { SdkModes } from '@module/sdk/types';
import type { SessionContext } from '@module/session/SessionContext';
import { mockFrankieClient } from '@tests/mocks/FrankieClient';
import { optionalParameters } from '@tests/testUtils/functionUtilities';

import type { AxiosResponse } from 'axios';

export const mkBiometricsComponent = ({
  recipe,
  mockPost,
  mockResponse,
}: {
  recipe: RecipeParsed;
  mockPost?: () => Promise<AxiosResponse<unknown>>;
  mockResponse?: { checkStatus: IDVStatus; ocrDocument?: Document };
}) => {
  const { frankieClient } = mockFrankieClient({ sessionType: 'entityId' });
  frankieClient.stubResponse(
    {
      url: new RegExp(`data/v2/idvCheck/${URL_PARAM}/initProcess`),
      method: 'post',
    },
    () => ({
      data: { ...mockResponse },
    }),
  );
  frankieClient.stubResponse(
    {
      url: new RegExp(`/data/v2/idvCheck/token`),
      method: 'post',
    },
    () => ({
      data: {
        token: 'token',
        vendorParameters: { clientId: '', interviewId: '', token: '' },
        entityId: 'entityId',
      },
    }),
  );
  if (mockPost) {
    jest.spyOn(frankieClient, 'post').mockImplementation(mockPost);
  }
  return optionalParameters(BiometricsModule)({
    moduleMeta: { moduleName: 'biometrics', instanceName: 'biometrics' },
    mode: { modeName: SdkModes.DEV } as ModeObject,
    recipe,
    frankieClient,
    globalEventHub: mkEventHub(),

    oneSdkInstance: {} as OneSdkContext,
    telemetry: false,
    session: {} as SessionContext,
  }, {});
};
