import { Modules } from "@config";
import { IndividualModuleContext } from "@module/individual";
import { ModuleContext } from "../../common/types/oneSDKModules";
import { GlobalEvents } from "./globalEvents";
import { OneSdkRootParameters } from "./oneSDKParameters";
import { SessionFacade } from "@module/session/SessionFacade";

export type OneSdkContext = ModuleContext<
  {
    individual: () => ModuleContext<IndividualModuleContext>;
    component: Modules["factoryFunctions"]["component"];
    flow: Modules["factoryFunctions"]["flow"];
    session: SessionFacade;
  },
  GlobalEvents
>;
export type OneSdkModule = {
  initialise(p: OneSdkRootParameters): Promise<OneSdkContext>;
};

