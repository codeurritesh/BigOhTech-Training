import { IRiskLevelConstructor } from "../models/ApplicantSummary";

export function getRiskLevel(key: string): IRiskLevelConstructor {
  switch (typeof key) {
    case "string":
      key = key.toLowerCase();
      break;
    case "object":
      return key;
    default:
      key = "unknown";
  }

  const norm: IRiskLevelConstructor = { key, label: "", term: "" };
  switch (key) {
    case "significant":
      norm.term = "risk_significant";
      norm.label = "Significant";
      break;
    case "unacceptable":
      norm.term = "risk_unacceptable";
      norm.label = "Unacceptable";
      break;
    case "low":
      norm.term = "risk_low";
      norm.label = "Low";
      break;
    case "medium":
      norm.term = "risk_medium";
      norm.label = "Medium";
      break;
    case "high":
      norm.term = "risk_high";
      norm.label = "High";
      break;
    case "unknown":
    default:
      norm.term = "risk_unknown";
      norm.label = "Unknown";
  }

  return norm;
}
