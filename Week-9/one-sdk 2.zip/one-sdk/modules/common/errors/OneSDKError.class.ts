export class OneSDKError<Payload = unknown> extends Error {
  readonly payload: Payload;
  constructor(message: string, payload: Payload) {
    super(message);
    this.payload = payload;
  }
}
