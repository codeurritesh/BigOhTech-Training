import { Address } from '@module/common/shared/models/Address';
import { mkAddAddress, mkUpdateAddress } from '@module/individual/actions/addresses';

import { mockAccessors } from '../mocks/ReactiveStore';

const mkAddress = (details: Partial<Address>) => Object.assign(new Address(), details);
describe('Individual module: addAddress and updateAddress', () => {
  test('Addresss array is updated with call to addAddress', async () => {
    const addresses$ = mockAccessors<Address[]>({
      addresses: [mkAddress({ addressId: '1' }), mkAddress({ longForm: 'some, address' })],
    });
    const addAddress = mkAddAddress({ addresses$ });
    addAddress(mkAddress({ longForm: 'some, address', country: 'BRA' }));

    expect(addresses$.getValue()).toMatchObject([
      mkAddress({ addressId: '1' }),
      mkAddress({ longForm: 'some, address' }),
      mkAddress({ longForm: 'some, address', country: 'BRA' }),
    ]);
  });
  test('Existing address with the same addressId is updated with a call to updateAddress', () => {
    const addresses$ = mockAccessors<Address[]>({
      addresses: [
        mkAddress({ longForm: 'some, address' }),
        mkAddress({ longForm: 'some, address', addressId: 'the-id' }),
      ],
    });
    const updateAddress = mkUpdateAddress({ addresses$ });
    updateAddress('the-id', mkAddress({ longForm: 'some, address', country: 'BRA' }));

    expect(addresses$.getValue()).toMatchObject([
      mkAddress({ longForm: 'some, address' }),
      mkAddress({ longForm: 'some, address', country: 'BRA', addressId: 'the-id' }),
    ]);
  });
  test('updateAddress with non existing address id will throw exception', () => {
    const addresses$ = mockAccessors<Address[]>({
      addresses: [mkAddress({ longForm: 'some, address' })],
    });
    const updateAddress = mkUpdateAddress({ addresses$ });
    expect(() => updateAddress('the-id', mkAddress({ longForm: 'some, address', country: 'BRA' }))).toThrowError();

    expect(addresses$.getValue()).toMatchObject([mkAddress({ longForm: 'some, address' })]);
  });
});
