import type { TelemetryEvent } from "@module/common/shared/models/TelemetryEvent";
import { GlobalState, InjectedState } from "@module/common/types";

export type GlobalEvents = {
  // omit event hub so customers don't have access to private methods
  resolved_root_config: [Omit<GlobalState, "globalEventHub" | "oneSdkInstance">];
  resolved_module_config: [InjectedState, unknown];
  // telemetry events might contain an event name and extra data, or simply an event name
  telemetry: [string | { eventName: string; data?: TelemetryEvent["data"]; error?: Error }];
};
