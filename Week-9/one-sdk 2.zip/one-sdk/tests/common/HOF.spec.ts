import { runOnce } from "@module/common/modules/HOF";

describe("HOF: High Order Functions", () => {
  describe("runOnce", () => {
    test("Calling once: Without parameters or return values", () => {
      const func = runOnce(() => void 0, "Error message");
      expect(func()).toBe(undefined);
    });
    test("Calling once: With parameters and return values", () => {
      const func = runOnce(
        (arg1: string, arg2: number, arg3: boolean) => parseInt(arg1) + arg2 + Number(arg3),
        "Error message"
      );
      // false is converted to zero
      expect(func("1", 2, false)).toBe(3);
    });
    test("Calling twice: Error is thrown", () => {
      const func = runOnce(
        (arg1: string, arg2: number, arg3: boolean) => parseInt(arg1) + arg2 + Number(arg3),
        "Error message"
      );
      // false is converted to zero
      expect(func("1", 2, false)).toBe(3);
      expect(() => func("1", 2, false)).toThrow("Error message");
    });
  });
});
