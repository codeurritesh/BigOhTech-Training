import { RecipeConfiguration } from "@module/common";
import { ActivityType, Vendor } from "./constants";

export type Events = {
  configuration_loaded: [RecipeConfiguration];
  activity_started: [{ activityType: ActivityType }];
  device_characteristics_extracted: [{ deviceCharacteristics: Record<string, string | number | object> }];
  completed: [Core["DeviceDetailsObject"]];
  vendor_sdk_loaded: [{ vendor: Vendor }];
  vendor_sdk_failed_loading: [{ vendor: Vendor; errorObject: unknown }];
  session_data_generated: [{ session: unknown }];
  value_set: [{ key: string; value: unknown }];
};
// temporary core mocked interface
interface Core {
  DeviceDetailsObject: Record<string, never>;
}
