import { Path } from "ts-toolbelt/out/Object/Path";
import { Split } from "ts-toolbelt/out/String/Split";

export type TypeOfProperty<Target, DotPath extends string> = Path<Target, Split<DotPath, ".">>;
