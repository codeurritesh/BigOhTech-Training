import type { AnyFunction } from '@types';

import type { PartialDeep } from 'type-fest';

export type OptionalParameters<F extends AnyFunction> = (...args: PartialDeep<Parameters<F>>) => ReturnType<F>;

export const optionalParameters = <F extends AnyFunction<A, R>, A extends unknown[] = unknown[], R = void>(func: F) =>
  func as OptionalParameters<typeof func>;
export const mockFunction = <T extends AnyFunction>(fn: T) => <jest.Mock & T>fn;
