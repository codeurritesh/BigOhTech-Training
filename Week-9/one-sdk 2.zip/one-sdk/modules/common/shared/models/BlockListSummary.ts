import { Nullable } from "./general";

export interface IBlockListRecord {
  entityId: Nullable<string>;
  attribute: Nullable<string>;
  description: Nullable<string>;
  reason: Nullable<string>;
  createdDate: Nullable<string>;
  lastUpdated: Nullable<string>;
  addedBy: Nullable<string>;
  duplicateBlocklistResolved: Nullable<boolean>;
}
export enum EnumBlocklistAttribute {
  "ENTIRE_ENTITY" = "ENTIRE_ENTITY",
  "MAILING_ADDRESS" = "MAILING_ADDRESS",
  "RESIDENTIAL_ADDRESS" = "RESIDENTIAL_ADDRESS",
  "EMAIL_ADDRESS" = "EMAIL_ADDRESS",
  "PHONE_NUMBER" = "PHONE_NUMBER",
  "ID_DOCUMENT" = "ID_DOCUMENT",
  "NAME_AND_DOB" = "NAME_AND_DOB",
}

export interface IBlocklistSummary {
  records: IBlockListRecord[];
  nextPageMarker: Nullable<string>;
}
export interface IBlockListSummaryPayload {
  records: IBlockListRecord[];
  nextPageMarker: Nullable<string>;
}
export class BlockListSummary {
  records: BlocklistRecord[] = [];
  nextPageMarker: Nullable<string> = null;
  static fromJSON(payload: IBlockListSummaryPayload): BlockListSummary {
    const instance = new BlockListSummary();
    instance.records = payload.records?.map((record) => BlocklistRecord.fromJSON(record)) ?? [];
    instance.nextPageMarker = payload.nextPageMarker ?? null;
    return instance;
  }
  toJSON(): BlockListSummary {
    const records = this.records.map((record) => record.toJSON());
    return { ...this, records };
  }
}

export class BlocklistRecord {
  entityId: Nullable<string> = null;
  attribute: Nullable<string> = null;
  description: Nullable<string> = null;
  reason: Nullable<string> = null;
  createdDate: Nullable<string> = null;
  lastUpdated: Nullable<string> = null;
  addedBy: Nullable<string> = null;
  duplicateBlocklistResolved: Nullable<boolean> = null;
  static fromJSON(payload: IBlockListRecord) {
    const instance = new BlocklistRecord();
    instance.entityId = payload.entityId ?? null;
    instance.attribute = payload.attribute ?? null;
    instance.description = payload.description ?? null;
    instance.reason = payload.reason ?? null;
    instance.createdDate = payload.createdDate ?? null;
    instance.lastUpdated = payload.lastUpdated ?? null;
    instance.addedBy = payload.addedBy ?? null;
    instance.duplicateBlocklistResolved = payload.duplicateBlocklistResolved ?? null;
    return instance;
  }
  toJSON() {
    return { ...this };
  }
}
