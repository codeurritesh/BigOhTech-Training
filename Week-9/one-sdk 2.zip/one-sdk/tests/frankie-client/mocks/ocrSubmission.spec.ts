import { mkEventHub } from '@module/common';
import { DummyFrankieApiClient } from '@module/frankie-client';
import { OCRClient, OCRStatus } from '@module/frankie-client/clients/OCRClient';
import { createOCRDocument, updateOCRDocument } from '@module/frankie-client/mocks/ocr/ocrSubmission';
import { resolveScans } from '@module/frankie-client/mocks/options/simplified/preloadedIndividual';

import { dateMatcher, mockedUuidMatcher } from '../../testUtils/patterns';

describe('Dummy mode: OCR Submission POST request', () => {
  test('Successfully submitting POST with both DRIVERS_LICENCE scans and COMPLETE_OCR result', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });

    createOCRDocument(dummyClient, {
      ocrRequests: {
        detectedType: 'DRIVERS_LICENCE',
        postResponsePayload: {
          status: OCRStatus.COMPLETE,
          ocrDocument: { scans: resolveScans('both') },
        },
        updateResponsePayloads: [],
      },
    });

    const ocrClient = new OCRClient(dummyClient);
    const { documentStatus, ocrDocument } = await ocrClient.attachNewOCRDocument(new File([''], 'filename.jpeg'));

    expect(documentStatus).toEqual(OCRStatus.COMPLETE);
    expect(ocrDocument).toMatchObject({
      idType: 'DRIVERS_LICENCE',
      documentId: mockedUuidMatcher,
      scans: [
        expect.objectContaining({
          mimeType: 'image/jpeg',
          scanCreated: dateMatcher,
          scanId: mockedUuidMatcher,
          side: 'F',
          scanName: 'dl-front.jpg',
          file: null,
          fileUploadUuid: null,
        }),
        expect.objectContaining({
          mimeType: 'image/jpeg',
          scanCreated: dateMatcher,
          scanId: mockedUuidMatcher,
          side: 'B',
          scanName: 'dl-back.jpg',
          file: null,
          fileUploadUuid: null,
        }),
      ],
    });
  });
  test('Successfully submitting POST with front scan only', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });

    createOCRDocument(dummyClient, {
      ocrRequests: {
        detectedType: 'DRIVERS_LICENCE',
        postResponsePayload: {
          status: OCRStatus.COMPLETE,
          ocrDocument: { scans: resolveScans('F') },
        },
        updateResponsePayloads: [],
      },
    });

    const ocrClient = new OCRClient(dummyClient);
    const { documentStatus, ocrDocument } = await ocrClient.attachNewOCRDocument(new File([''], 'filename.jpeg'));

    expect(documentStatus).toEqual(OCRStatus.COMPLETE);
    expect(ocrDocument).toMatchObject({
      idType: 'DRIVERS_LICENCE',
      documentId: mockedUuidMatcher,
      scans: [
        expect.objectContaining({
          mimeType: 'image/jpeg',
          scanCreated: dateMatcher,
          scanId: mockedUuidMatcher,
          side: 'F',
          scanName: 'dl-front.jpg',
          file: null,
          fileUploadUuid: null,
        }),
      ],
    });
  });
  test('Getting all ocrDocument defaults when leaving option ocrDocument empty', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });
    const idType = 'DRIVERS_LICENCE';
    const status = OCRStatus.COMPLETE;

    createOCRDocument(dummyClient, {
      ocrRequests: {
        detectedType: idType,
        postResponsePayload: {
          status,
          ocrDocument: {},
        },
        updateResponsePayloads: [],
      },
    });

    const ocrClient = new OCRClient(dummyClient);
    const { documentStatus, ocrDocument } = await ocrClient.attachNewOCRDocument(new File([''], 'filename.jpeg'));

    expect(documentStatus).toEqual(OCRStatus.COMPLETE);
    expect(ocrDocument).toMatchObject({
      idType,
      documentId: mockedUuidMatcher,
      scans: [],
      country: 'AUS',
      dateOfBirth: null,
      extraData: {},
      gender: null,
      idExpiry: '0001-01-01',
      idNumber: 'P77864526',
      idSubType: null,
      ocrResult: {
        status,
        runDate: dateMatcher,
        documentTypeInternal: idType,
        dateOfExpiry: '2031-05-28',
        dateOfIssue: '2021-05-28',
        documentType: idType,
        documentNumber: 'P77864526',
        dateOfBirth: '1990-01-01',
        nationality: 'AUS',
        issuingState: null,
        issuingCountry: 'AUS',
        state: 'VIC',
        postcode: '3000',
        town: 'Melbourne',
        street: '80 Collins Street',
        firstName: 'PETER',
        lastName: 'TESTTHIRTEEN',
        mismatch: ['firstName', 'lastName', 'documentNumber', 'dateOfBirth'],
      },
      region: 'VIC',
      validation: {
        electronic: {
          isValid: true,
          validationReport: null,
        },
        manual: {
          isValid: null,
        },
      },
      verified: {
        electronic: null,
        manual: null,
      },
    });
  });
});

describe('Dummy mode: OCR Submission PUT request', () => {
  test('Succesfully submitting PUT receiving COMPLETE status and both scans back', async () => {
    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
      defaultDelay: 0,
    });

    updateOCRDocument(dummyClient, {
      preloadedIndividual: {
        documents: [],
      },
      ocrRequests: {
        detectedType: 'DRIVERS_LICENCE',
        updateResponsePayloads: [
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: {
              documentId: 'preloaded-uuid',
              ocrResult: { documentNumber: 'any-number' },
              scans: resolveScans('both'),
            },
          },
        ],
        postResponsePayload: {
          status: OCRStatus.WAITING_OCR_RUN,
          ocrDocument: {},
        },
      },
    });
    const ocrClient = new OCRClient(dummyClient);
    const { documentStatus, ocrDocument } = await ocrClient.updateOCRDocument(
      new File([''], 'filename.jpeg'),
      'doc-uuid',
    );
    expect(documentStatus).toBe(OCRStatus.COMPLETE);
    expect(ocrDocument).toMatchObject({
      documentId: 'doc-uuid',
      ocrResult: {
        documentNumber: 'any-number',
      },
      scans: [
        expect.objectContaining({
          side: 'F',
        }),
        expect.objectContaining({
          side: 'B',
        }),
      ],
    });
  });
});
