import type { OneSdkContext } from '@module/types';

import { INCLUDE } from '../config';
import { useOneSdkState } from '../onesdk/useOneSdkState';

import { Form } from './Form';

export function IndividualDetailsForm(o: { oneSdk: OneSdkContext }) {
  const { oneSdk } = o;
  const individual = oneSdk.individual();
  const [isLoading] = useOneSdkState(individual.access('isLoading'));
  const [name, setName] = useOneSdkState(individual.access('name'));
  const [consents] = useOneSdkState(individual.access('consentsGiven'));
  const [isPersisted] = useOneSdkState(individual.access('isPersisted'));
  const [dateOfBirth] = useOneSdkState(individual.access('dateOfBirth'));
  const [addresses] = useOneSdkState(individual.access('addresses'));
  const [documents] = useOneSdkState(individual.access('documents'));
  const fullName = [
    name.givenName,
    name.middleName,
    name.familyName,
  ].filter(Boolean).join(' ');
  const giveConsent = () => {
    individual.addConsent('general');
    individual.addConsent('docs');
    individual.addConsent('creditheader');
  };

  const addRandomReference = () => {
    const randKey = Math.random().toString(36).substring(2, 10);
    const randValue = Math.random().toString(36).substring(2, 16);
    individual.addReference('reference-' + randKey, randValue);
  };
  const includeForm = INCLUDE['form'];

  return (
    <div style={{ opacity: isLoading ? 0.5 : 1 }}>
      <h2>Update your name</h2>
      {
        <input
          placeholder="First name"
          value={name?.givenName ?? ''}
          onChange={({ target: { value } }) => setName({
            ...name,
            givenName: value,
          })}
        />
      }
      {
        <input
          placeholder="Last name"
          value={name?.familyName ?? ''}
          onChange={({ target: { value } }) => setName({
            ...name,
            familyName: value,
          })}
        />
      }
      {fullName && <p>Your name is {fullName}</p>}
      {consents.length > 0 &&
        <p>List of consents: {JSON.stringify(consents)}</p>}
      <button disabled={isLoading || consents.length > 0}
              value={name?.familyName ?? ''} onClick={giveConsent}>
        {!consents.length ? 'Give consent' : <>Consent given &#10003;</>}
      </button>
      <button disabled={isLoading} onClick={addRandomReference}>
        Add random reference
      </button>
      <p>Is persisted: {isPersisted ? 'Yes' : 'No'}</p>
      <h3>Individual details</h3>
      <pre style={{ textAlign: 'left' }}>
        {JSON.stringify(
          {
            name,
            dateOfBirth,
            addresses,
            documents,
          },
          null,
          2,
        )}
      </pre>
      {includeForm && <Form oneSdk={oneSdk} />}
    </div>
  );
}
