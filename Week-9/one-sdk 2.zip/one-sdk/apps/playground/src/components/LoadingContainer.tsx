import type { CSSProperties } from 'react';

export const FullScreenContainer = ({ loading, mounted, id }) => {
  const containerStyle: CSSProperties = {
    width: '100%',
    height: mounted ? '100%' : '0',
    display: mounted ? 'block' : 'none',
    top: '0',
    left: '0',
    position: 'fixed',
    margin: '0 auto',
    background: 'white',
    overflowY: 'auto',
  };
  const loadingStyles: CSSProperties = {
    position: 'absolute',
    width: '100%',
    height: '100%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    background: 'white',
  };
  const mountElStyles: CSSProperties = {
    width: '100%',
    height: '100%',
    display: 'block',
    position: 'absolute',
  };
  return (
    <div style={containerStyle}>
      <div id={id} style={mountElStyles}></div>
      {loading && <h3 style={loadingStyles}>Loading...</h3>}
    </div>
  );
};
