import { Applicant } from "@module/common/shared/models/Applicant";
import { mkAddReference } from "@module/individual/actions/addReference";
import { mockEventHub } from "@tests/mocks/EventHub";
import { mockAccessors } from "@tests/mocks/ReactiveStore";

describe("individual::addReference", () => {
  test("addReference with two parameters (key, value) adds an additionalReference entry to the applicant object", () => {
    const initialApplicant = new Applicant();
    const applicant$ = mockAccessors({
      applicant: initialApplicant
    });
    const eventHub = mockEventHub();
    const addReference = mkAddReference({
      applicant$,
      eventHub,
    });
    
    addReference("foo", "bar");
    expect(applicant$.setValue).toHaveBeenCalledWith(expect.objectContaining({
      additionalReferences: {
        foo: "bar",
      },
    }));
    expect(applicant$.getValue().additionalReferences.foo).toBe("bar");
  });
  test("addReference with ONE parameter (value) adds to the main customerReference of the applicant object", () => {
    const initialApplicant = new Applicant();
    const applicant$ = mockAccessors({
      applicant: initialApplicant
    });
    const eventHub = mockEventHub();
    const addReference = mkAddReference({
      applicant$,
      eventHub,
    });
    
    addReference("foobar");
    expect(applicant$.setValue).toHaveBeenCalledWith(expect.objectContaining({
      customerReference: "foobar",
      additionalReferences: {}
    }));
    expect(applicant$.getValue().customerReference).toBe("foobar");
  });
  test("addReference with repeated additional reference (two parameters) will not have any effect", () => {
    const initialApplicant = new Applicant();
    initialApplicant.additionalReferences["foo"] = "bar";

    const applicant$ = mockAccessors({
      applicant: initialApplicant
    });
    const eventHub = mockEventHub();
    const addReference = mkAddReference({
      applicant$,
      eventHub,
    });
    
    addReference("foo", "updated");
    expect(applicant$.setValue).not.toHaveBeenCalled();
    expect(applicant$.getValue().additionalReferences.foo).toBe("bar");
  });
  test("addReference with repeated main customer reference (one parameter) will throw error if value is different to existing value", () => {
    const initialApplicant = new Applicant();
    initialApplicant.customerReference = "bar";

    const applicant$ = mockAccessors({
      applicant: initialApplicant
    });
    const eventHub = mockEventHub();
    const addReference = mkAddReference({
      applicant$,
      eventHub,
    });
    
    expect(() => addReference("updated")).toThrowError("Customer reference already set. You cannot change it.");
    expect(applicant$.setValue).not.toHaveBeenCalled();
    expect(applicant$.getValue().customerReference).toBe("bar");
  });
  test("addReference with repeated main customer reference (one parameter) will not throw error if value is the same as existing value", () => {
    const initialApplicant = new Applicant();
    initialApplicant.customerReference = "bar";

    const applicant$ = mockAccessors({
      applicant: initialApplicant
    });
    const eventHub = mockEventHub();
    const addReference = mkAddReference({
      applicant$,
      eventHub,
    });
    
    expect(() => addReference("bar")).not.toThrowError();
    expect(applicant$.setValue).not.toHaveBeenCalled();
    expect(applicant$.getValue().customerReference).toBe("bar");
  });
});