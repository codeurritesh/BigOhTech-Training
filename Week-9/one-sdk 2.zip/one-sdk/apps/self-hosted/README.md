ATTENTION: For types to work during development, first build the OneSDK using `npm run build:esm`, if not already built in `<project-root>/dist/esm`

# How sessions work

**ONLY IN DEVELOPMENT** and when the URL doesn't contain the parameters `t` or `j`, In `src/index.html` a `<script>` tag takes care of generating a new session token using whatever credentials are defined in the `<project-root>.env` file, just like the `playground` application used for development of the OneSDK.
