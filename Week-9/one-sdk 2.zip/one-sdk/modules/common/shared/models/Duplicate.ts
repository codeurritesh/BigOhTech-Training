interface IDuplicatePayload {
  entityId: string;
  matchStrength: number | null;
  matches: {
    personal: string[];
    documents: {
      documentId: string | null;
      field: string[];
    };
  };
}

interface IDuplicateConstructor {
  entityId: string;
  matches: {
    personal: string[];
    documents: {
      documentId: string | null;
      field: string[];
    };
  };
  matchStrength?: number | null,
}

interface IMatches {
  personal: string[];
  documents: {
    documentId: string | null;
    field: string[];
  };
}
export class DuplicateResults implements IDuplicatePayload {
  entityId: string;
  matchStrength: number | null;
  matches = {
    personal: [],
    documents: {
      documentId: null,
      field: [],
    },
  } as IMatches;
  constructor(payload?: IDuplicateConstructor) {
    this.entityId = payload?.entityId || "";
    this.matches.documents = payload?.matches?.documents || {
      documentId: null,
      field: [],
    };
    this.matches.personal = payload?.matches?.personal || [];
    this.matchStrength = payload?.matchStrength || null;
  }

  toJSON(): IDuplicatePayload{
    return { ...this};
  }

  static fromJSON(payload: IDuplicatePayload): DuplicateResults{
    return new DuplicateResults({...payload});
  }
}
