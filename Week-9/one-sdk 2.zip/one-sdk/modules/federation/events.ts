export type Events = {
  results: [individual: object, status: string, approve: () => void];
  data_extracted_successfully: [data: {entityId: string}];
};
