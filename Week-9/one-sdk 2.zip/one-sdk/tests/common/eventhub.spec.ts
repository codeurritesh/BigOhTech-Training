import { mkEventHub } from '@module/common';

describe('Event hub', () => {
  test('You may subscribe to an event that will trigger when emitted', () => {
    const eventHub = mkEventHub();
    const listener = jest.fn();
    eventHub.on('eventName', listener);
    eventHub.emit('eventName', 'a', 'b', 'c');
    expect(listener).toHaveBeenCalledWith('a', 'b', 'c');
  });
  test("You may subscribe to a wildcard event '*' that will trigger whenever any event is emitted", () => {
    const eventHub = mkEventHub();
    const listener = jest.fn();
    eventHub.on('*', listener);
    eventHub.emit('eventName', 'a', 'b', 'c');
    eventHub.emit('eventName2', 'd', 'e', 'f');

    expect(listener).toHaveBeenNthCalledWith(1, { eventName: 'eventName', arguments: ['a', 'b', 'c'] });
    expect(listener).toHaveBeenNthCalledWith(2, { eventName: 'eventName2', arguments: ['d', 'e', 'f'] });
  });
  test('Triggering an event before listening, will simply miss it', () => {
    const eventHub = mkEventHub();
    const listener = jest.fn();
    eventHub.emit('eventName', 'a', 'b', 'c');
    eventHub.emit('eventName2', 'd', 'e', 'f');
    eventHub.on('*', listener);
    expect(listener).not.toHaveBeenCalled();
  });
  test("When calling off on a specific listener, that listener is removed and won't be called again", () => {
    const eventHub = mkEventHub();
    const listener = jest.fn();
    eventHub.on('eventName', listener);
    eventHub.emit('eventName', 'a', 'b', 'c');
    eventHub.off('eventName', listener);
    eventHub.emit('eventName', 'd', 'e', 'f');
    expect(listener).toHaveBeenCalledOnce();
  });
  test("When no event name is provided to 'off', it will remove all listeners for all events", () => {
    const eventHub = mkEventHub();
    const listener = jest.fn();
    eventHub.on('*', listener);
    eventHub.off();
    eventHub.emit('eventName', 'a', 'b', 'c');
    eventHub.emit('eventName2', 'd', 'e', 'f');
    expect(listener).toHaveBeenCalledOnce();
    expect(listener).toHaveBeenCalledWith(expect.objectContaining({ eventName: '__off__' }));
  });
  test.todo(
    "Removing all listeners for a specific event when an event name is provided to 'off' method, it will remove all listeners for that event",
  );
  test("When providing event name and event hub to 'map' method, it will map the event to the same event name in the provided event hub", () => {
    const eventHub = mkEventHub();
    const proxyEventHub = mkEventHub();
    const listener = jest.fn();
    proxyEventHub.on('eventName', listener);
    eventHub.map('eventName', proxyEventHub);
    eventHub.emit('eventName', 'a', 'b', 'c');
    expect(listener).toHaveBeenCalledWith('a', 'b', 'c');
  });
  test("When providing event name, event hub and a second event name to 'map' method, it will map the event to the second event in the provided event hub", () => {
    const eventHub = mkEventHub();
    const proxyEventHub = mkEventHub();
    const listener = jest.fn();
    proxyEventHub.on('proxiedEventName', listener);
    eventHub.map('eventName', proxyEventHub, 'proxiedEventName');
    eventHub.emit('eventName', 'a', 'b', 'c');
    expect(listener).toHaveBeenCalledWith('a', 'b', 'c');
  });
  test('You may subscribe to many events that will all trigger when emitted', () => {
    const eventHub = mkEventHub();
    const listenerA = jest.fn();

    eventHub.on(['eventA', 'eventB'], listenerA);

    eventHub.emit('eventC');
    expect(listenerA).not.toHaveBeenCalled();

    eventHub.emit('eventA', 'a', 'b', 'c');
    expect(listenerA).toHaveBeenCalledWith('a', 'b', 'c');
    expect(listenerA).toHaveBeenCalledOnce();

    eventHub.emit('eventB', 'c', 'b', 'a');
    expect(listenerA).toHaveBeenCalledWith('a', 'b', 'c');
    expect(listenerA).toHaveBeenCalledWith('c', 'b', 'a');
  });
  test("when calling off with no parameters, reemit '__off__' before removing all listeners", () => {
    const eventHub = mkEventHub();
    const listener = jest.fn();

    eventHub.on('__off__', listener);
    eventHub.off();
    expect(listener).toHaveBeenCalled();
    expect(eventHub.hasListenersFor('__off__')).toBe(false);
  });
});
