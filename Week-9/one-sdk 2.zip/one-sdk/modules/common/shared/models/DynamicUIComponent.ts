import { stripOutScriptTagFromString } from "../utils";
import { HasValidation, LeafNode, ValidationMessageUnit } from "./Blueprint";
import { Dictionary } from "./general";

const mkRandomRef = () => Math.floor(Math.random() * 99999999999).toString(16);
type Listener = (...a: any[]) => void;
type ValidationOption = (c: DynamicUIComponent) => ValidationMessageUnit;
interface DynamicUiOptions {
  tag: string;
  classes?: string[];
  id?: string;
  attrs?: Dictionary;
  listeners?: Dictionary<Listener>;
  content?: LeafNode;
  slots?: Dictionary<LeafNode>;
  validation?: ValidationOption;
  ref?: string;
}
export class DynamicUIComponent implements HasValidation<ValidationMessageUnit> {
  readonly isDynamicComponent = true;
  private _tag = "";
  private _classes: string[] = [];
  private _attrs: Dictionary = {};
  private _listeners: Dictionary<Listener> = {};
  private _id?: string;
  private _content: LeafNode | null = null;
  private _validation: ValidationOption = () => true;
  private _slots: Dictionary<LeafNode> = {};
  private _ref: string = mkRandomRef();

  constructor(init: DynamicUiOptions) {
    this.setTag(init.tag);
    this.setId(init.id ?? "");
    this.setClasses(init.classes ?? []);
    this.setAttrs(init.attrs ?? {});
    this.setListeners(init.listeners ?? {});
    this.setValidation(init.validation ?? (() => true));
    this.setSlots(init.slots ?? {});
    if (init.ref) this.setRef(init.ref);
    if (init.content) this.setContent(init.content);
  }

  isValid() {
    return this._validation.bind(this)(this);
  }
  setTag(tag: string) {
    this._tag = tag;
  }
  setId(id: string) {
    this._id = id;
  }
  setClasses(classes: string[]) {
    this._classes = classes;
  }
  setListeners(listeners: Dictionary<Listener>) {
    this._listeners = listeners;
  }
  setAttrs(attrs: Dictionary) {
    this._attrs = attrs;
  }
  setListener(key: string, listener: Listener) {
    this._listeners[key] = listener;
  }
  setAttr(key: string, value: any) {
    this._attrs[key] = value;
  }
  setRef(ref: string) {
    this._ref = ref;
  }
  setValidation(validation: ValidationOption) {
    this._validation = validation;
  }
  setContent(content: LeafNode) {
    if (typeof content === "string") content = stripOutScriptTagFromString(content);
    this._content = content;
  }
  setSlots(slots: Dictionary<LeafNode>) {
    const keys = Object.keys(slots);
    const ifStringSanitiseIt = (maybeStr) => {
      if (typeof maybeStr === "string") return stripOutScriptTagFromString(maybeStr);
      return maybeStr;
    };
    const sanitizedSlots = {};
    keys.forEach((key) => (sanitizedSlots[key] = ifStringSanitiseIt(slots[key])));
    this._slots = sanitizedSlots;
  }

  ref(): string {
    return this._ref;
  }
  tag(): DynamicUIComponent["_tag"] {
    return this._tag;
  }
  classes(): DynamicUIComponent["_classes"] {
    return this._classes;
  }
  attrs(): Dictionary {
    return this._attrs;
  }
  listeners(): Dictionary<Listener> {
    return this._listeners;
  }
  id(): DynamicUIComponent["_id"] {
    return this._id;
  }
  content(): LeafNode | null {
    return this._content;
  }
  slots(): Dictionary<LeafNode> {
    return this._slots;
  }

  toJSON(): Omit<DynamicUiOptions, "listeners"> {
    return JSON.parse(
      JSON.stringify({
        ref: this._ref,
        tag: this._tag,
        id: this._id,
        classes: this._classes,
        attrs: this._attrs,
        content: this._content,
      })
    );
  }
  static fromJSON(payload: Omit<DynamicUiOptions, "listeners">) {
    return new DynamicUIComponent(payload);
  }
  clone(): DynamicUIComponent {
    const listeners = this.listeners();
    const payload = this.toJSON();
    const copy = DynamicUIComponent.fromJSON(payload);
    copy.setListeners(listeners);
    return copy;
  }
}
