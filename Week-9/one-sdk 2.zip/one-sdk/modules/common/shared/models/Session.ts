import { OrganisationPayload } from "./Organisation";

export interface ICreateMachineSessionResponse {
  organisation: OrganisationPayload;
  [configurations: string]: any;
}
