import { Core } from "./Core";
import { ICloneable, Nullable } from "./general";

export type TTransactionRiskToken = {
  sessionKey: string;
  userId: string;
};

export type TTransactionAmount = {
  value: Nullable<string>;
  currencyCode: Nullable<string>;
};

export interface ITransactionDetail {
  transactionId: Nullable<string>;
  resultId: Nullable<string>;
  status: Nullable<Core["enumCheckCaseStatus"]>;
  issueType: Nullable<Core["enumIssueType"]>;
  riskLevel: Nullable<Core["enumRiskLevelType"]>;
  activityType: Nullable<Core["enumActivityType"]>;
  paymentMethod: Nullable<Core["enumPaymentType"]>;
  paymentId: Nullable<string>;
  amount: Nullable<TransactionAmount>;
  transactionTimestamp: Nullable<string>;
  deviceId: Nullable<string>;
  riskToken: Nullable<Core["RiskTokenObject"]>;
}
export interface ITransactionDetailPayload {
  transactionId: Nullable<string>;
  resultId: Nullable<string>;
  status: Nullable<Core["enumCheckCaseStatus"]>;
  riskLevel: Nullable<Core["enumRiskLevelType"]>;
  activityType: Nullable<Core["enumActivityType"]>;
  paymentMethod: Nullable<Core["enumPaymentType"]>;
  paymentId: Nullable<string>;
  issueType: Nullable<Core["enumIssueType"]>;
  amount: Nullable<TransactionAmount>;
  transactionTimestamp: Nullable<string>;
  deviceId: Nullable<string>;
  riskToken: Nullable<Core["RiskTokenObject"]>;
}

export class TransactionDetail implements ITransactionDetail, ICloneable<ITransactionDetail> {
  transactionId: Nullable<string>;
  resultId: Nullable<string>;
  status: Nullable<Core["enumCheckCaseStatus"]>;
  issueType: Nullable<Core["enumIssueType"]>;
  riskLevel: Nullable<Core["enumRiskLevelType"]>;
  riskToken: Nullable<Core["RiskTokenObject"]>;
  activityType: Nullable<Core["enumActivityType"]>;
  paymentId: Nullable<string>;
  paymentMethod: Nullable<Core["enumPaymentType"]>;
  amount: Nullable<TransactionAmount>;
  transactionTimestamp: Nullable<string>;
  deviceId: Nullable<string>;

  constructor(payload: ITransactionDetail) {
    this.transactionId = payload.transactionId ?? null;
    this.resultId = payload.resultId ?? null;
    this.activityType = payload.activityType ?? null;
    this.issueType = payload.issueType ?? null;
    this.riskLevel = payload.riskLevel ?? null;
    this.status = payload.status ?? null;
    this.paymentMethod = payload.paymentMethod ?? null;
    this.paymentId = payload.paymentId ?? null;
    this.amount = payload.amount ?? null;
    this.transactionTimestamp = payload.transactionTimestamp ?? null;
    this.deviceId = payload.deviceId ?? null;
    this.riskToken = payload.riskToken ?? null;
  }
  clone(): TransactionDetail {
    return TransactionDetail.fromJSON(this.toJSON());
  }

  toJSON(): TransactionDetail {
    const amount = this.amount ? this.amount.toJSON() : null;

    return {
      ...this,
      amount,
    };
  }

  static fromJSON(payload: ITransactionDetailPayload): TransactionDetail {
    const amount = payload.amount ? TransactionAmount.fromJSON(payload.amount) : null;

    return new TransactionDetail({
      ...payload,
      amount,
    });
  }
}

export class TransactionRiskToken {
  sessionKey: string;
  userId: string;
  constructor(token: TTransactionRiskToken) {
    this.sessionKey = token.sessionKey || "";
    this.userId = token.userId || "";
  }
  toJSON(): TTransactionRiskToken {
    return { ...this };
  }
  static fromJSON(payload: TTransactionRiskToken): TransactionRiskToken {
    return new TransactionRiskToken(payload);
  }
}

export class TransactionAmount {
  value: Nullable<string>;
  currencyCode: Nullable<string>;
  constructor(amount: TTransactionAmount) {
    this.value = amount.value;
    this.currencyCode = amount.currencyCode || null;
  }
  toJSON(): TTransactionAmount {
    return { ...this };
  }
  static fromJSON(payload: TTransactionAmount): TransactionAmount {
    return new TransactionAmount(payload);
  }
}
