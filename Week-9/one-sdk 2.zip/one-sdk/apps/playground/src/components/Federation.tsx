import { useEffect } from 'react';

import type { OneSdkContext } from '@frankieone/one-sdk';
import { wildcardEventLogger } from '@frankieone/one-sdk';

export const Federation = ({ oneSdk }: { oneSdk: OneSdkContext }) => {
  const federation = oneSdk.component('federation');
  const startFederation = () => {
    federation.start();
  };

  useEffect(() => {
    const resultsCallback = (individual, status, approve) => {
      const approved = confirm(status + '\n' + JSON.stringify(individual, null, 4));
      if (approved) approve();
    };
    federation.on('*', wildcardEventLogger);
    federation.on('results', resultsCallback);
    return () => federation.off();
  });

  return (
    <div style={{ minHeight: 844, position: 'relative', margin: '0 auto' }}>
      <div>
        <h3>Federation usage notes</h3>
        <ol>
          <li>
            When you click "Start Federation" below, the OneSDK will redirect you to the identity provider (IdP) for
            authorisation
          </li>
          <li>The IdP will then redirect you back here with an authorisation token</li>
          <li>
            For the second part of the flow, at the moment you will be required to click the button "Start Federation"
            again, which will fetch the authorised information and display it for approval
          </li>
          <li>
            After approved, the data will be successfully stored and the event 'data_extracted_successfully' will be
            emitted with the newly created entity id
          </li>
        </ol>
      </div>
      {<button onClick={startFederation}>Start Federation</button>}
    </div>
  );
};
