import { FrankieApiClient } from "@module/frankie-client";
import { IDVClient, IDVStatus } from "@module/frankie-client/clients/IDVClient";
import { AxiosResponse } from "axios";
import { mockSessionContext } from "../mocks/SessionContext";
import { jwtWithEntityId, jwtWithReference } from "../testUtils/tokens";

describe("IDVClient", () => {
  test("when session uses entity id, getToken sends POST request for session.entityId and returns object with a token string and updates the internal entityId stored in the session context", async () => {
    const frankieClient = new FrankieApiClient();
    frankieClient.session = mockSessionContext(jwtWithEntityId);
    const getTokenSpy = jest.spyOn(frankieClient, "post").mockResolvedValue(<AxiosResponse>{
      data: {
        token: "the-token",
        vendorParameters: { paramA: true },
        entityId: "random-id",
      },
    });
    const client = new IDVClient(frankieClient);
    const response = await client.getToken();
    expect(response).toEqual({
      token: "the-token",
      vendorParameters: { paramA: true },
      entityId: "random-id",
    });
    expect(getTokenSpy).toHaveBeenCalledWith(
      "data/v2/idvCheck/token",
      {
        applicant: {
          customerReference: null,
          entityId: "some-id",
        },
      },
      {
        params: {},
      }
    );
    expect(frankieClient.session.entityId).toBe("random-id");
  });
  test("when session contains appReference, getToken sends it in the root of the body", async () => {
    const frankieClient = new FrankieApiClient();
    const appReference = "app-reference";
    frankieClient.session = mockSessionContext(jwtWithEntityId, {
      appReference,
      takenFromStorage: false,
    });
    const getTokenSpy = jest.spyOn(frankieClient, "post").mockResolvedValue(<AxiosResponse>{
      data: {
        token: "the-token",
        vendorParameters: { paramA: true },
        entityId: "random-id",
      },
    });
    const client = new IDVClient(frankieClient);
    await client.getToken();
    expect(getTokenSpy).toHaveBeenCalledWith(
      "data/v2/idvCheck/token",
      {
        applicant: {
          customerReference: null,
          entityId: "some-id",
        },
        appReference,
      },
      {
        params: {},
      }
    );
    expect(frankieClient.session.entityId).toBe("random-id");
  });
  test("when session uses reference, getToken sends POST request for session.reference and returns object with a token string", async () => {
    const frankieClient = new FrankieApiClient();
    frankieClient.session = mockSessionContext(jwtWithReference);
    const postTokenSpy = jest.spyOn(frankieClient, "post").mockResolvedValue(<AxiosResponse>{
      data: {
        token: "the-token",
        vendorParameters: { paramA: true },
        entityId: "random-id",
      },
    });
    const client = new IDVClient(frankieClient);
    const response = await client.getToken();
    expect(response).toEqual({
      token: "the-token",
      vendorParameters: { paramA: true },
      entityId: "random-id",
    });
    expect(postTokenSpy).toHaveBeenCalledWith(
      "data/v2/idvCheck/token",
      {
        applicant: { customerReference: "some-reference", entityId: null },
      },
      {
        params: {},
      }
    );
  });
  test("When providing 'relayState', the same value is sent as a url query parameter", async () => {
    const frankieClient = new FrankieApiClient();
    frankieClient.session = mockSessionContext(jwtWithReference);
    const postTokenSpy = jest.spyOn(frankieClient, "post").mockResolvedValue(<AxiosResponse>{
      data: {},
    });
    const client = new IDVClient(frankieClient);
    await client.getToken({
      relayState: "testing-state",
    });

    expect(postTokenSpy).toHaveBeenCalledWith(
      "data/v2/idvCheck/token",
      {
        applicant: { customerReference: "some-reference", entityId: null },
      },
      {
        params: {
          relayState: "testing-state",
        },
      }
    );
  });
  test("initProcess requests token for session.entityId and returns object with a token string", async () => {
    const frankieClient = new FrankieApiClient();
    frankieClient.session = mockSessionContext(jwtWithEntityId);
    const initProcessSpy = jest.spyOn(frankieClient, "post").mockResolvedValue(<AxiosResponse>{
      data: { checkStatus: IDVStatus.CHECK_PROCESSING },
    });
    const client = new IDVClient(frankieClient);
    const { checkStatus } = await client.initProcess({ isSynchronous: false });
    expect(checkStatus).toBe(IDVStatus.CHECK_PROCESSING);
    expect(initProcessSpy).toHaveBeenCalledWith("data/v2/idvCheck/some-id/initProcess", { vendorParameters: {} });
  });

  test("initProcess requests token for session.entityId and returns object with a token string", async () => {
    const frankieClient = new FrankieApiClient();
    frankieClient.session = mockSessionContext(jwtWithEntityId);
    const initProcessSpy = jest.spyOn(frankieClient, "post").mockResolvedValue(<AxiosResponse>{
      data: { checkStatus: IDVStatus.COMPLETE },
    });
    const client = new IDVClient(frankieClient);
    const { checkStatus } = await client.initProcess({ isSynchronous: true });
    expect(checkStatus).toBe(IDVStatus.COMPLETE);
    expect(initProcessSpy).toHaveBeenCalledWith("data/v2/idvCheck/some-id/initProcess?is_synchronous", {
      vendorParameters: {},
    });
  });
  test("all data passed to initProcess option vendorParameters is simply passed through to the api", async () => {
    const frankieClient = new FrankieApiClient();
    frankieClient.session = mockSessionContext(jwtWithEntityId);
    const initProcessSpy = jest.spyOn(frankieClient, "post").mockResolvedValue(<AxiosResponse>{
      data: { checkStatus: IDVStatus.COMPLETE },
    });
    const client = new IDVClient(frankieClient);
    const vendorParameters: Parameters<typeof client.initProcess>[0]["vendorParameters"] = <unknown>{
      paramA: true,
      paramB: "string",
    };
    await client.initProcess({ isSynchronous: true, vendorParameters });
    expect(initProcessSpy).toHaveBeenCalledWith("data/v2/idvCheck/some-id/initProcess?is_synchronous", {
      vendorParameters,
    });
  });
});
