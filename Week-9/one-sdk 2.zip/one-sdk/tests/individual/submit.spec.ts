import type { ReactiveStore } from '@module/common';
import { Applicant } from '@module/common/shared/models/Applicant';
import { CheckSummary } from '@module/common/shared/models/CheckSummary';
import type { Document } from '@module/common/shared/models/Document';
import { ApplicantClient } from '@module/frankie-client/clients/ApplicantClient';
import { URL_PARAM } from '@module/frankie-client/DummyFrankieApiClient';
import type { InternalState } from '@module/individual';
import { mkSubmit } from '@module/individual/actions/submit';

import { EventHubMock } from '../mocks/EventHub';
import { mockFrankieClient } from '../mocks/FrankieClient';
import { mockAccessors } from '../mocks/ReactiveStore';

import type { AxiosResponse } from 'axios';

describe('Individual::submit', () => {
  test.skip('Submitting without giving consent first emits error event and then rejects request', async () => {
    const { frankieClient } = mockFrankieClient({ sessionType: 'entityId' });
    const client = new ApplicantClient(frankieClient);
    const eventHub = new EventHubMock();
    const globalEventHub = new EventHubMock();
    const applicant$ = mockAccessors({ applicant: new Applicant() });
    const isPersisted$ = mockAccessors({ isPersisted: true });
    const isLoading$ = mockAccessors({ isLoading: false });
    const consentsGiven$ = mockAccessors({ consents: [] as string[] });
    const documents$ = mockAccessors({ documents: [] as Document[] });

    const state$ = <ReactiveStore<InternalState>>{
      getRootAccessors: (key: string) =>
        ({
          applicant: applicant$,
          isPersisted: isPersisted$,
          isLoading: isLoading$,
          consentsGiven: consentsGiven$,
          documents: documents$,
        }[key]),
    };
    const submit = mkSubmit({ client, eventHub, globalEventHub, state$ });

    await expect(submit()).rejects.toMatchObject({ message: expect.stringMatching(/consent/i) });
    expect(eventHub.emit).toHaveBeenCalledWith(
      'error',
      expect.objectContaining({
        message: expect.stringMatching(/consent/i),
        payload: {
          hint: expect.stringMatching(/addConsent\(\{ type \}\)/),
        },
      }),
    );
  });

  test('Non existing applicant will only have reference, on Submit( verify: false ) it calls createApplicant, updates entity id and returns nothing', async () => {
    const { frankieClient } = mockFrankieClient({ sessionType: 'reference' });
    frankieClient.stubResponse(
      { url: 'data/v2/applicants', method: 'post' },
      {
        data: { entityId: 'created-entity-id' },
      },
    );
    const client = new ApplicantClient(frankieClient);
    const eventHub = new EventHubMock();
    const globalEventHub = new EventHubMock();
    const applicant$ = mockAccessors({
      applicant: { name: { givenName: 'testname' }, consents: [] } as Applicant,
    });
    const isPersisted$ = mockAccessors({ isPersisted: true });
    const isLoading$ = mockAccessors({ isLoading: false });
    const consentsGiven$ = mockAccessors({ consents: ['already-has-consents'] });
    const documents$ = mockAccessors({
      documents: [{ documentId: 'existing-document' } as Document],
    });
    const state$ = <ReactiveStore<InternalState>>{
      getRootAccessors: (key: string) =>
        ({
          applicant: applicant$,
          isPersisted: isPersisted$,
          isLoading: isLoading$,
          consentsGiven: consentsGiven$,
          documents: documents$,
        }[key]),
    };
    const submit = mkSubmit({ client, eventHub, globalEventHub, state$ });

    await expect(submit()).resolves.toBe(void 0);

    expect(frankieClient.post).toHaveBeenCalledWith(
      '/data/v2/applicants',
      expect.objectContaining({
        applicant: expect.any(Object),
        documents: expect.objectContaining([{ documentId: 'existing-document' }]),
      }),
    );
    expect(applicant$.setValue).toHaveBeenCalledWith(
      expect.objectContaining({
        entityId: 'created-entity-id',
        name: { givenName: 'testname', familyName: '' },
      }),
    );
  });
  test("Existing applicant with entityId, Submit( verify: false ) calls updateApplicant, doesn't update entityId and returns nothing", async () => {
    const { frankieClient } = mockFrankieClient({ sessionType: 'entityId' });
    frankieClient.stubResponse({ url: new RegExp(`data/v2/applicants/${URL_PARAM}`), method: 'put' }, { status: 200 });
    const client = new ApplicantClient(frankieClient);
    const eventHub = new EventHubMock();
    const globalEventHub = new EventHubMock();
    const applicant$ = mockAccessors({
      applicant: { entityId: 'some-id', name: { givenName: 'testname' }, consents: [] } as Applicant,
    });
    const isPersisted$ = mockAccessors({ isPersisted: true });
    const isLoading$ = mockAccessors({ isLoading: false });
    const consentsGiven$ = mockAccessors({ consents: ['already-has-consents'] });
    const documents$ = mockAccessors({
      documents: [{ documentId: 'existing-document' } as Document],
    });
    const state$ = <ReactiveStore<InternalState>>{
      getRootAccessors: (key: string) =>
        ({
          applicant: applicant$,
          isPersisted: isPersisted$,
          isLoading: isLoading$,
          consentsGiven: consentsGiven$,
          documents: documents$,
        }[key]),
    };
    const submit = mkSubmit({ client, eventHub, globalEventHub, state$ });

    await expect(submit()).resolves.toBe(void 0);

    expect(frankieClient.put).toHaveBeenCalledWith(
      `/data/v2/applicants/some-id`,
      expect.objectContaining({
        applicant: expect.any(Object),
        documents: expect.objectContaining([{ documentId: 'existing-document' }]),
      }),
    );
    expect(applicant$.setValue).not.toHaveBeenCalled();
  });
  test("Submit( verify: true ) with entityId calls updateApplicant, doesn't update entityId, calls triggerChecks and returns CheckSummary", async () => {
    const { frankieClient } = mockFrankieClient({ sessionType: 'entityId' });
    const checkSummary = CheckSummary.default();
    frankieClient.stubResponse(
      { url: new RegExp(`data/v1/applicants/${URL_PARAM}/checks`), method: 'post' },
      { status: 200 },
    );
    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/applicants/${URL_PARAM}`), method: 'get' },
      {
        status: 200,
        data: {
          checkSummary: checkSummary.toJSON(),
        },
      },
    );
    const client = new ApplicantClient(frankieClient);
    const eventHub = new EventHubMock();
    const globalEventHub = new EventHubMock();
    const applicant$ = mockAccessors({
      applicant: { entityId: 'some-id', name: { givenName: 'testname' }, consents: [] } as Applicant,
    });
    const isPersisted$ = mockAccessors({ isPersisted: true });
    const isLoading$ = mockAccessors({ isLoading: false });
    const consentsGiven$ = mockAccessors({ consents: ['already-has-consents'] });
    const documents$ = mockAccessors({
      documents: [{ documentId: 'existing-document' } as Document],
    });
    const state$ = <ReactiveStore<InternalState>>{
      getRootAccessors: (key: string) =>
        ({
          applicant: applicant$,
          isPersisted: isPersisted$,
          isLoading: isLoading$,
          consentsGiven: consentsGiven$,
          documents: documents$,
        }[key]),
    };
    const submit = mkSubmit({ client, eventHub, globalEventHub, state$ });

    await expect(submit({ verify: true })).resolves.toMatchObject(checkSummary);

    expect(frankieClient.post).toHaveBeenCalledWith(`/data/v1/applicants/some-id/checks`);
    expect(frankieClient.get).toHaveBeenCalledWith(`/data/v2/applicants/some-id`);
    expect(applicant$.setValue).not.toHaveBeenCalled();
  });
  test('Submit( verify: true ) with reference calls createApplicant, updates entityId, calls triggerChecks and returns CheckSummary', async () => {
    const { frankieClient } = mockFrankieClient({ sessionType: 'reference', clientType: 'dummy' });
    const checkSummary = CheckSummary.default();
    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/applicants`), method: 'post' },
      { status: 200, data: { entityId: 'created-entity-id' } },
    );
    frankieClient.stubResponse(
      { url: new RegExp(`data/v1/applicants/${URL_PARAM}/checks`), method: 'post' },
      { status: 200 },
    );
    frankieClient.stubResponse(
      { url: new RegExp(`data/v2/applicants/${URL_PARAM}`), method: 'get' },
      {
        status: 200,
        data: {
          checkSummary: checkSummary.toJSON(),
        },
      },
    );
    const applicantPreSubmission = new Applicant();
    applicantPreSubmission.name.givenName = 'testname';
    applicantPreSubmission.consents = [];

    const client = new ApplicantClient(frankieClient);
    const eventHub = new EventHubMock();
    const globalEventHub = new EventHubMock();
    const applicant$ = mockAccessors({
      applicant: applicantPreSubmission,
    });
    const isPersisted$ = mockAccessors({ isPersisted: true });
    const isLoading$ = mockAccessors({ isLoading: false });
    const consentsGiven$ = mockAccessors({ consents: ['already-has-consents'] });
    const documents$ = mockAccessors({
      documents: [{ documentId: 'existing-document' } as Document],
    });
    const state$ = <ReactiveStore<InternalState>>{
      getRootAccessors: (key: string) =>
        ({
          applicant: applicant$,
          isPersisted: isPersisted$,
          isLoading: isLoading$,
          consentsGiven: consentsGiven$,
          documents: documents$,
        }[key]),
    };
    const submit = mkSubmit({ client, eventHub, globalEventHub, state$ });

    await expect(submit({ verify: true })).resolves.toMatchObject(checkSummary);

    expect(frankieClient.post).toHaveBeenCalledWith(
      `/data/v2/applicants`,
      expect.objectContaining({
        applicant: applicantPreSubmission,
      }),
    );
    expect(frankieClient.post).toHaveBeenCalledWith(`/data/v1/applicants/created-entity-id/checks`);
    expect(frankieClient.get).toHaveBeenCalledWith(`/data/v2/applicants/created-entity-id`);
    expect(applicant$.setValue).toHaveBeenCalledWith(
      expect.objectContaining({
        entityId: 'created-entity-id',
      }),
    );
  });
  test.todo('When submitting, after response, set ref of all models containing a uuid to that uuid');
  test('Set isLoading before and after', async () => {
    const { frankieClient } = mockFrankieClient({ sessionType: 'reference', clientType: 'dummy' });
    frankieClient.post.mockResolvedValue({ data: { entityId: 'created-entity-id' } } as AxiosResponse);
    frankieClient.put.mockResolvedValue({ data: { entityId: 'created-entity-id' } } as AxiosResponse);

    const isPersisted$ = mockAccessors({ isPersisted: true });
    const isLoading$ = mockAccessors({ isLoading: false });
    const client = new ApplicantClient(frankieClient);
    const eventHub = new EventHubMock();
    const globalEventHub = new EventHubMock();
    const applicant$ = mockAccessors({
      applicant: new Applicant(),
    });
    const consentsGiven$ = mockAccessors({ consents: ['already-has-consents'] });
    const documents$ = mockAccessors({
      documents: [{ documentId: 'existing-document' } as Document],
    });

    const state$ = <ReactiveStore<InternalState>>{
      getRootAccessors: (key: string) =>
        ({
          applicant: applicant$,
          isPersisted: isPersisted$,
          isLoading: isLoading$,
          consentsGiven: consentsGiven$,
          documents: documents$,
        }[key]),
    };
    const submit = mkSubmit({ client, eventHub, globalEventHub, state$ });
    await submit();
    expect(isLoading$.setValue).toHaveBeenNthCalledWith(1, true);
    expect(isLoading$.setValue).toHaveBeenNthCalledWith(2, false);
  });
});
