import { ApplicantId } from "@module/session/SessionContext";

export type Events = {
  data_loaded: [ApplicantId & { isPreloaded: boolean }];
  data_updated: [string, unknown];
};
