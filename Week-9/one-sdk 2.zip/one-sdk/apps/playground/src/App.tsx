import { useEffect, useRef, useState } from 'react';

import type { CheckSummary, OneSdkConfiguration, OneSdkContext } from '@frankieone/one-sdk';
import OneSdk, { wildcardEventLogger } from '@frankieone/one-sdk';

import './App.css';

import { BiometricsIDV } from './components/Biometrics';
import { DocumentDetailsForm } from './components/DocumentDetails';
import { Federation } from './components/Federation';
import { IDVFlow } from './components/IDVFlow';
import { IndividualDetailsForm } from './components/IndividualDetails';
import { Instructions } from './components/Instructions';
import { DEVTOOLS, INCLUDE, ONE_SDK_MODE, RECIPE_CONFIGURATION, SESSION_CONFIGURATION, TELEMETRY } from './config';
import { mkFrankieSession } from './onesdk/mkFrankieSession';
import { useOneSdkState } from './onesdk/useOneSdkState';

declare global {
  interface Window {
    uploadFile: unknown;
    oneSdkInstance: OneSdkContext;
    OneSDK: unknown;
  }
}
window.OneSDK = OneSdk;

console.log(`You are using OneSDK version ${OneSdk.version}`);
/**
 * ENTRY COMPONENT FOR THE PLAYGROUND, WHERE ONE SDK IS INITIALISED
 */
const App = () => {
  const [isReady, setIsReady] = useState(false);
  const oneSdk = useRef<OneSdkContext>();

  useEffect(() => {
    (async () => {
      const sessionTokenObject = await mkFrankieSession(ONE_SDK_MODE, SESSION_CONFIGURATION);
      const sessionOptions = {
        ...sessionTokenObject,
        appReference: SESSION_CONFIGURATION.appReference,
        persist: SESSION_CONFIGURATION.persist,
      };
      // Root ONE_SDK_OPTIONS
      const ONE_SDK_OPTIONS = {
        telemetry: TELEMETRY,
        session: sessionOptions,
        mode: ONE_SDK_MODE,
        recipe: RECIPE_CONFIGURATION,
        devtools: DEVTOOLS,
      } as OneSdkConfiguration;
      // OneSDK constructor, where options are passed and OneSDK instance is returned in a Promise
      OneSdk(ONE_SDK_OPTIONS)
        .then((oneSdkInstance) => {
          window.oneSdkInstance = oneSdkInstance;
          oneSdkInstance.on('*', wildcardEventLogger);
          oneSdk.current = oneSdkInstance;

          const individual = oneSdkInstance.individual();
          individual.on('*', wildcardEventLogger);

          if (INCLUDE.device) {
            const device = oneSdkInstance.component('device', { activityType: 'LOGIN' });
            device.on('*', wildcardEventLogger);
            device.start();
          }
          setIsReady(true);
        })
        .catch(console.error);
    })();

    return () => {
      // Since OneSDK is resolved asynchronously,
      // we need to check if it actually exists yet before unpluging the event listeners
      if (oneSdk.current) {
        // oneSdk.current.off();
        oneSdk.current.off('*', wildcardEventLogger);
        // oneSdk.current.individual().off();
        oneSdk.current.individual().off('*', wildcardEventLogger);
        if (INCLUDE.device) oneSdk.current.component.instances.device.device.off();
      }
    };
  }, []);

  return isReady && <Form oneSdk={oneSdk.current} />;
};
const Form = ({ oneSdk }: { oneSdk: OneSdkContext }) => {
  const individual = oneSdk.individual();
  const [documents] = useOneSdkState(individual.access('documents'));

  const isOnlyModuleIncluded = Object.values(INCLUDE).filter(Boolean).length === 1;
  const includeInstructions = INCLUDE.individual && isOnlyModuleIncluded;
  const includeFederation = INCLUDE.federation && !SESSION_CONFIGURATION.useEntityId;
  const includeBiometrics = INCLUDE.biometrics && !INCLUDE.idv;
  const includeOcr = INCLUDE.ocr;
  const includeIndividual = INCLUDE.individual;
  const includeIdv = INCLUDE.idv && !INCLUDE.biometrics;
  useEffect(() => {
    if (INCLUDE.biometrics && INCLUDE.idv)
      console.error(
        'You cannot have both idv and biometrics turned on at the same time. Go to config.ts and set one of them to false.',
      );
  });

  return (
    <div className="App">
      <h1>OneSdk playground(ish)</h1>
      {includeInstructions && <Instructions />}
      {includeFederation && <Federation oneSdk={oneSdk} />}
      {includeIndividual && <IndividualDetailsForm oneSdk={oneSdk} />}
      {includeOcr && <DocumentDetailsForm {...{ documents, oneSdk }} />}
      {includeBiometrics && <BiometricsIDV oneSdk={oneSdk} />}
      {includeIdv && <IDVFlow oneSdk={oneSdk} />}
      <Submission oneSdk={oneSdk} />
    </div>
  );
};
function Submission(o: { oneSdk: OneSdkContext }) {
  const { oneSdk } = o;
  const individual = oneSdk.individual();
  const [consents] = useOneSdkState(individual.access('consentsGiven'));

  const [shouldVerify, setShouldVerify] = useState(false);
  const [checkResults, setCheckResults] = useState<CheckSummary | true | void>(null);

  const submitData = () => individual.submit({ verify: shouldVerify }).then(setCheckResults);
  return (
    <>
      {
        <button disabled={consents.length === 0} onClick={submitData}>
          Submit
        </button>
      }
      {
        <p>
          <input id="sv" type="checkbox" checked={shouldVerify} onChange={() => setShouldVerify(!shouldVerify)}></input>
          <label htmlFor="sv">
            Run checks?<span style={{ fontStyle: 'italic', paddingLeft: '10px' }}>{shouldVerify ? 'Yes' : 'No'}</span>
          </label>
        </p>
      }
      <div>
        {checkResults && checkResults === true && <div>Data was saved, but no verification was run.</div>}
        {checkResults && typeof checkResults === 'object' && (
          <div>
            <h2>Here are your results</h2>
            <p>
              You <b>{checkResults.status.label}</b>
            </p>
            <p>{JSON.stringify(checkResults)}</p>
          </div>
        )}
      </div>
    </>
  );
}

export default App;
