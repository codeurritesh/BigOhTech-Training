import { TApplicantStatus } from "../models/TApplicantStatus";

export const STATE_FAILED = "failed";
export const STATE_PASSED = "passed";
export const STATE_FAIL = "fail";
export const STATE_PASS = "pass";
export const STATE_MANUAL_FAILED = "fail_manual";
export const STATE_MANUAL_PASSED = "pass_manual";
export const STATE_NEEDS_ATTENTION = "refer";
export const STATE_WAITING_ON_CUSTOMER = "wait";
export const STATE_UNCHECKED = "unchecked";

export enum STATE_TYPES {
  FAILED = "failed",
  PASSED = "passed",
  MANUAL_FAILED = "fail_manual",
  MANUAL_PASSED = "pass_manual",
  NEEDS_ATTENTION = "refer",
  WAITING_ON_CUSTOMER = "wait",
  UNCHECKED = "unchecked",
  ARCHIVED = "archived",
  INACTIVE = "inactive",
}

export function stateBackend(state: string): TApplicantStatus {
  const frontend: TApplicantStatus = { type: null, label: "", key: state };

  if (state) {
    state = state.toLowerCase();
    switch (state) {
      case "pass":
      case "passed":
      case "checked_success":
      case "checked_success_clear":
        frontend.type = STATE_TYPES.PASSED;
        frontend.label = "Passed";
        break;
      case "review":
      case "refer":
      case "checked_partial_success":
      case "checked_success_with_notes":
        frontend.type = STATE_TYPES.NEEDS_ATTENTION;
        frontend.label = "Refer";
        break;
      case "no_match":
      case "fail":
      case "failed":
      case "check_stopped":
      case "checked_failed":
      case "not_supported":
      case "unprocessable":
      case "checking":
        frontend.type = STATE_TYPES.FAILED;
        frontend.label = "Failed";
        break;
      case "wait":
      case "waiting":
        frontend.type = STATE_TYPES.WAITING_ON_CUSTOMER;
        frontend.label = "Waiting";
        break;
      case "fail_manual":
      case "manual_fail":
        frontend.type = STATE_TYPES.MANUAL_FAILED;
        frontend.label = "Manually Failed";
        break;
      case "pass_manual":
      case "manual_pass":
        frontend.type = STATE_TYPES.MANUAL_PASSED;
        frontend.label = "Manually Failed";
        break;
      case "archived":
        frontend.type = STATE_TYPES.ARCHIVED;
        frontend.label = "Archived";
        break;
      case "inactive":
        frontend.type = STATE_TYPES.INACTIVE;
        frontend.label = "Inactive";
        break;
      case "unchecked":
        frontend.type = STATE_TYPES.UNCHECKED;
        frontend.label = "Unchecked";
    }
  }

  return frontend;
}

export const sortStatus = (a: TApplicantStatus, b: TApplicantStatus): number => {
  const STATUS_SORT = {
    [STATE_TYPES.PASSED]: 1,
    [STATE_TYPES.MANUAL_PASSED]: 2,
    [STATE_TYPES.NEEDS_ATTENTION]: 3,
    [STATE_TYPES.FAILED]: 4,
    [STATE_TYPES.MANUAL_FAILED]: 5,
    [STATE_TYPES.WAITING_ON_CUSTOMER]: 6,
    [STATE_TYPES.UNCHECKED]: 7,
    [STATE_TYPES.ARCHIVED]: 8,
    [STATE_TYPES.INACTIVE]: 9,
  };

  const aType = a.type;
  const bType = b.type;
  const aPoints = aType ? STATUS_SORT[aType] : 0;
  const bPoints = bType ? STATUS_SORT[bType] : 0;

  return aPoints - bPoints;
};
