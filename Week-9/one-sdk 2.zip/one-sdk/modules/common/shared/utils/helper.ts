export function checkIncludes(arr: string[], value: string | undefined | null) {
  if (!value) return false;
  let isIncludes = false;
  arr.map(item => {
    if (item === value) isIncludes = true;
  });
  return isIncludes;
}

export const mergeObject = (defaultObj: any, targetObj: any | undefined) => {
  if (!targetObj) return defaultObj;
  return { ...defaultObj, ...targetObj };
};
export const mergeArray = (
  defaultArray: any[],
  targetArray: any[] | undefined
) => {
  if (!targetArray) return defaultArray;
  return [...defaultArray, ...targetArray];
};

export const getNameLabel= (displayName) =>{

  if (!displayName) return null;
  const nameArr = displayName.split(" ") || [];
  if (nameArr.length <= 1) return nameArr[0]?.slice(0, 1)?.toUpperCase();
  else return [nameArr[0].slice(0, 1), nameArr[nameArr.length - 1].slice(0, 1)].join("").toUpperCase();
}