import basicSsl from '@vitejs/plugin-basic-ssl';
import { createHtmlPlugin } from 'vite-plugin-html';

import { getDotEnvVariables } from '../../scripts/env';
import mergeDefaultConfig from '../common/vite.config';

import * as constants from './src/constants';
import { env2url } from './src/scripts/env2url';
export default mergeDefaultConfig(
  {
    plugins: [
      basicSsl(),
      createHtmlPlugin({
        minify: true,
        template: 'src/index.html',
        viteNext: true,
        inject: {
          data: {
            constants,
            env: getDotEnvVariables(),
            env2url,
          },
        },
      }),
    ],
    https: true,
  },
  { appDir: 'self-hosted', entryFile: 'main.tsx' },
);
