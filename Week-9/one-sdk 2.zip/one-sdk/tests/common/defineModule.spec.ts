import { defineModule } from "@module/common/modules/defineModule";
import { InjectedState } from "@module/common/types";
import { eventHubAssertion } from "@tests/testUtils/expecters";

describe("defineModule function", () => {
  test("defineModule will return a function that wraps the provided function", () => {
    const initialiseFunction = jest.fn(() => ({ context: true }));
    const wrappedFunction = defineModule("moduleName", initialiseFunction);
    const returnedContext = wrappedFunction(<InjectedState>{}, {});

    expect(initialiseFunction).toHaveBeenCalled();
    expect(returnedContext).toEqual(expect.objectContaining({ context: true }));
  });
  test("defineModule will provide localEventHub as parameter and wrap context with a corresponding eventListener", () => {
    const initialiseFunction = jest.fn(() => ({ context: true }));
    const wrappedFunction = defineModule("moduleName", initialiseFunction);
    const returnedContext = wrappedFunction(<InjectedState>{}, {});

    expect(initialiseFunction).toHaveBeenCalledWith(expect.objectContaining({ localEventHub: eventHubAssertion }), {});
    expect(returnedContext).toEqual({ context: true, on: expect.any(Function), off: expect.any(Function) });
  });
});
