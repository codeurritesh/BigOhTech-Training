import { EventHub, EventsDictionary, mkEventHub } from "@module/common";

export const mockEventHubConstructor = <Events extends EventsDictionary = EventsDictionary>(): {
  new (): EventHub<Events>;
} => jest.fn().mockImplementation(mockEventHub);

export const mockEventHub = <Events extends EventsDictionary = EventsDictionary>() => {
  const actualEventHub = mkEventHub<Events>();
  jest.spyOn(actualEventHub, "emit");
  jest.spyOn(actualEventHub, "on");
  jest.spyOn(actualEventHub, "off");
  return <jest.Mocked<EventHub<Events>>>actualEventHub;
};
export const EventHubMock = mockEventHubConstructor();
