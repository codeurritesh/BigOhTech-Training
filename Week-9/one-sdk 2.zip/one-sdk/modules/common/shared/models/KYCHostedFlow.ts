import { ICloneable, Nullable } from "./general";

export interface IKYCHostedFlow {
  pushToSms: boolean;
  smsPhoneNumber: Nullable<string>;
  recipe?: Nullable<string>;
  comment: Nullable<string>;
}

export class KYCHostedFlow implements IKYCHostedFlow, ICloneable<KYCHostedFlow> {
  pushToSms = true;
  smsPhoneNumber: Nullable<string>;
  comment: Nullable<string>;
  recipe: Nullable<string>;

  constructor(payload: IKYCHostedFlow) {
    this.pushToSms = payload.pushToSms ?? true;
    this.smsPhoneNumber = payload.smsPhoneNumber ?? null;
    this.comment = payload.comment ?? null;
    this.recipe = payload.recipe ?? null;
  }

  clone(): KYCHostedFlow {
    return KYCHostedFlow.fromJSON(this.toJSON());
  }

  toJSON(): KYCHostedFlow {
    return {
      ...this,
    };
  }

  static fromJSON(payload: IKYCHostedFlow): KYCHostedFlow {
    return new KYCHostedFlow({
      ...payload,
    });
  }
}
