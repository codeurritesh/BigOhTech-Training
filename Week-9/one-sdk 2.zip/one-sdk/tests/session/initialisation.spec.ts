import { SdkMode } from '@frankieone/one-sdk';
import { ModeObject, ResolvedRootParameters } from '@module/common/types';
import SessionInitialise from '@module/session';
import { StorageKeys } from '@module/session/constants';
import { mockEventHub } from '@tests/mocks/EventHub';
import { optionalParameters } from '@tests/testUtils/functionUtilities';
import jwtEncode from 'jwt-encode';

const SessionModule = optionalParameters(SessionInitialise);
const tokenExpirationSeconds = 1668681813;
const commonEntityId = 'some-entity-id';
const providedToken = jwtEncode(
  {
    data: {
      environment: 'https://some-environment.com',
      sessionId: 'some-session-id',
      entityId: commonEntityId,
      organisation: {
        customerId: 'customer-id',
      },
    },
    exp: tokenExpirationSeconds, // epoch in seconds, which will be compared against Date.now (mocked in beforeEach)
  },
  'secret',
);
const storedToken = jwtEncode(
  {
    data: {
      environment: 'https://some-environment.com',
      sessionId: 'some-session-id',
      entityId: commonEntityId,
      organisation: {
        customerId: 'customer-id',
      },
    },
    exp: tokenExpirationSeconds, // epoch in seconds, which will be compared against Date.now (mocked in beforeEach)
  },
  'secret',
);
const mockExpiredStoredToken = () => {
  jest
    .spyOn(Date, 'now')
    .mockClear()
    .mockReturnValue(tokenExpirationSeconds * 1000 + 1000); // epoch in milliseconds
};
const mockNonExpiredStoredToken = () => {
  jest
    .spyOn(Date, 'now')
    .mockClear()
    .mockReturnValue(tokenExpirationSeconds * 1000 - 1000); // epoch in milliseconds
};
const mockStoredToken = (options?: { expired?: boolean; token?: string }) => {
  const { expired = false, token } = options ?? {};
  const theStoredToken = token ?? storedToken;
  jest.spyOn(Storage.prototype, 'getItem').mockReturnValue(JSON.stringify(theStoredToken));

  if (expired) mockExpiredStoredToken();
  else mockNonExpiredStoredToken();
};
describe('Session module initialisation', () => {
  beforeEach(() => {
    jest.spyOn(Date, 'now').mockReset();
    jest.spyOn(Storage.prototype, 'getItem').mockReset();
    jest.spyOn(Storage.prototype, 'setItem').mockReset();
    jest.spyOn(Storage.prototype, 'removeItem').mockReset();
  });
  test('Initialise session module in dev mode, without stored token: Session is initialised with provided token', () => {
    const globalEventHub = mockEventHub();
    const sessionContext = SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(sessionContext.token).toBe(providedToken);
  });
  test('Initialise session module in dev mode, with a stored token AND session persistence: Session is initialised with stored token and token is NOT removed from storage', () => {
    mockStoredToken();

    const globalEventHub = mockEventHub();
    const sessionContext = SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
          persist: true,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(sessionContext.token).toBe(storedToken);
    expect(Storage.prototype.setItem).not.toHaveBeenCalled();
    expect(Storage.prototype.removeItem).not.toHaveBeenCalled();
  });
  test('Initialise session module in dev mode, with a stored token AND NO session persistence: Session is initialised with provided token and stored token is NOT changed', () => {
    mockStoredToken();

    const globalEventHub = mockEventHub();
    const sessionContext = SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(sessionContext.token).toBe(providedToken);
    expect(Storage.prototype.removeItem).not.toHaveBeenCalled();
    expect(Storage.prototype.setItem).not.toHaveBeenCalled();
  });
  test('Initialise session module in dev mode, with an expired stored token: Session is initialised with provided token, provided token is stored', () => {
    mockStoredToken({ expired: true });

    const globalEventHub = mockEventHub();
    const sessionContext = SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
          persist: true,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(sessionContext.token).toBe(providedToken);
    expect(Storage.prototype.setItem).toHaveBeenCalledWith(StorageKeys.TOKEN, JSON.stringify(providedToken));
  });
  test('Initialise session module in dev mode, with a stored token with different entity id to provided token: Session is initialised with provided token, provided token is stored', () => {
    const storedToken = jwtEncode(
      {
        data: {
          environment: 'https://some-environment.com',
          sessionId: 'some-session-id',
          entityId: 'some-other-entity-id',
          organisation: {
            customerId: 'customer-id',
          },
        },
        exp: tokenExpirationSeconds, // epoch in seconds, which will be compared against Date.now (mocked in beforeEach)
      },
      'secret',
    );
    const globalEventHub = mockEventHub();
    mockStoredToken({ expired: true, token: storedToken });
    const sessionContext = SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
          persist: true,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(sessionContext.token).toBe(providedToken);
    expect(Storage.prototype.setItem).toHaveBeenCalledWith(StorageKeys.TOKEN, JSON.stringify(providedToken));
  });
  test('Initialise session module in dev mode, with a stored token with reference while provided uses entityId: Session is initialised with provided token, provided token is stored', () => {
    const storedToken = jwtEncode(
      {
        data: {
          environment: 'https://some-environment.com',
          sessionId: 'some-session-id',
          reference: 'some-reference',
          organisation: {
            customerId: 'customer-id',
          },
        },
        exp: tokenExpirationSeconds, // epoch in seconds, which will be compared against Date.now (mocked in beforeEach)
      },
      'secret',
    );
    const globalEventHub = mockEventHub();
    mockStoredToken({ expired: true, token: storedToken });
    const sessionContext = SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
          persist: true,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(sessionContext.token).toBe(providedToken);
    expect(Storage.prototype.setItem).toHaveBeenCalledWith(StorageKeys.TOKEN, JSON.stringify(providedToken));
  });
  test('Initialise session module in dev mode, with an invalid stored token: Session is initialised with provided token, provided token is stored', () => {
    mockStoredToken({ token: 'gibberish' });
    const globalEventHub = mockEventHub();
    const sessionContext = SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
          persist: true,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(globalEventHub.emit).toHaveBeenCalledWith(
      'warning',
      expect.objectContaining({
        message: expect.any(String),
        payload: expect.any(Error),
      }),
    );
    expect(sessionContext.token).toBe(providedToken);
    expect(Storage.prototype.setItem).toHaveBeenCalledWith(StorageKeys.TOKEN, JSON.stringify(providedToken));
  });
});

describe('persisting sessions', () => {
  beforeEach(() => {
    jest.spyOn(Storage.prototype, 'setItem').mockClear();
    jest.spyOn(Storage.prototype, 'removeItem').mockClear();
    jest.spyOn(Storage.prototype, 'getItem').mockClear();
  });
  test('persist = undefined, dont read token, dont store token, dont delete token', () => {
    jest.spyOn(Storage.prototype, 'setItem');
    jest.spyOn(Storage.prototype, 'removeItem');
    jest.spyOn(Storage.prototype, 'getItem');

    const globalEventHub = mockEventHub();
    SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
          persist: undefined,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(Storage.prototype.setItem).not.toHaveBeenCalled();
    expect(Storage.prototype.removeItem).not.toHaveBeenCalled();
    expect(Storage.prototype.getItem).not.toHaveBeenCalled();
  });
  test('persist = false, dont read token, dont store token, dont delete token', () => {
    jest.spyOn(Storage.prototype, 'setItem');
    jest.spyOn(Storage.prototype, 'removeItem');
    jest.spyOn(Storage.prototype, 'getItem');

    const globalEventHub = mockEventHub();
    SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
          persist: false,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(Storage.prototype.setItem).not.toHaveBeenCalled();
    expect(Storage.prototype.removeItem).not.toHaveBeenCalled();
    expect(Storage.prototype.getItem).not.toHaveBeenCalled();
  });
  test('persist = true and token exists, read token, dont delete token', () => {
    mockStoredToken();

    jest.spyOn(Date, 'now').mockReturnValue(tokenExpirationSeconds - 1000); // epoch in milliseconds

    jest.spyOn(Storage.prototype, 'setItem');
    jest.spyOn(Storage.prototype, 'removeItem');
    jest.spyOn(Storage.prototype, 'getItem').mockReturnValue(JSON.stringify(storedToken));

    const globalEventHub = mockEventHub();
    SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
          persist: true,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(Storage.prototype.getItem).toHaveBeenCalled();
    expect(Storage.prototype.removeItem).not.toHaveBeenCalled();
    expect(Storage.prototype.setItem).not.toHaveBeenCalled();
  });
  test('persist = true and token doesnt exist, read token, store token', () => {
    jest.spyOn(Storage.prototype, 'setItem');
    jest.spyOn(Storage.prototype, 'removeItem');
    jest.spyOn(Storage.prototype, 'getItem').mockReturnValue(undefined);

    const globalEventHub = mockEventHub();
    SessionModule(
      <ResolvedRootParameters>{
        mode: new ModeObject(SdkMode.DEV),
        session: {
          token: providedToken,
          persist: true,
        },
      },
      {
        globalEventHub,
      },
    );
    expect(Storage.prototype.getItem).toHaveBeenCalled();
    expect(Storage.prototype.removeItem).not.toHaveBeenCalled();
    expect(Storage.prototype.setItem).toHaveBeenCalled();
  });
});
