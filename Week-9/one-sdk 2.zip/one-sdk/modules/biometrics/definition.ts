import type { EventHub } from '@module/common';
import type { ModuleDefinition } from '@module/common/types';

import type { Events } from './events';
import type { PartialDeep } from 'type-fest';

export type BiometricsModule = ModuleDefinition<{
  module: {
    category: 'component';
    name: 'biometrics';
    events: Events;
    context: {
      mount(domElementOrSelector: string | HTMLElement): void;
    };
    options: PartialDeep<BiometricsRecipeOptions>;
    recipe: {
      biometrics: BiometricsRecipeOptions;
    };
  };
  wrapper: {
    vendors: ['dummy-biometrics', 'ocrlabs', 'onfido', 'incode'];
    loadType: 'sync';
    options: {
      // TODO: Stop using options.eventHub in favour of the injected localEventHub. See "defineModule" definition
      eventHub: EventHub<Events>;
      mountElement: HTMLElement;
    };
  };
}>;

type BiometricsRecipeOptions = {
  provider:
    | {
    name: 'ocrlabs';
    tx_id: string;
  }
    | {
    name: 'onfido';
    fallback?: 'standard' | 'video';
    sdkVersion?: string;
  }
    | {
    name: 'incode';
    sdkVersion?: string;
  };
  is_synchronous?: boolean;
}
