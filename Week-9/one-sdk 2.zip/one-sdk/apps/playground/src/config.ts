/**
 * Import what you can from @frankieone/one-sdk directly and if anything else is also needed, consider exporting it from modules/index so it's available to all customers.
 * Not all types and helpers are necessarily needed by customers, but if it's used here or anywhere in the playground files, that indicates it might be required by customers.
 *
 * Use this space to play with different one sdk options. Don't remove commented area, as they are used for quickly switching options on and off.
 **/
import {
  Environments,
  SdkMode,
  type OneSdkConfiguration,
} from '@frankieone/one-sdk';
import type { Modules } from '@frankieone/one-sdk';
import type { RecipeConfiguration } from '@module/common';

import type { FrankieSessionOptions } from './onesdk/mkFrankieSession';

// type RecipeConfiguration used here for testing different recipes, which we don't expect customers to do.

/**
 * Included components
 * Any components provided as a comma separated list in the env variable PUBLIC_INCLUDE will take precedence over the default values
 */
type InstantiableCategory = Modules['categories'][
  | 'component'
  | 'flow'
  | 'private'];
const featuresFromEnv = process.env.PUBLIC_INCLUDE?.split(',') ?? [];
export const INCLUDE: Record<InstantiableCategory, boolean> = Object.assign(
  {
    biometrics: false,
    device: false,
    federation: false,
    ocr: false,
    idv: false,
    individual: false,
    form: false,
    workflow: false,
  },
  featuresFromEnv.reduce((acc, feature) => ({ ...acc, [feature]: true }), {})
);

// ! WARNING: When listening for global wildcard events, you'll still see telemetry events, but they won't trigger any requests
export const TELEMETRY = true;
export const DEVTOOLS = true;
/**
 * ONE SDK MODE
 * ONE_SDK_MODE = SdkMode.DEV, SdkMode.PROD, SdkMode.DUMMY or configuration object for Dummy mode, as defined below
 */
export const ONE_SDK_MODE: OneSdkConfiguration['mode'] & object = {
  modeName: SdkMode.DEV,
  // modeName: SdkMode.DUMMY,
  // mocks: {
  //   preloadedIndividual: {
  //     individual: {},
  //     documents: [],
  //   },
  //   // ocrFlow: {
  //   //   detectedType: "DRIVERS_LICENCE",
  //   //   statusResults: [OCRStatus.DOCUMENTS_INVALID, OCRStatus.COMPLETE],
  //   // },
  //   idvFlow: { result: IDVStatus.INTERRUPTED, failGeneratingSession: false },
  // }
};
export const SESSION_CONFIGURATION: FrankieSessionOptions & {
  persist: boolean;
} = {
  environment: Environments[process.env.PUBLIC_ENVIRONMENT],
  // ! WARNING: When persisting a session, make sure to initialise the SDK with the same entityId / reference
  // Persisted sessions have multiple gotchas. Among them
  // - OneSDK ENV PUBLIC_LOCAL_BFF_HOST must match BFF's ENV BFF_HOSTNAME, otherwise a session with the wrong environment url is created and persisted
  // - Initialising OneSDK for an entity different to the one persisted will override the persisted session,
  // ! --> so using a random reference in practice won't persist a session
  persist: false,
  appReference: 'VMA App',
  useEntityId: process.env.PUBLIC_ENTITY_ID,
  useReference: process.env.PUBLIC_CUSTOMER_REFERENCE,
  useRandomReference: !process.env.PUBLIC_ENTITY_ID,
};
export const RECIPE_CONFIGURATION: RecipeConfiguration = {
  // biometrics: {
  //   provider: {
  //     name: "onfido",
  //   },
  //   is_synchronous: true,
  // },
  //   deviceCharacteristics: {
  //     provider: {
  //       name: "sardine",
  //       environment: "sandbox",
  //     },
  //   },
  //   federation: "singpass",
  //   idps: {
  //     singpass: {
  //       client_id: "STG2-MYINFO-DEMO-APP",
  //       environment: "test",
  //       redirect_url: "http://localhost:3001/callback",
  //       purpose: "demonstrating MyInfo APIs",
  //       attributes:
  //         "uinfin,name,sex,race,nationality,dob,email,mobileno,regadd,housingtype,hdbtype,marital,edulevel,noa-basic,ownerprivate,cpfcontributions,cpfbalances",
  //     },
  //   },
  // },
  ocr: {
    provideReviewScreen: true,
    maxDocumentCount: 1,
    provider: {
      name: 'onfido',
    },
  },
  biometrics: {
    provider: {
      name: 'onfido',
    },
  },
  idv: {
    provideReviewScreen: true,
    provider: {
      name: 'onfido',
    },
  },
  form: {
    provider: {
      // name: 'formio',
      // formUrl: 'https://oaaipxptpitcrxk.form.io/mainreviewform',
      name: 'react',
      config: {
        name: 'WELCOME',
      },
    },
  },
  workflow: {
    steps: [
      { stepId: 'module:device', activityType: 'LOGIN' },
      { stepId: 'module:ocr' },
      { stepId: 'module:biometrics' },
    ],
  },
};
