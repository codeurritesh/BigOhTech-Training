import type { EventHub } from "@module/common";
import type { ModuleDefinition } from "@module/common/types";
import type { ActivityType } from "./constants";
import type { Events } from "./events";

export type DeviceModule = ModuleDefinition<{
  module: {
    category: "component";
    name: "device";
    context: {
      start: () => void;
    };
    options: {
      activityType: ActivityType;
    };
    events: Events;
  };
  wrapper: {
    vendors: ["sardine", "threatmetrix"];
    options: {
      eventHub: EventHub<Events>;
      activityType: ActivityType;
    };
    context: {
      set<Key extends keyof SetOptions>(key: Key, value: SetOptions[Key]): void;
    };
    loadType: "async";
  };
}>;

type SetOptions = {
  activityType: ActivityType;
  entityId: string;
};
