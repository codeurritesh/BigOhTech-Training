import { distinctUntilChanged } from "rxjs/operators";

export function onlyWhenChanged<T>(changeDetector?: (a: T, b: T) => boolean) {
  return changeDetector ? distinctUntilChanged(changeDetector) : distinctUntilChanged<T>();
}
