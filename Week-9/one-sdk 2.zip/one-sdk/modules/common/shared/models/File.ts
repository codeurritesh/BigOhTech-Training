import { stringToBase64 } from "../utils";

export interface IFilePayload {
  name: string;
  mimeType: string;
  size: number;
  base64Contents: string | null;
}

export interface IFileConstructor {
  name: string;
  mimeType: string;
  size: number;
  data?: string; // has to carry either da or base64Content
  base64Contents?: string | null;
}

export class File implements IFilePayload {
  name: string;
  mimeType: string;
  size: number;
  base64Contents: string | null;

  constructor(file: IFileConstructor) {
    this.name = file.name;
    this.mimeType = file.mimeType;
    this.size = file.size;
    this.base64Contents =
      file.base64Contents ||
      ((d) => {
        if (!d) return null;
        return stringToBase64(d);
      })(file.data!) ||
      null;
  }

  toJSON(): IFilePayload {
    return { ...this };
  }

  static fromJSON(payload: IFilePayload): File {
    return new File({
      ...payload,
    });
  }
}
