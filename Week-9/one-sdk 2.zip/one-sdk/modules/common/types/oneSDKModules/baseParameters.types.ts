import type { EventHub } from '@module/common';
import type { FrankieApiClient } from '@module/frankie-client';
import type {
  SimplifiedMockOptions,
} from '@module/frankie-client/mocks/options/simplified/SimplifiedMockOptions.type';
import type {
  GlobalEvents,
  OneSdkContext,
  RecipeParsed,
  SdkModes,
} from '@module/sdk/types';
import type { SessionContext } from '@module/session/SessionContext';
import type { Modules } from '@module/types';

import type { ModuleCategory } from './categories';

/**
 * ModuleBaseParameters
 * The base parameters object provided to all modules. Depending on the type of the module, ModuleBaseParameters is defined as:
 * - For component modules, it is GlobalState + oneSdkInstance + moduleMeta (which should be injected by the component loader)
 * - For flow modules, it is GlobalState + oneSdkInstance + moduleMeta (which should be injected by the component loader)
 * - For private modules, it is GlobalState + oneSdkInstance
 * - For pre initialisation modules, where no dependencies were built yet, it is simply the ResolvedRootParameters
 */
export type BaseParameters<Type extends ModuleCategory> = Type extends 'component'
  ? InjectedState
  : Type extends 'flow'
    ? InjectedState
    : Type extends 'private'
      ? Omit<InjectedState, 'moduleMeta'>
      : Type extends 'setup'
        ? ResolvedRootParameters
        : never;

export type InjectedState = GlobalState & {
  oneSdkInstance: OneSdkContext;
  moduleMeta: ModuleMeta;
};
type ModuleMeta = {
  moduleName: Modules['moduleName'];
  instanceName: string;
};
/**
 * The Global State object which is provided to all modules.
 * Besides the resolved root parameters, it contains "the shared dependencies", see below.
 * OBS: The raw provided session object is replaced with a complete session context object
 */
export type GlobalState =
  SharedDependencies
  & Omit<ResolvedRootParameters, 'session'>;
/**
 * The shared dependencies are part of the GlobalState, which is provided to all modules. It contains:
 * - globalEventHub: The global event hub, which is used for one way communication between modules and with the host application
 * - frankieClient: The frankie client, which is used to communicate with the backend
 * - session: The session context, which is used to store the session token and other session related information
 */
export type SharedDependencies = {
  globalEventHub: EventHub<GlobalEvents>;
  frankieClient: FrankieApiClient;
  session: SessionContext;
};
/**
 * The resolved root parameters are the parameters provided to the OneSDK by the host application. The host is allowed to provide bare minimum parameters,
 * which will be resolved to a full set of parameters by the OneSDK during its initialisation.
 */
export type ResolvedRootParameters = {
  recipe: RecipeParsed;
  telemetry: boolean;
  /** session object may or may not contain token. When token is not provided, persist will always be "false" */
  session: { appReference: string | null } & ({
    token: string;
    persist: boolean;
  } | { token: null; persist: false });
  mode: ModeObject;
};
export type DummyModeObject = ModeObject & { modeName: SdkModes.DUMMY };

export class ModeObject<Mode extends SdkModes = SdkModes> {
  public readonly modeName: Mode;
  public readonly mocks?: SimplifiedMockOptions;

  constructor(modeName: Mode, mocks?: SimplifiedMockOptions) {
    this.modeName = modeName;
    this.mocks = mocks ?? {};
  }

  is<T extends Mode | SdkModes>(mode: T): this is ModeObject<T> {
    return this.modeName === mode;
  }
}
