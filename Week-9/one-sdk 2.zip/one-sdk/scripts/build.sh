version=$(npm run curr-version --silent)
release=$(scripts/branch-to-release-name.sh $BITBUCKET_BRANCH);
scripts/tag-package-version.sh "$release"

npm run fresh
npm run build

echo "$BITBUCKET_COMMIT" >> "dist/commit.txt"
echo "$release" >> "dist/release.txt"
echo "$version" >> "dist/version.txt"