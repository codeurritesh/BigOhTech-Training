import { mkEventHub } from '@module/common';
import type { InjectedState } from '@module/common/types';
import DeviceInitialise from '@module/device';
import type { RecipeParsed } from '@module/sdk/types';
import { SdkMode } from '@module/types';
import { mockFunction } from '@tests/testUtils/functionUtilities';

const DeviceModule = mockFunction(DeviceInitialise);

describe('device:: parse configuration', () => {
  test('initialising device module in dummy mode emits error event', () => {
    const globalEventHub = mkEventHub();
    const errorListener = jest.fn();
    globalEventHub.on('error', errorListener);
    try {
      DeviceModule(
        <InjectedState>{
          mode: { modeName: SdkMode.DUMMY },
          globalEventHub,
        },
        {
          activityType: 'LOGIN',
        },
      );
    } catch (error) {
      errorListener(error);
    }

    expect(errorListener).toHaveBeenCalledWith(
      expect.objectContaining({
        message: `There is no implementation for the device component in 'dummy' mode.`,
      }),
    );
  });
  test('initialising device module without provider name emits error event', () => {
    const globalEventHub = mkEventHub();
    const errorListener = jest.fn();
    globalEventHub.on('error', errorListener);
    try {
      DeviceModule(
        <InjectedState>{
          mode: { modeName: SdkMode.DEV },
          globalEventHub,
          recipe: <RecipeParsed>{
            deviceCharacteristics: {},
          },
        },
        {
          activityType: 'LOGIN',
        },
      );
    } catch (error) {
      errorListener(error);
    }

    expect(errorListener).toHaveBeenCalledWith(
      expect.objectContaining({
        message:
          "Your account doesn't have any device characteristics providers configured. Please contact FrankieOne support.",
      }),
    );
  });
  test('initialising device module without providor environment emits error event', () => {
    const globalEventHub = mkEventHub();
    const errorListener = jest.fn();
    globalEventHub.on('error', errorListener);

    try {
      DeviceModule(
        <InjectedState>{
          mode: { modeName: SdkMode.DEV },
          globalEventHub,
          recipe: {
            deviceCharacteristics: {
              provider: {
                name: 'sardine',
              },
            },
          },
        },
        {
          activityType: 'LOGIN',
        },
      );
    } catch (error) {
      errorListener(error);
    }

    expect(errorListener).toHaveBeenCalledWith(
      expect.objectContaining({
        message:
          'Your account is missing the environment configuration for the device characteristics provider "sardine". Please contact FrankieOne support.',
      }),
    );
  });
});
