const runAll = require("npm-run-all");
const inquirer = require("inquirer");
const fs = require("fs");

inquirer
  .prompt([
    {
      type: "list",
      name: "stack",
      message: "Choose a frontend environment for @frankieone/one-sdk package to run on:",
      choices: ["React", "CDN"],
    },
  ])
  .then((answers) => {
    /**
     * @type {Stack}
     */
    const stack = answers.stack.toLocaleLowerCase().replace(" ", "-");

    runAll("dev:one-sdk", {
      stdin: process.stdin,
      stdout: process.stdout,
      stderr: process.stderr,
      printLabel: true,
      printName: true,
    })
      .then(() => {
        console.log(`npm scripts dev:one-sdk success.`);
      })
      .catch((error) => {
        console.log(`npm scripts dev:one-sdk failed.`);
        console.log(error);
      });

    scriptsRunner(stack);
  });

function scriptsRunner(stack) {
  fs.readdir("./packages/sdk/dist", (error, files) => {
    if (error || !files.length) {
      console.log("No bundle found. Waiting for @frankieone/one-sdk");
      setTimeout(() => {
        scriptsRunner(stack);
      }, 2000);
    } else {
      runAll(`dev:use-${stack}`, {
        // stdin: process.stdin,
        stdout: process.stdout,
        // stderr: process.stderr,
        printLabel: true,
        printName: true,
        silent: true,
      })
        .then(() => {
          console.log(`npm scripts dev:use-${stack} success.`);
        })
        .catch(() => {
          console.log(`npm scripts dev:use-${stack} failed.`);
          setTimeout(() => {
            scriptsRunner(stack);
          }, 2000);
        });
    }
  });
}
