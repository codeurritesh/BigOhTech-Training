import { useState } from 'react';

interface Props {
  onSubmit(v: { username: string; password: string }): void;
}
export default function LoginFlow({ onSubmit }: Props) {
  const [username, _setUsername] = useState('');
  const [password, _setPassword] = useState('');
  const setUsername = (ev: { target: { value: string } }) => _setUsername(ev.target.value);
  const setPassword = (ev: { target: { value: string } }) => _setPassword(ev.target.value);
  return (
    <div>
      <input onChange={setUsername} placeholder="Username"></input>
      <input onChange={setPassword} placeholder="Username"></input>
      <button onClick={() => onSubmit({ username, password })}>Enter</button>
    </div>
  );
}
