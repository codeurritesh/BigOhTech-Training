import { useEffect, useRef, useState } from 'react';

import type { OneSdkContext } from '@frankieone/one-sdk';
import { wildcardEventLogger } from '@frankieone/one-sdk';

import { useOneSdkState } from '../onesdk/useOneSdkState';

import { FullScreenContainer } from './LoadingContainer';

export function DocumentDetailsForm(o: { oneSdk: OneSdkContext; documents }) {
  const { oneSdk, documents } = o;
  const { info, status, submitFile, setSubmitFile, ocrComponent } = useOCRComponent(oneSdk);

  const ocrStatuses = ocrComponent.statuses;
  const [isPreloaded] = useOneSdkState(ocrComponent.access('isPreloaded'));
  const [mounted, _setMounted] = useState(false);
  const [loading, setLoading] = useState(false);

  const isFailedStatus = (status) => {
    return [
      ocrStatuses.DOCUMENTS_INVALID,
      ocrStatuses.DOCUMENTS_UPLOAD_FAILED,
      ocrStatuses.FAILED_FILE_SIZE,
      ocrStatuses.FAILED_FILE_FORMAT,
      ocrStatuses.PROVIDER_OFFLINE,
    ].includes(status);
  };
  const uploadFile = (ev) => {
    if (submitFile) submitFile(ev.target.files[0]);
    else console.error('submitFile was called at the wrong moment');

    setSubmitFile(null);
    ev.target.value = null;
  };

  const startOCR = ocrComponent.start;
  const mountOCR = () => {
    ocrComponent.mount('#ocr-el');
  };
  const setMounted = () => {
    _setMounted(true);
  };
  const setUnmounted = () => {
    _setMounted(false);
  };

  useEffect(() => {
    ocrComponent.on('ready', setMounted);
    ocrComponent.on('results', setUnmounted);
    ocrComponent.on('loading', setLoading);
    return () => {
      ocrComponent.off('loading', setLoading);
      ocrComponent.off('results', setUnmounted);
      ocrComponent.off('ready', setMounted);
    };
  }, []);

  return (
    <div>
      {!status && <h2>OCR your id document</h2>}
      {isPreloaded && <h3>...continuing existing OCR</h3>}
      {status === ocrStatuses.COMPLETE && <h2>Thank you!</h2>}
      {status === ocrStatuses.WAITING_FRONT && <h2>Upload the front of your Licence first</h2>}
      {status === ocrStatuses.WAITING_BACK && <h2>Now the back of your licence</h2>}
      {isFailedStatus(status) && <h2>Oh no! Something went wrong. Maybe try uploading the {info.side} scan again</h2>}
      {status && (
        <div>
          <p>
            Once the button was clicked, it triggered the OCR flow, emitting the event &quot;update_input&quot; once per
            required file. The event itself exposes three variables, described below
          </p>
          <ol>
            {info && <li>Info object: {JSON.stringify(info)}</li>}
            <li style={{ fontWeight: status === ocrStatuses.DOCUMENTS_UPLOAD_FAILED ? 'bold' : 'normal' }}>
              Current status for this OCR flow: <span style={{ fontWeight: 'bold' }}>{status}</span>
              {status === ocrStatuses.DOCUMENTS_UPLOAD_FAILED && (
                <p>
                  Whenever there is a failure on file submission, the previous event input_required is just repeated,
                  but with a status representing the error
                </p>
              )}
            </li>
            <li>A callback function &quot;provideFile&quot; that will be triggered once you pick a file below</li>
          </ol>
        </div>
      )}
      <p>
        When OCR is completed successfully the document will be included in the list of documents of the individual
        below.
        <br />
        <span style={{ color: 'red' }}>TODO:</span> Interrupted/preloaded OCR flow
      </p>
      <button onClick={startOCR}>Start OCR</button>
      {info?.side && (
        <div>
          <input type="file" accept="image/*" onChange={uploadFile} />
        </div>
      )}
      <FullScreenContainer id="ocr-el" mounted={mounted} loading={loading} />
      <button onClick={mountOCR}>Mount OCR</button>
      {documents.length > 0 && (
        <div>
          <p>Existing documents ({documents.length})</p>
          {documents.map((d, i) => (
            <div key={i}>
              <h3>{i + 1}</h3>
              <DocumentBlock document={d} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
function useOCRComponent(oneSdk: OneSdkContext) {
  const ocrComponent = oneSdk.component('ocr');
  const ocrStatuses = ocrComponent.statuses;

  const [status, setStatus] = useState<string>(null);
  const [info, setInfo] = useState<{ side: string }>(null);

  const submitFile = useRef<(f: File) => void>(() => void 0);
  const setSubmitFile = (f) => (submitFile.current = f);

  const onInputRequired = (info, status, submitFile) => {
    setInfo(info);
    setStatus(status);
    setSubmitFile(submitFile);
  };
  const onError = (e) => {
    alert(e.message + '\n' + JSON.stringify(e.payload));
  };
  const onResults = ({ document }) => {
    setStatus(ocrStatuses.COMPLETE);
    console.log("'results' event:", document);
  };

  useEffect(() => {
    ocrComponent.on('input_required', onInputRequired);
    ocrComponent.on('error', onError);
    ocrComponent.on('results', onResults);
    ocrComponent.on('error', () => setStatus(null));
    ocrComponent.on('*', wildcardEventLogger);
    return () => {
      ocrComponent.off('input_required', onInputRequired);
      ocrComponent.off('error', onError);
      ocrComponent.off('results', onResults);
      ocrComponent.off('error', () => setStatus(null));
      ocrComponent.off('*', wildcardEventLogger);
    };
  }, []);

  return { status, info, submitFile: submitFile.current, setSubmitFile, ocrComponent };
}
function DocumentBlock({ document }: { document: object }) {
  const html = JSON.stringify(document)
    .trim()
    .replace(/,/, '<br>')
    .replace(/"/, '')
    .replace(/:/, ': ')
    .replace(/^\{/, '')
    .replace(/\}$/, '')
    .replace(/\{/g, "{<br><div class='indent'>")
    .replace(/\}/g, '</div><br>}');

  return (
    <div
      style={{ textAlign: 'left', maxWidth: '500px', margin: '0 auto' }}
      dangerouslySetInnerHTML={{ __html: html }}></div>
  );
}
