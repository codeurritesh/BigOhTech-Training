#!/bin/bash
# takes build dist directory as argument $1
branch=$BITBUCKET_BRANCH
release=$(scripts/branch-to-release-name.sh)

if [ $branch == "main" ]; then playgroundTargetBucket=""; # TODO
else playgroundTargetBucket="frankie-playground-dev/$release"; fi;

playgroundBuildDirectory=$1

echo "$BITBUCKET_COMMIT" >> "$playgroundBuildDirectory/commit.txt"
echo "$release" >> "$playgroundBuildDirectory/release.txt"

echo $playgroundTargetBucket;