/* eslint-disable @typescript-eslint/no-empty-interface */
interface EnvironmentVariables {
  readonly PUBLIC_CUSTOMER_ID: string;
  readonly PUBLIC_CUSTOMER_CHILD_ID: string;
  readonly PUBLIC_CUSTOMER_API_KEY: string;
  readonly PUBLIC_LOCAL_BFF_HOST: string;
  readonly PUBLIC_ENTITY_ID: string;
  readonly PUBLIC_CUSTOMER_REFERENCE: string;
  readonly PUBLIC_INCLUDE: string;
  // more env variables...
}
declare interface ImportMeta {
  readonly env: EnvironmentVariables;
}
declare global {
  namespace NodeJS {
    interface ProcessEnv extends EnvironmentVariables {}
  }
}
export {};
