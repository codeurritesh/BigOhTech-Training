import type { ModuleDefinition } from '@module/common/types';

export type WorkflowModule = ModuleDefinition<{
  module: {
    name: 'workflow';
    category: 'flow';
    context: {
      mount: (mountElement: HTMLElement) => void;
    };
    recipe: {
      workflow:
        | {
        steps: Step[];
      }
        | {
        workflowId: string;
      };
    };
    events: {
      completed: [unknown[]];
      failure: [unknown[]];
    };
  };
}>;

export type Step =
  | {
  stepId: 'module:idv';
}
  | {
  stepId: 'module:ocr';
}
  | {
  stepId: 'module:biometrics';
}
  | {
  stepId: 'module:federation';
}
  | {
  stepId: 'module:device';
  activityType:
    | 'REGISTRATION'
    | 'LOGIN'
    | 'CRYPTO_DEPOSIT'
    | 'CRYPTO_WITHDRAWAL'
    | 'FIAT_DEPOSIT'
    | 'FIAT_WITHDRAWAL';
}
  | {
  stepId: 'module:form';
}
  | {
  stepId: 'action:redirect';
  redirectUrl: string;
};
