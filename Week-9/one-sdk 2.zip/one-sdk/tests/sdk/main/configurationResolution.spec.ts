import type { RecipeConfiguration } from "@module/common";
import { mkFrankieClient } from "@module/frankie-client";
import { parseConfiguration, resolveParameters } from "@module/sdk/initialisation/configurationParser";
import { mkSharedDependencies } from "@module/sdk/initialisation/sharedDependencies";
import { SdkModes } from "@module/sdk/types";
import { jwtWithReference } from "@tests/testUtils/tokens";

import { mockFrankieClient } from "../../mocks/FrankieClient";
import { delayTest } from "../../testUtils/asyncUtils";

import type { AxiosResponse } from "axios";

jest.mock("@module/frankie-client", () => {
  return {
    mkFrankieClient: jest.fn(),
  };
});
// Skipping just while backend API is fixed
describe("Configuration merging", () => {
  const { mockConfigurationPayload } = mockFrankieClientRequests();
  test("Passed configuration is merged with API configuration", async () => {
    mockConfigurationPayload({
      auto: {
        deviceCharacteristics: {
          provider: {
            name: "threatmetrix",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
        biometrics: {
          provider: {
            name: "ocrlabs",
            tx_id: "some-client-id",
          },
        },
        ocr: {
          provider: {
            name: "ocrlabs",
            tx_id: "some-client-id",
          },
        },
      },
    });
    const passedConfiguration: RecipeConfiguration = {
      deviceCharacteristics: {
        provider: {
          name: "sardine",
          clientID: "some-client-id",
          environment: "sandbox",
        },
      },
    };
    const passedOptions = resolveParameters({
      recipe: passedConfiguration,
      mode: SdkModes.DUMMY,
    });
    // If test fails it might be because shared.session used to be injected with mockSessionContext
    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting } = await parseConfiguration(passedOptions, shared);
    expect(passedOptions).toEqual({
      localEventHub: expect.objectContaining({
        emit: expect.any(Function),
        on: expect.any(Function),
        off: expect.any(Function),
      }),
      mode: expect.objectContaining({
        is: expect.any(Function),
        modeName: "dummy",
      }),
      recipe: expect.objectContaining({
        deviceCharacteristics: expect.objectContaining({
          provider: expect.objectContaining({
            name: "sardine",
            clientID: "some-client-id",
            environment: "sandbox",
          }),
        }),
        name: "auto",
      }),
      session: expect.objectContaining({
        appReference: null,
        persist: false,
        token: null,
      }),
      telemetry: true,
    });
    expect(resulting).toMatchObject({
      recipe: {
        deviceCharacteristics: {
          provider: {
            name: "sardine",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
        biometrics: {
          provider: {
            name: "ocrlabs",
            tx_id: "some-client-id",
          },
        },
        ocr: {
          provider: {
            name: "ocrlabs",
            tx_id: "some-client-id",
          },
        },
      },
    });
  });
  test("Passed configuration with recipe name: passed name will be seen in resulting recipe object", async () => {
    mockConfigurationPayload({
      auto: {
        name: "some-name",
        deviceCharacteristics: {
          provider: {
            name: "threatmetrix",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
      },
    });
    const passedConfiguration: RecipeConfiguration = {
      name: "some-name",
      deviceCharacteristics: {
        provider: {
          name: "sardine",
          clientID: "some-client-id",
          environment: "sandbox",
        },
      },
    };
    const passedOptions = resolveParameters({
      recipe: passedConfiguration,
      mode: SdkModes.DUMMY,
      session: {
        token: jwtWithReference,
        appReference: "some-appReference",
        persist: true,
      },
    });

    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting } = await parseConfiguration(passedOptions, shared);
    expect(passedOptions).toEqual({
      localEventHub: expect.objectContaining({
        emit: expect.any(Function),
        on: expect.any(Function),
        off: expect.any(Function),
      }),
      mode: expect.objectContaining({
        is: expect.any(Function),
        modeName: "dummy",
      }),
      recipe: expect.objectContaining({
        deviceCharacteristics: expect.objectContaining({
          provider: expect.objectContaining({
            name: "sardine",
            clientID: "some-client-id",
            environment: "sandbox",
          }),
        }),
        name: "some-name",
      }),
      session: expect.objectContaining({
        appReference: "some-appReference",
        persist: true,
        token: jwtWithReference,
      }),
      telemetry: true,
    });
    expect(resulting).toMatchObject({
      recipe: {
        name: "some-name",
        deviceCharacteristics: {
          provider: {
            name: "sardine",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
      },
    });
  });
  test('Passed configuration with recipe name: if not "auto" and is different to api recipe name, emit a "error" event and keep passed name', async () => {
    mockConfigurationPayload({
      "passed-name": {
        name: "different-api-name",
        deviceCharacteristics: {
          provider: {
            name: "threatmetrix",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
      },
    });
    const passedConfiguration: RecipeConfiguration = {
      name: "passed-name",
      deviceCharacteristics: {
        provider: {
          name: "sardine",
          clientID: "some-client-id",
          environment: "sandbox",
        },
      },
    };
    const passedOptions = resolveParameters({
      recipe: passedConfiguration,
      mode: SdkModes.DUMMY,
    });
    const expectedPartialObject = {
      recipe: {
        name: "passed-name",
        deviceCharacteristics: {
          provider: {
            name: "sardine",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
      },
    };
    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting, warnings } = await parseConfiguration(passedOptions, shared);
    return delayTest(() => {
      expect(warnings).toContainEqual(
        expect.objectContaining({
          level: "error",
          data: expect.objectContaining({
            message: expect.stringMatching(
              "Recipe name mismatch. Requested 'passed-name', found 'different-api-name'.",
            ),
            payload: expect.objectContaining(expectedPartialObject.recipe),
          }),
        }),
      );
      expect(resulting).toMatchObject(expectedPartialObject);
    });
  });
  test("Passed configuration with recipe name 'auto': passed name will be whatever API sends back", async () => {
    mockConfigurationPayload({
      auto: {
        name: "api-recipe-name",
        deviceCharacteristics: {
          provider: {
            name: "threatmetrix",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
      },
    });
    const passedConfiguration: RecipeConfiguration = {
      name: "auto",
      deviceCharacteristics: {
        provider: {
          name: "sardine",
          clientID: "some-client-id",
          environment: "sandbox",
        },
      },
    };
    const passedOptions = resolveParameters({
      recipe: passedConfiguration,
      mode: SdkModes.DUMMY,
    });

    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting, warnings } = await parseConfiguration(passedOptions, shared);
    expect(warnings).not.toContain(
      expect.objectContaining({ level: "error", message: expect.stringContaining("Recipe name mismatch") }),
    );
    expect(resulting).toMatchObject({
      recipe: {
        name: "api-recipe-name",
        deviceCharacteristics: {
          provider: {
            name: "sardine",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
      },
    });
  });
  test("Passed configuration with recipe name 'auto': if API passes no name back, for any reason, name will be 'auto'", async () => {
    mockConfigurationPayload({
      auto: {
        deviceCharacteristics: {
          provider: {
            name: "threatmetrix",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
      },
    });
    const passedConfiguration: RecipeConfiguration = {
      name: "auto",
      deviceCharacteristics: {
        provider: {
          name: "sardine",
          clientID: "some-client-id",
          environment: "sandbox",
        },
      },
    };
    const passedOptions = resolveParameters({
      recipe: passedConfiguration,
      mode: SdkModes.DUMMY,
    });

    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting } = await parseConfiguration(passedOptions, shared);
    const listener = jest.fn();
    resulting.globalEventHub.on("error", listener);
    expect(listener).not.toHaveBeenCalled();
    expect(resulting).toMatchObject({
      recipe: {
        name: "auto",
        deviceCharacteristics: {
          provider: {
            name: "sardine",
            clientID: "some-client-id",
            environment: "sandbox",
          },
        },
      },
    });
  });
});
describe("Recipe option resolution", () => {
  const { mockConfigurationPayload } = mockFrankieClientRequests();

  test("Missing recipe option resolves the same as the 'auto' string", async () => {
    mockConfigurationPayload({});
    const passedOptions = resolveParameters({ mode: SdkModes.DUMMY });
    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting } = await parseConfiguration(passedOptions, shared);
    expect(resulting.recipe).toMatchObject({
      name: "auto",
    });
  });
  test("Recipe as an object without property 'name' resolves the same as if it's defined as 'auto' string", async () => {
    mockConfigurationPayload({});
    const passedOptions = resolveParameters({ mode: SdkModes.DUMMY, recipe: {} });
    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting } = await parseConfiguration(passedOptions, shared);
    expect(resulting.recipe).toMatchObject({
      name: "auto",
    });
  });
  test("Recipe as a string simply resolves to itself", async () => {
    mockConfigurationPayload({});
    const passedOptions = resolveParameters({ mode: SdkModes.DUMMY, recipe: "some-recipe" });
    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting } = await parseConfiguration(passedOptions, shared);
    expect(resulting.recipe).toMatchObject({
      name: "some-recipe",
    });
  });
  test("Recipe as an object with property 'name' simply resolves to itself", async () => {
    mockConfigurationPayload({});
    const passedOptions = resolveParameters({ mode: SdkModes.DUMMY, recipe: { name: "some-recipe" } });
    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting } = await parseConfiguration(passedOptions, shared);
    expect(resulting.recipe).toMatchObject({
      name: "some-recipe",
    });
  });
  test("Recipe passed as 'auto'and no recipe name is returned from api resolves as 'auto'", async () => {
    mockConfigurationPayload({});
    const passedOptions = resolveParameters({ mode: SdkModes.DUMMY, recipe: { name: "auto" } });
    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting } = await parseConfiguration(passedOptions, shared);
    expect(resulting.recipe).toMatchObject({
      name: "auto",
    });
  });
  test("When recipe passed as auto and api returns a recipe name, resolves to that recipe name", async () => {
    mockConfigurationPayload({ auto: { name: "api-recipe-name" } });
    const passedOptions = resolveParameters({ mode: SdkModes.DUMMY, recipe: { name: "auto" } });
    const shared = await mkSharedDependencies(passedOptions);
    const { globalState: resulting } = await parseConfiguration(passedOptions, shared);
    expect(resulting.recipe).toMatchObject({
      name: "api-recipe-name",
    });
  });
});

function mockFrankieClientRequests() {
  const getMock = () => <jest.Mock>mkFrankieClient;
  const mockConfigurationPayload = (recipeConfiguration: { [k: string]: RecipeConfiguration }) => {
    const { frankieClient } = mockFrankieClient();
    frankieClient.get.mockResolvedValue(<AxiosResponse>{ data: recipeConfiguration });
    getMock().mockReturnValue(frankieClient);
    return frankieClient;
  };
  return {
    mockConfigurationPayload,
  };
}
