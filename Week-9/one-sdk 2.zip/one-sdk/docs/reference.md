---
pdf_options:
  format: a4
  margin: 30mm 20mm
  printBackground: true
  title: FrankieOne OneSDK Guide
  footerTemplate: |-
    <section>
      <div>
        Page <span class="pageNumber"></span> of <span class="totalPages"></span>
      </div>
    </section>
---

# FrankieOne OneSDK Reference

**ATTENTION: OneSDK is in ALPHA stage and is subject to change.**

## Version History

|     Date     |     Changes    |
|:------------:|:--------------:|
| 27 June 2021 | Added `individual.submissionInputs()`. |
| 16 June 2021 | Initial draft. |

## Setting up

### Including OneSDK

Include the OneSDK script on your site.

**Example:**

```js
<script src="https://assets.frankiefinancial.io/one-sdk/v0.2/oneSdk.umd.js"></script>
```

### Initializing OneSDK

Use the `async FrankieOne(options)` function to create an instance of the FrankieOne object. The FrankieOne object is your entry point to the rest of OneSDK.

**Options:**

The options object can contain the following properties:

* **`session`** (Session object)
  
  The Session object obtained from the response to `POST /machine-sessions`.

**Example:**

```js
const frankieOne = await FrankieOne({
    session
})
```

## The Individual object

The Individual object represents the customer being onboarded onto your application.

Within the FrankieOne API, this corresponds to the [Entity](https://apidocs.frankiefinancial.com/reference/createentity) API resource of type `"INDIVIDUAL"`.

### Access the Individual object

`frankieOne.individual(options?)`

This method access the Individual object.

Example:

```js
const individual = frankieOne.individual({

})
```

### Query which inputs are required for the current workflow

`individual.submissionInputs()`

This method returns an object containing a list of inputs that are required in order to sucessfully verify the individual.

This method merely reports whether inputs are required by the workflow. It does not indicate whether the data has already been supplied.

**Returns:**

An object with a `required` property that contains an array of objects representing the inputs that are required by the workflow. Each input object contains a `type` property equal to one of `"ocr"` or `"biometrics"`.

**Example:**

```js
const { required } = individual.submissionInputs();

console.log(JSON.stringify(required, null, '  '))
// [
//   {
//     "type": "ocr"
//   },
//   {
//     "type": "biometrics"
//   }
// ]
```

### Get accessors for attribute of an individual

`individual.access(attributeName)`

This method returns getter and setter accessors for an individual by attribute name. An attribute may be the individual's name, address or date of birth.

**Parameters:**

- **`attributeName`**
  
  string

  The name of the attribute to return.

  Allowable values:

  - `"name"`
  - `"address"`
  - `"dob"`

**Returns:**

Returns an object containing `getValue` and `setValue` accessors for the attribute's value.

**Example:**

```js
const { getValue, setValue } = individual.access('name');

// Retrieve the name. Returns undefined if not set yet.
const name = getValue()

// Set a new name.
setValue('new name');
```

### Add a document

`individual.addDocument(documentDetails)`

This method associates a new identity document with the individual.

### Submit an individual

`async individual.submit(options?)`

This method saves an individual in the FrankieOne system as an [Entity] API resource of type `"INDIVIDUAL"`. If the entity already exists it will be updated with any new attribute values.

You can optionally start the entity verification process by specifying the `verify` option.

**Parameters:**

- **`verify`**

  boolean

  If true, the individual will also be verified according to the default entity profile configured for your account.

  Default: false

**Returns:**

If the `verify` option was specified, the return value will indicate the results of the verification process.

**Example:**

```
const results = await individual.submit({
    verify: true
})

switch (results.recommendedAction) {
    case 'pass':
      // The individual passed the verification process
      break
    case 'fail'
      // The individual failed the verification process
      break
    case 'needs_attention'
      // The verification process must be manually passed or failed by a customer agent in the FrankieOne portal
      break
}
```

## The OCR Component

The OCR component enables collecting ID document information via image data extraction, and presenting detected document details to the user for review.

### Create an OCR Component

`frankieOne.component('ocr', options?)`

This method creates an instance of the OCR Component.

**Parameters:**

- **`type`**

  'ocr'

  The type of Component being created, which is 'ocr' in this case.

- **`options`**
  
  Options for creating an ocr component.

**Example:**

```js
const ocr = frankieOne.component('ocr', {

})
```

### Obtain previous results

`ocr.results()`

If an individual has already submitted document information via OCR and, this method will return any previous results from processing those documents.

***Example:**

```js
const previousResults = ocr.results()
```

### Start the OCR process

`ocr.start()`

This method starts the OCR process. Calling this method will immediately trigger the 'input_required' event to request the first image.

### The Processing event

`ocr.on('processing', handler)`

The processing event is triggered when the document image has been received by the server.

Use this event to display a progress interface.

**Example:**

```js
ocr.on('processing', ({ serviceLevel }) => {
  // serviceLevel will be one of 'immediate' or 'background' depending on the OCR provider.
})
```

### The Input Required event

`ocr.on('input_required', handler)`

The input required event is triggered when more information is required from the user to complete processing the document.

Typically this occurs when an additional image of the document is required, such as an image of the back of a drivers license in addition to an image of the front.

**Parameters:**

- **`type`**

  'input_required'

  The name of the event being listened to, which is 'input_required' in this case.

- **`handler`**
  
  A function that accepts three arguments:

  * `infoInfo`: An object that decribes what document input is required. Contains `documentType`. If `documentType` is equal to `'drivers_license'` this object will also contain `side`.
  * `state`: An object that describes any previous state that occured before this event was called. Contains `error` if this event was triggered in response to a previous image upload error.
  * `callback`: A function that accepts a single argument of type [`Blob`](https://developer.mozilla.org/en-US/docs/Web/API/Blob) containing your image data.

**Example:**

```js
ocr.on('input_required', (inputInfo, state, callback) => {
  const { documentType, side } = inputInfo
  if (documentType === 'passport') {
    // present UI to capture a passport image
  } else if (documentType === 'drivers_license') {

    // check which side of the drivers licenses is required
    if (side === 'front') {
      // present UI to capture the front side
    } else if (side === 'back') {
      // present UI to capture the back side
    } else {
      // present UI to capture any side
    }
  } else {
    // present UI to capture any type of identity document
  }
})
```

### The Results event

`ocr.on('results', handler)`

The results event is triggered when the ocr process has completed for a given document.

**Parameters:**

- **`type`**

  'input_required'

  The name of the event being listened to, which is 'results' in this case.

- **`handler`**
  
  A function that accepts one arguments:

  * `document`: The document object, which can be inspected for ocr and verification results.

**Example:**

```js
ocr.on('results', (results) => {
  const { document } = results
  if (document.verified) {

  } else {

  }
})
```

### Error event

`ocr.on('error', handler)`

The error event is triggered when a document image could not be processed.

**Example:**

```js
ocr.on('error', (error) => {
  console.error(error.message)
})
```

## The Biometrics Component

The Biometrics Component enables performing selfie and liveness checks of the individual being onboarding. The component embeds its own user interface in your web page.

### Create a Biometrics Component

`frankieOne.component('biometrics', options?)`

This method creates an instance of the Biometrics Component.

**Parameters:**

- **`type`**

  'biometrics'

  The type of Component being created, which is 'biometrics' in this case.

- **`options`**
  
  Options for creating a biometrics component.

**Example:**

```js
const biometrics = frankieOne.component('biometrics', {

})
```

### Mount the Biometrics Component

`biometrics.mount(domElement)`

This method attaches the Biometrics Component to the DOM. It accepts either a CSS Selector (e.g., `'#biometrics-container'`) or a DOM element.

You need to create a container DOM element to mount the component.

**Parameters:**

- **`domElement`**

  string | DOM element

  The CSS selector or DOM element where the component will be mounted.


**Example:**

```js
biometrics.mount(document.getElementById('biometrics-container'))
```

### The Results event

`biometrics.on('results', handler)`

The results event is triggered when the biometrics process has completed.

**Example:**

```js
biometrics.on('results', ({ verified }) => {
  if (verified) {

  } else {

  }
})
```

### The Error event

The error event is triggered when biometrics data could not be processed.

**Example:**

```js
biometrics.on('error', (error) => {
  console.error(error.message)
})
```

## The Document object

The document is object is returned in the results provided by the OCR Component.

View the [Document Object guide](https://apidocs.frankiefinancial.com/docs/fundamentals-document-object) to learn more about documents.

***Attributes:**

| Attribute name | Description |
|:-------------:|:-----------:|
| docmentId     | An identifier for the document in FrankieOne. |
| dateOfBirth   | Contains the document owner's date of birth, if specified. |
| country       | The country code where the document was issued. For example, `"AUS"`. |
| idNumber      | The document number. |
| gender        | Contains the document owner's gender, if specified. One of `"U"`, `"F"`, `"M"` or `"O"'`. |
| idType        | The type of document. One of `"PASSPORT"` or `"DRIVERS_LICENSE"`. |.
| idExpiry      | The expiration date of the document. |
| extraData     | Contains extra data as [Key-Value Pairs](https://apidocs.frankiefinancial.com/docs/key-value-pairs). |
