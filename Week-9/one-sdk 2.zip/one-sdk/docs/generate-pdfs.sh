#!/bin/bash

npx md-to-pdf ./*.md
