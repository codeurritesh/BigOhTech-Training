import { Accessors, ReactiveStore } from "@module/common";
import { mockAccessors } from "../mocks/ReactiveStore";

describe("ReactiveStore", () => {
  test("ReactiveStore is an extension of BehaviourSubject, exposing methods next and subscribe", () => {
    const state = new ReactiveStore({ string: "a", boolean: false, number: 0 });
    const observer = jest.fn();
    state.subscribe(observer);
    state.next({
      string: "b",
      boolean: true,
      number: 1,
    });
    expect(observer).toHaveBeenCalledWith({
      string: "b",
      boolean: true,
      number: 1,
    });
  });
  test("ReactiveStore internal storage is immutable and doesn't return references", () => {
    const object = { value: "value" };
    const state = new ReactiveStore({ object, boolean: false, number: 0 });
    const accessors = state.getRootAccessors("object");
    const observer = jest.fn();
    state.subscribe(observer);

    expect(accessors.getValue()).not.toBe(object);
  });
});
describe("ReactiveStore::mkComputedAccessors", () => {
  test("generates ReadonlyAccessors for provided Accessors", () => {
    const accessors = mockAccessors({ accessors: false });
    const readonlyAccessors = ReactiveStore.mkComputedAccessors(accessors);
    expect(readonlyAccessors).toMatchObject({
      property: "computed(accessors)",
      getValue: expect.any(Function),
      observable: expect.any(Object),
    });
    expect((readonlyAccessors as Accessors).setValue).toBeFalsy();
    expect(readonlyAccessors.getValue()).toBe(false);
  });
  test("generated ReadonlyAccessors emits when origin's value is updated", () => {
    const accessors = mockAccessors({ accessors: false });
    const readonlyAccessors = ReactiveStore.mkComputedAccessors(accessors);
    const observer = jest.fn();
    readonlyAccessors.observable.subscribe(observer);
    accessors.setValue(true);
    expect(observer).toHaveBeenCalledWith(true);
  });
  test("option 'transformer' generates transformed ReadonlyAccessors for provided Accessors", () => {
    const accessors = mockAccessors({ accessors: false });
    const readonlyAccessors = ReactiveStore.mkComputedAccessors(accessors, {
      transformer: (v) => (v ? "true" : "false"),
    });
    const observer = jest.fn();
    readonlyAccessors.observable.subscribe(observer);
    accessors.setValue(true);
    expect(observer).toHaveBeenCalledWith("true");
  });
  test("option 'emitArrayOfLatestValues: 3' generate latest 3 values from source", () => {
    const accessors = mockAccessors({ accessors: false });
    const readonlyAccessors = ReactiveStore.mkComputedAccessors(accessors, {
      emitArrayOfLatestValues: 3,
    });
    const observer = jest.fn();
    readonlyAccessors.observable.subscribe(observer);
    accessors.setValue(true);
    accessors.setValue(false);
    expect(observer).toHaveBeenCalledWith([false, true, false]);
  });
  test("repeated subsequent values, according to option 'changeDetector', are not emitted", () => {
    const accessors = mockAccessors({ accessors: "A" }); // 1
    const readonlyAccessors = ReactiveStore.mkComputedAccessors(accessors, {
      emitArrayOfLatestValues: 4,
      changeDetector: (a, b) => a == b,
    });
    const observer = jest.fn();
    readonlyAccessors.observable.subscribe(observer);
    accessors.setValue("A");
    accessors.setValue("B"); // 2
    accessors.setValue("B");
    accessors.setValue("C"); // 3
    accessors.setValue("D"); // 4
    accessors.setValue("E"); // 5
    expect(observer).toHaveBeenNthCalledWith(5, ["B", "C", "D", "E"]);
    expect(observer).toHaveBeenCalledTimes(5);
  });
  test("when option emitArrayOfLatestValues: 4, if only 2 values were emitted, is completed with nulls", () => {
    const origin = mockAccessors({ origin: "A" });
    const readonlyAccessors = ReactiveStore.mkComputedAccessors(origin, {
      emitArrayOfLatestValues: 4,
    });
    const observer = jest.fn();
    readonlyAccessors.observable.subscribe((v) => {
      // because jest seems to lose an array with multiple "null" values,
      // i'm serialising it first
      return observer(JSON.stringify(v));
    });
    origin.setValue("B");
    expect(observer).toHaveBeenNthCalledWith(1, JSON.stringify([null, null, null, "A"]));
    expect(observer).toHaveBeenNthCalledWith(2, JSON.stringify([null, null, "A", "B"]));
    expect(observer).toHaveBeenCalledTimes(2);
  });
});

describe("ReactiveStore::mkPropertyAccessors", () => {
  test("generates Accessors for a property of the provided Accessors", () => {
    const objectAccessors = mockAccessors({ object: { aProp: "property" } });
    const propertyAccessors = ReactiveStore.mkPropertyAccessors(objectAccessors, { propertyName: "aProp" });

    const observer = jest.fn();
    propertyAccessors.observable.subscribe(observer);

    objectAccessors.setValue({ aProp: "changed" });

    expect(observer).toHaveBeenNthCalledWith(1, "property");
    expect(observer).toHaveBeenNthCalledWith(2, "changed");
    expect(observer).toHaveBeenCalledTimes(2);
  });
  test("option.emitArrayOfLatestValues: N generates Accessors for the past N values for a property of the provided Accessors", () => {
    const objectAccessors = mockAccessors({ object: { aProp: "property" } });
    const propertyAccessors = ReactiveStore.mkPropertyAccessors(objectAccessors, {
      emitArrayOfLatestValues: 5,
      propertyName: "aProp",
    });

    const observer = jest.fn();
    propertyAccessors.observable.subscribe((v) => {
      // because jest seems to lose an array with multiple "null" values,
      // i'm serialising it first
      return observer(JSON.stringify(v));
    });

    objectAccessors.setValue({ aProp: "changed" });

    expect(observer).toHaveBeenNthCalledWith(1, JSON.stringify([null, null, null, null, "property"]));
    expect(observer).toHaveBeenNthCalledWith(2, JSON.stringify([null, null, null, "property", "changed"]));
    expect(observer).toHaveBeenCalledTimes(2);
  });
  test("setValue changes value immediately and triggers subscribers", () => {
    const objectAccessors = mockAccessors({ object: { aProp: "property" } });
    const propertyAccessors = ReactiveStore.mkPropertyAccessors(objectAccessors, {
      propertyName: "aProp",
    });

    const observer = jest.fn();
    // propertyAccessors.observable.subscribe(observer);
    propertyAccessors.observable.subscribe(observer);

    expect(propertyAccessors.getValue()).toBe("property");

    propertyAccessors.setValue("changed");
    expect(propertyAccessors.getValue()).toBe("changed");
    propertyAccessors.setValue("yet-again");
    expect(propertyAccessors.getValue()).toBe("yet-again");

    expect(observer).toHaveBeenNthCalledWith(1, "property");
    expect(observer).toHaveBeenNthCalledWith(2, "changed");
    expect(observer).toHaveBeenNthCalledWith(3, "yet-again");
    expect(observer).toHaveBeenCalledTimes(3);
  });
});
