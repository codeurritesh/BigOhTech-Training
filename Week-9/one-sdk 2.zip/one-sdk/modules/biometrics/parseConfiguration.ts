import { InjectedState } from "@module/common/types";

export function validateConfiguration(options: InjectedState) {
  const { recipe } = options;

  if (!recipe.biometrics) throw new Error("Missing biometrics configuration");
}
