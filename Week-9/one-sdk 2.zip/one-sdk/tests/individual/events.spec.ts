import { PublicAccessors } from "@module/individual";
import { subscribeAndEmitEvents } from "@module/individual/actions/emitEvents";
import { EventHubMock } from "../mocks/EventHub";
import { mockAccessors } from "../mocks/ReactiveStore";

describe("individual::event(data_updated)", () => {
  test("Map publicAccessors subscription to data_updated events", () => {
    const publicAccessors = <PublicAccessors>(<unknown>{
      name: mockAccessors({ name: "original-value" }),
      dateOfBirth: mockAccessors({ dateOfBirth: "original-value" }),
    });
    const eventHub = new EventHubMock();
    const applicant$ = mockAccessors({ applicant: null });
    const documents$ = mockAccessors({ documents: null });
    const isPersisted$ = mockAccessors({ isPersisted: false });

    subscribeAndEmitEvents({
      emitDataUpdatedFor: [publicAccessors.name, publicAccessors.dateOfBirth],
      eventHub,
      applicant$,
      documents$,
      isPersisted$,
    });
    expect(publicAccessors.name.observable.subscribe).toHaveBeenCalled();
    expect(publicAccessors.dateOfBirth.observable.subscribe).toHaveBeenCalled();

    publicAccessors.dateOfBirth.setValue("the-value");
    expect(eventHub.emit).toHaveBeenCalledWith("data_updated", "dateOfBirth", "the-value");
    // isPersisted$.setValue is called initially after subscribing to applicant$ and documents$
    // then another type after applicant$ is updated and a fourth after documents$ is updated
    expect(isPersisted$.setValue).toHaveBeenCalledTimes(2);
    expect(isPersisted$.setValue).not.toHaveBeenCalledWith(true);
    
    applicant$.setValue({ name: { givenName: "the-value" } });
    expect(isPersisted$.setValue).toHaveBeenNthCalledWith(3, false);
    expect(isPersisted$.setValue).toHaveBeenCalledTimes(3);

    documents$.setValue([{}]);
    expect(isPersisted$.setValue).toHaveBeenNthCalledWith(4, false);
    expect(isPersisted$.setValue).toHaveBeenCalledTimes(4);
  });
});
