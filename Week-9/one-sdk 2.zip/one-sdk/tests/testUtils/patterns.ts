export const mockedPreloadedMatcher = expect.stringMatching(/^mockpreloaded-/);
export const mockedUuidMatcher = expect.stringMatching(/^mocked-uuid-package-/);
export const uuidMatcher = expect.stringMatching(
  /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/
);

export const dateMatcher = expect.stringMatching(/^\d{4}-\d{2}-\d{2}T/);
