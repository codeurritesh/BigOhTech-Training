type TAssociate = { relation: string; name: string };
export interface IAmlMatchDetailsPayload {
  name: string;
  dateOfBirth: string | null;
  aka: string[];
  countries: string[];
  associates: TAssociate[];
  addresses: string[];
  matchStatus: string;
  imageURL: string | null;
}

export interface IAmlMatchDetailsConstructor {
  name: string;
  dateOfBirth: string | null;
  aka: string[];
  countries: string[];
  associates: TAssociate[];
  matchStatus: string;
  imageURL: string | null;
}
export class AmlMatchDetails implements IAmlMatchDetailsPayload {
  name: string;
  dateOfBirth: string | null;
  aka: string[];
  countries: string[];
  associates: TAssociate[];
  matchStatus: string;
  imageURL: string | null;
  addresses: string[];

  constructor(a: IAmlMatchDetailsPayload) {
    this.name = a.name;
    this.matchStatus = a.matchStatus;
    this.dateOfBirth = a.dateOfBirth || null;
    this.aka = a.aka || [];
    this.countries = a.countries || [];
    this.associates = a.associates || [];
    this.addresses = a.addresses || [];
    this.imageURL = a.imageURL || null;
  }

  toJSON(): IAmlMatchDetailsPayload {
    return { ...this };
  }

  static fromJSON(payload: IAmlMatchDetailsPayload): AmlMatchDetails {
    return new AmlMatchDetails({ ...payload });
  }
}
