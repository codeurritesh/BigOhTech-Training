import type OneSdk from '@frankieone/one-sdk';

declare global {
  declare type OneSdk = typeof OneSdk;
  interface Window {
    OneSdk: OneSdk;
  }
}
