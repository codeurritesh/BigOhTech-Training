import type { KeyOf } from "@types";
import type { ApplicantClient } from "./clients/ApplicantClient";
import type { ConfigurationClient } from "./clients/ConfigurationClient";
import type { TelemetryEventsClient } from "./clients/TelemetryEventsClient";
import type { FrankieApiClient } from "./FrankieApiClient";

export interface FrankieClient {
  new (frankie: FrankieApiClient, options: unknown);
}
export type ClientsConstructorDictionary = {
  configuration: typeof ConfigurationClient;
  applicant: typeof ApplicantClient;
  telemetry: typeof TelemetryEventsClient;
};
type ClientName = KeyOf<ClientsConstructorDictionary>;
export type InstanceOf<Which extends ClientName> = InstanceType<ClientsConstructorDictionary[Which]>;
export type ConstructorOf<Which extends ClientName> = ClientsConstructorDictionary[Which];
export type OptionsFor<Which extends ClientName> = ConstructorParameters<ConstructorOf<Which>>[1];
export type LoadClientParametersFor<Which extends ClientName> = OptionsFor<Which> extends undefined
  ? [Which]
  : [Which, OptionsFor<Which>];
