import { Kvp } from "./general";

type KvpType = Kvp["kvpType"];
export class KvpList {
  private list: Kvp[];
  constructor(list: Kvp[] = []) {
    this.list = list;
  }
  static convertToType(v?: string, _t: KvpType = "general.string") {
    // replace undefined with null
    if (!v) return null;
    return v;
    // switch(t) {
    //   case "general.string": return v;
    //   case "general.datetime": return new Date(v);
    //   default : JSON.parse(v);
    // }
  }
  deleteEntry(key) {
    const index = this.list.findIndex((kvp: Kvp) => kvp.kvpKey === key);
    if (index >= 0) this.list.splice(index, 1);
  }
  findKvpObject(key: string | RegExp): Kvp | null {
    if (typeof key === "string") key = "^" + key + "$"; //Make string to find exact match
    const kvpKeyExistsAndEquals = (kvpKey) => {
      if (!kvpKey) return false;
      return kvpKey?.toLowerCase().match(new RegExp(key, "i"));
    };
    return this.list?.find(({ kvpKey }) => kvpKeyExistsAndEquals(kvpKey)) || null;
  }
  findKvpValue(key: string | RegExp): string | null {
    const kvp = this.findKvpObject(key);
    if (kvp === null) return null;
    return kvp.kvpValue ?? null;
  }
  findNumericKvpValue(key: string): number | null {
    const value = this.findKvpValue(key);
    if (value === null) return null;
    if (value.length === 0) return NaN;
    return +value; // convert to number, either integer, float or NaN in case it's not a number
  }
  findArrayKvpValue(key: string | RegExp): string[] | null {
    const value = this.findKvpValue(key);
    if (value === null) return null;
    if (value.length === 0) return [];
    return value.split(",");
  }
  findBooleanKvpValue(key: string): boolean | null {
    const value = this.findKvpValue(key);
    if (value === "true") return true;
    if (value === "false") return false;
    return null;
  }
  filterKvpKeyByRegex(regex: RegExp): KvpList {
    const cb = (kvp) => {
      const kvpKey = kvp.kvpKey ?? null;
      if (!kvpKey) return false;
      return regex.test(kvpKey);
    };
    return this.filter(cb);
  }
  addKvp(kvp: Kvp): void {
    this.list.push(kvp);
  }
  replaceKvp(kvp: Kvp): void {
    if (kvp.kvpKey && !this.findKvpValue(kvp.kvpKey)) return this.addKvp(kvp);
    this.list.forEach((k) => {
      if (k.kvpKey === kvp.kvpKey) {
        k.kvpType = kvp.kvpType ?? undefined;
        k.kvpValue = kvp.kvpValue ?? null;
      }
    });
  }
  static mkKvp(k?: string, v?: any, t?: string, isStringify = true): Kvp {
    if (!v) v = ""; //value can not be null or undefined, must be an empty string
    if (isStringify && typeof v !== "string") {
      v = JSON.stringify(v);
    }

    const kvp = {
      kvpKey: k,
      kvpValue: v,
    } as any;
    if (t) kvp.kvpType = t;
    return kvp;
  }
  get transformed(): Kvp[] {
    return this.list.map((kvp) =>
      KvpList.mkKvp(kvp.kvpKey, KvpList.convertToType(kvp.kvpValue, kvp.kvpType), kvp.kvpType)
    );
  }

  toJSON(): Kvp[] {
    return this.transformed;
  }

  static fromJSON(list: Kvp[]): KvpList {
    return new KvpList(list);
  }

  filter(cb: (e: Kvp) => boolean) {
    return new KvpList(this.list.filter(cb));
  }
  toObject(): { [key: string]: any } {
    return this.list.reduce((carry, kvp: Kvp) => {
      const key = kvp.kvpKey;
      const value = kvp.kvpValue ?? null;
      if (!key) return {};
      carry[key] = value;
      return carry;
    }, {});
  }
  get kvpList() {
    return this.list;
  }
  static fromObject(obj: { [key: string]: any }) {
    const mkKvpFromEntries = (entry: [string, any]) => KvpList.mkKvp(entry[0], entry[1]);
    const kvpEntries: [string, any][] = Object.entries(obj);
    const kvpList: Kvp[] = kvpEntries.map(mkKvpFromEntries);
    return new KvpList(kvpList);
  }
}
