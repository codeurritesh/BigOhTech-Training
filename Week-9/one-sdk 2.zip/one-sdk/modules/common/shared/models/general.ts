import { PartialDeep } from "type-fest";
import { Admin } from "./Admin";
import { Core } from "./Core";
export declare type Nullable<T> = T | null;
export declare type IStringOrNull = string | null;
export declare type Dictionary<T = any> = {
  [key: string]: T;
};
export declare type Kvp = (AdminKvpWithoutValue | CoreKvpWithoutValue) & { kvpValue: any };
export declare type DictionaryReturnTypes<D extends Dictionary<(...args: any) => any>> = {
  [P in keyof D]: ReturnType<D[P]>;
};
export declare type DeepPartial<T> = PartialDeep<T>;
export declare interface ICloneable<T> {
  clone(): T;
}
type AdminKvpWithoutValue = Omit<Admin["KeyValuePairObject"], "kvpValue">;
type CoreKvpWithoutValue = Omit<Core["KeyValuePairObject"], "kvpValue">;
export declare type TDOBTypeSupport = "gregorian" | "buddhist";
export declare type DateObject = { dd: IStringOrNull; mm: IStringOrNull; yyyy: IStringOrNull };
export declare type ExtraData = { [field: string]: Nullable<string | boolean | number> };
export type IChannel = "portal" | "smart-ui" | "support-portal" | "unknown" | Admin["enumChannel"];
