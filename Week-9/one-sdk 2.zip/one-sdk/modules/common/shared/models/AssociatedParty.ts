import { Applicant } from "./Applicant";
import { BusinessInfo } from "./BusinessInfo";

export type TAssociationPercentage = {
  beneficially: number;
  jointly: number;
  nonBeneficially: number;
};

export type TAssociationRole = {
  type: AssociationRoleType;
  typeDescription: string;
};

export interface IAssociatedParty {
  addedBy: string;
  percentage: TAssociationPercentage;
  roles: TAssociationRole[];
  hidePartyFromSearch?: boolean;
  party?: Applicant | BusinessInfo;
  partyType?: "INDIVIDUAL" | "BUSINESS";
}

export class AssociatedParty implements IAssociatedParty {
  addedBy: string;
  percentage: TAssociationPercentage;
  hidePartyFromSearch?: boolean;
  roles: TAssociationRole[];
  party?: Applicant | BusinessInfo;
  partyType?: "INDIVIDUAL" | "BUSINESS";

  constructor(payload: IAssociatedParty) {
    this.addedBy = payload.addedBy;
    this.percentage = payload.percentage;
    this.roles = payload.roles;
    this.party = payload.party;
    this.partyType = payload.partyType;
    this.hidePartyFromSearch = payload.hidePartyFromSearch;
  }

  toJSON(): IAssociatedParty {
    return {
      ...this,
    };
  }

  static fromJSON(payload: IAssociatedParty): AssociatedParty {
    return new AssociatedParty({
      ...payload,
    });
  }
}

export enum AssociationRoleType {
  DIR = "DIR",
  SCR = "SCR",
  OWNR = "OWNR",
  SHRH = "SHRH",
  OTH = "OTH",
  TRST = "TRST",
  BEN = "BEN",
  SET = "SET",
  APP = "APP",
}

export const ASSOCIATION_ROLE_DESCRIPTION = new Map<AssociationRoleType, string>([
  [AssociationRoleType.DIR, "Director"],
  [AssociationRoleType.SCR, "Secretary"],
  [AssociationRoleType.OWNR, "Owner"],
  [AssociationRoleType.SHRH, "Shareholder"],
  [AssociationRoleType.TRST, "Trustee"],
  [AssociationRoleType.BEN, "Beneficiary"],
  [AssociationRoleType.SET, "Settler"],
  [AssociationRoleType.APP, "Appointer"],
]);
