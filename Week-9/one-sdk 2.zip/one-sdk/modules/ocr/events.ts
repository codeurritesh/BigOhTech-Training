import type { Document } from '@module/common/shared/models/Document';
import type { OCRStatus } from '@module/frankie-client/clients/OCRClient';

export type Events = {
  session_data_generated: [{ session: unknown }];
  session_data_failed_loading: [{ code?: unknown; message: string }];
  ready: [{ domElement: HTMLElement }];
  detection_complete: [];
  detection_failed: [{ message?: string }];
  input_required: [Info, OCRStatus, ProvideFile];
  results: [{ document: Document; entityId: string }];
  file_uploaded: [FileUploadedMeta];
  session_closed: [];
};
export type FileUploadedMeta = {
  fileName: string;
  mimeType: string;
  scanId: string;
  statusAfterUpload: OCRStatus;
  statusBeforeUpload: OCRStatus;
};
export type Info = { documentType: Document['idType']; side: 'front' | 'back' };
export type ProvideFile = (blob: File) => void;
