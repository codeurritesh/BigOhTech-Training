import type { BiometricsModule } from '@module/biometrics';
import type { EventHub } from '@module/common';
import type { ModuleDefinition } from '@module/common/types';
import type { IDVStatus } from '@module/frankie-client/clients/IDVClient';
import type { OCRModule } from '@module/ocr';
import type { Override } from '@types';

import type { Events } from './events.types';
import type { PartialDeep } from 'type-fest';

export type IDVModule = ModuleDefinition<{
  module: {
    category: 'flow';
    name: 'idv';
    context: IDVContext;
    events: Events;
    options: PartialDeep<IDVRecipeOptions>;
    recipe: { idv: IDVRecipeOptions };
  };
  wrapper: {
    vendors: ['mastercard', 'ocrlabs', 'incode', 'onfido'];
    options: BiometricsModule['wrapperOptions'];
    loadType: 'async';
  };
}>;

type IDVContext = Override<
  OCRModule['moduleContext'] & BiometricsModule['moduleContext'],
  {
    start: never;
    statuses: typeof IDVStatus;
  }
>;

export type IDVEventHub = EventHub<IDVModule['moduleEvents']>;

type IDVRecipeOptions = {
  provideReviewScreen?: boolean;
  provider:
    | {
    name: 'mastercard' | 'incode';
  }
    | {
    name: 'ocrlabs';
    /** Set this if the redirect url is different to the initial url */
    redirect_uri?: string;
  }
    | {
    name: 'onfido';
    maxDocumentCount?: number;
    fallback?: 'standard' | 'video';
  };
};
