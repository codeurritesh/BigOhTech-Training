import { parse } from "dotenv-flow";
import { existsSync } from "fs";
import { resolve } from "path";

type EnvironmentVariables = Record<string, string>;
const thisDirectory = __dirname; // dirname(import.meta.url);
const dotEnvPath = resolve(thisDirectory, "..", ".env");
/**
 * This function must be called from the root of the project, where the .env file lies
 * @param envPrefix prefix to add to environment variables passed to "define" plugin
 * @returns both the raw environment variables and the replacements for the "define" plugin
 */
export function getDotEnvVariables(): EnvironmentVariables;
export function getDotEnvVariables(envPrefix: string): {
  dotEnvVariables: EnvironmentVariables;
  definePluginReplacements: EnvironmentVariables;
};
export function getDotEnvVariables(envPrefix?: string) {
  const dotEnvExists = existsSync(dotEnvPath);
  if (!dotEnvExists) console.warn("No .env found. This could be a problem.");

  const dotEnvVariables: EnvironmentVariables = Object.assign(dotEnvExists ? parse(dotEnvPath) : {}, {
    ENV: process.env.NODE_ENV,
  });
  if (!envPrefix) return dotEnvVariables;

  const definePluginReplacements = Object.entries(dotEnvVariables).reduce((env, [key, value]) => {
    const mergedKey = [envPrefix, key].filter(Boolean).join(".");
    env[mergedKey] = `"${value}"`;
    return env;
  }, <EnvironmentVariables>{});

  return { dotEnvVariables, definePluginReplacements };
}
