import { ID_OPTIONS } from './constants';

type TDocumentDetails = { label: string, value: string, available?: string[], excluded?: string[] };
export function getDocumentDetails(code: string): TDocumentDetails | null {
  return ID_OPTIONS.find(d => d.value === code) ?? null;
}