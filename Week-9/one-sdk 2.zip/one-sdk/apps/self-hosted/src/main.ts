import './styles/style.css';
import './styles/loader.css';

import { LOGGING } from './constants';
import { setLoading } from './scripts/loadingAnimation';
import { exchangeShortToken, loadOneSDK } from './scripts/loadOneSdk';

/**
 * Expected URL parameters:
 * - v: The version of the OneSDK to load. Defaults to 'v1'.
 * - t: The short-lived token to exchange for a session token.
 * - j: The full jwt token to use as a session token, instead of the short-lived token.
 */
(async () => {
  setLoading(true);
  // Entry point for the self-hosted demo app.
  const parameters = new URLSearchParams(window.location.search);

  // Set all the required initial requests to be made in parallel
  const preloadedAssets: [Promise<OneSdk>, Promise<string>?] = [loadOneSDK(parameters.get('v') ?? 'v1')];
  // If the full jwt token is not provided, also exchange the short token with the full token
  if (parameters.has('t')) preloadedAssets.push(exchangeShortToken(parameters.get('t')));

  const [OneSDK, exchangedToken] = await Promise.all(preloadedAssets);

  // Either use the newly fetched session token, or fallback to the provided jwt token, if any
  const sessionToken = exchangedToken ?? parameters.get('j')!;
  if (!sessionToken) throw new Error('Missing authorization');

  const oneSdkInstance = await OneSDK({
    session: {
      token: sessionToken,
    },
    telemetry: true,
    devtools: true,
    mode: OneSDK.modes.PROD,
    recipe: {},
  });
  const idvFlow = oneSdkInstance.flow('idv');

  if (LOGGING) {
    oneSdkInstance.on('*', OneSDK.wildcardEventLogger);
    idvFlow.on('*', OneSDK.wildcardEventLogger);
  }

  const appContainer = document.querySelector('#app') as HTMLDivElement;
  idvFlow.on('ready', () => {
    setLoading(false);
    appContainer.style.display = 'block';
  });
  idvFlow.mount(appContainer);
})();
