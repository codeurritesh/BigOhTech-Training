---
pdf_options:
  format: a4
  margin: 30mm 20mm
  printBackground: true
  title: FrankieOne OneSDK Guide
  footerTemplate: |-
    <section>
      <div>
        Page <span class="pageNumber"></span> of <span class="totalPages"></span>
      </div>
    </section>
---

# FrankieOne OneSDK Guide

**ATTENTION: OneSDK is in ALPHA stage and is subject to change.**

## Version History

|    Date     |                                                                                              Changes                                                                                              |
| :---------: | :-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| 30 Sep 2022 |                                                                               Updated biometrics event information                                                                                |
| 08 Sep 2022 |                                                                      Changed current version to v0.3-alpha. Added npm module                                                                      |
| 06 Sep 2022 |                                                                                 Updated biometrics event examples                                                                                 |
| 25 Aug 2022 |                                                          Specified that documentType should be in uppercase. Removed duplicated sections                                                          |
| 27 Jul 2022 |                     Changed current version to v0.2-alpha. Specified that the session must be created with entity ID. Included details on how to use OneSDK in "dummy" mode.                      |
| 27 Jun 2022 | Included a step to query which inputs are required under the current workflow for the entity. Added a step to perform KYC verification. Updated the final step to await on the `submit()` method. |
| 20 Jun 2022 |                                         Clarified that the image data for OCR must be provided as a File object, though it can be obtained by any means.                                          |
| 16 Jun 2022 |                                                                                          Initial draft.                                                                                           |

## Overview

OneSDK is a client-side JavaScript SDK for onboarding individuals onto your application using FrankieOne. OneSDK consists of multiple components which can be seamlessly embedded into your onboarding flow at key points in order to verify identify documents and biometrics.

## How it works

The user onboarding flow works as follows:

1. The user navigates to your registration webpage.
2. Before serving the frontend, your server communicates with our server to create a temporary session object
3. Your server includes the session object as part of the frontend of your webpage.
4. Your webpage initializes OneSDK using the session object from the server.
5. OneSDK handles the collection and verification of identify documents and biometrics.
6. You onboard the individual using FrankieOne's Verify Entity API.

## Step 1: Create a session

> NOTE: this step can be skipped during development. For quick prototyping jump to the section "Dummy mode" below.

Obtain a session on your backend and forward it to your frontend web page.

### Construct the API credentials

1. Serialize your FrankieOne API credentials to a string using ':' as a separator.
2. Encode the resulting string using Base64 encoding.

If you are using a macOS or Linux operating system, run the following command in a terminal:

```sh
echo -n 'CUSTOMER_ID:API_KEY' | openssl base64
```

Or in Node.js

```node
const base64EncodedCredentials = Buffer.from(`${CUSTOMER_ID}:${API_KEY}`).toString("base64");
```

If you have a child account with FrankieOne, modify the above command to the following:

```sh
echo -n 'CUSTOMER_ID:CUSTOMER_CHILD_ID:API_KEY' | openssl base64
```

### Obtain a temporary session token

Send a `POST` request to the `/machine-sessions` endpoint of our Backend for Frontend server (BFF). The appropriate URL for BFF depends on the environment you're integrating with:

| Environment |                     BFF URL                     |
| :---------: | :---------------------------------------------: |
|    Demo     |    https://backend.demo.frankiefinancial.io/    |
|     UAT     | https://backend.kycaml.uat.frankiefinancial.io/ |
| Production  |   https://backend.kycaml.frankiefinancial.io/   |

Pass the encoded credential in the `Authorization` request header using `machine` as the scheme:

`Authorization: machine YOUR_ENCODED_CREDENTIAL`

Include the following parameters in the body of the request:

|     Parameter name     | Required | Description                                                           |
| :--------------------: | :------: | --------------------------------------------------------------------- |
|     `permissions`      | Required | A hash containing `preset` and `entityId`.                            |
|  `permissions.preset`  | Required | The string `'one-sdk'`.                                               |
| `permissions.entityId` | Required | A string containing the entity ID for the individual being onboarded. |

The following example creates a session object for a user using an existing entity ID:

```sh
ENCODED_CREDENTIAL=$(echo -ne "$YOUR_CUSTOMER_ID:$API_KEY" | base64);

curl https://backend.demo.frankiefinancial.io/auth/v2/machine-session \
  -X POST \
  -H "Authorization: machine $ENCODED_CREDENTIAL"
  -H 'Content-Type: application/json' \
  -d '{
    "permissions": {
      "preset": "one-sdk",
      "entityId": "YOUR_ENTITY_ID",
    }
  }';
```

Or using the Javascript Fetch API:

```js
const sessionObject = fetch(`${FRANKIE_BFF_URL}/auth/v2/machine-session`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    authorization: "machine " + Buffer.from(`${CUSTOMER_ID}:${CUSTOMER_CHILD_ID}:${API_KEY}`).toString("base64"),
  },
  body: JSON.stringify({
    permissions: {
      preset: "one-sdk",
      entityId: "YOUR_ENTITY_ID",
    },
  }),
}).then((response) => response.json());
```

> :warning: **ATTENTION**: DO NOT PUBLISH YOUR CREDENTIALS TO THE FRONTEND. THEY SHOULD REMAIN ACCESSIBLE ONLY TO YOUR SERVER.

> **Don't forget the header** `Content-Type: application/json`

Sample response:

```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
}
```

## Step 2: Set up OneSDK

Use OneSDK to onboard an individual into your application.

### Install the SDK

#### Embed script

The current version is v0.3-alpha.

```
<script src="https://assets.frankiefinancial.io/one-sdk/v0.3-alpha/oneSdk.umd.js"></script>
```

#### NPM Module

npm install @frankieone/one-sdk

### Create configuration object

Create an object for the global configuration of your SDK integration. This section shows the required and recommended parameters.

| Parameter name |                      Required                      | Description                                                                                                                                               |
| :------------: | :------------------------------------------------: | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
|   `session`    | Required, unless `mode` is specified as `"dummy"`. | The session object from your call to `/machine-sessions`.                                                                                                 |
|     `mode`     |                      Optional                      | One of `"production"` or `"dummy"`. If this is specified as `"dummy"`, then `session` does not need to be specified. The default value is `"production"`. |

Sample configuration:

```js
const configuration = {
  session: sessionObject,
};
```

**Don't extract the token from the response.** The entire object returned from the `/machine-sessions` API must be included as the `session` parameter, not just the token.

For example your server-side code may look like:

```php
<?php $sessionResponse = createFrankieSession(); ?>
<script>
  const session = JSON.parse('<?php echo json_encode($sessionResponse) ?>'); // session is the object { token: "...." }
  const oneSdk = await OneSdk({ session });
</script>
```

Or in Node.js + Twig template engine

```js
<script>
  {% set sessionObject = await createFrankieSession(); %}

  const sessionObject = JSON.parse("{{ sessionObject | json_encode | raw }}"); // session is the object { token: "...." }
  const oneSdk = await OneSdk({ session: sessionObject });
</script>
```

#### Dummy mode

In order to facilitate quick prototyping, OneSDK provides a "dummy" mode, which doesn't communicate with backend services so doesn't require a session object. When configured in "dummy" mode, OneSDK uses pre-canned responses. All requests and their corresponding responses are logged in the browser's console. Ensure your browser is configured to display all logs (verbose).

```js
const configuration = {
  mode: "dummy",
};

const oneSdk = await OneSdk(configuration);
```

### Initialize the FrankieOne object

Create an instance of FrankieOne using the configuration object you created.

The `OneSDK` function returns a promise, which can be `await`-ed in Javascript ES2017's `await`.

```js
const oneSdk = await OneSdk(configuration);
```

Otherwise you can use Javascript's Promise API.

```js
OneSdk(configuration).then((oneSdk) => {
  // The oneSDK instance is ready to use...
});
```

## Step 3: Verify identity document details via OCR

Use the OCR Component provided by OneSDK to verify identity document details.

You may skip this step if OCR is not required according to your workflow.

## Create the OCR Component

Create an instance of the OCR Component by passing `'ocr'` to the type in `component(type)` method of the FrankieOne object.

```js
const ocr = oneSdk.component("ocr");
```

## Handle image capture

Listen to the input_required event to present your image capture interface to the user. The handler method that you provide should accept the following arguments:

| Argument name |                                                                                                                              Description                                                                                                                               |
| :-----------: | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
|   inputInfo   | An object that describes the type of document required and any additional specifications for the document.<br /><br />For example, if the front side of a drivers license has already been captured, this object will specify that the back side needs to be captured. |
|    status     |                                                                                                      An object that contains the statuses of any previous calls.                                                                                                       |
|   callback    |                                                        A callback function that accepts the captured image data as an instance of the [File interface](https://developer.mozilla.org/en-US/docs/Web/API/File).                                                         |

### Valid statuses

| Value                                  | Description                                                                                                            |
| -------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| AWAITING_DOCUMENT_OCR                  | OneSDK has captured a document but ocr process is yet to run. Default status if we get errors or user abandons process |
| AWAITING_DOCUMENT_UPLOAD_FRONT         | Capture of front needed                                                                                                |
| AWAITING_DOCUMENT_UPLOAD_BACK          | Capture of back needed                                                                                                 |
| COMPLETE_OCR                           | OCR results are available                                                                                              |
| AWAITING_DOCUMENT_UPLOAD_FAILED_OCR    | Capture successful, but an error happened during upload, potentially due to a bad scan                                 |
| AWAITING_DOCUMENT_UPLOAD_INVALID_TYPE  | Document type of the scan seems to be invalid                                                                          |
| DOCUMENT_INVALID_EXCEEDED_SIZE_LIMIT   | File size exceeds the limits supported by third party OCR provider                                                     |
| DOCUMENT_INVALID_INCORRECT_FILE_FORMAT | File format is not accepted by the third party OCR provider                                                            |
| AWAITING_OCR_RESULTS_PROVIDER_OFFLINE  | OneSDK has captured a document but there was a communication issue uploading the document or retrieving the result     |

```js
ocr.on("input_required", async (inputInfo, status, provideFile) => {
  const { documentType, side } = inputInfo;
  // documentType will initially be null, until the type is inferred from the first provided scan
  if (documentType === "PASSPORT") {
    // present UI to capture a passport image
  } else if (documentType === "DRIVERS_LICENCE") {
    // check which side of the drivers licence is required
    if (side === "front") {
      // present UI to capture the licence's front side
    } else if (side === "back") {
      // present UI to capture the licence's back side
    }
  } else {
    // present UI to capture any type of identity document
  }

  // Your use interface you should capture an image and provide it to OneSDK as a File object.
  // https://developer.mozilla.org/en-US/docs/Web/API/File
  //
  // For example, your interface may use the Image Capture API to obtain the image data, though use of this API is not required.
  // See https://developer.mozilla.org/en-US/docs/Web/API/MediaStream_Image_Capture_API
  // const blob = // ...
  // provideFile(blob)

  // example of capturing a blob image from browser
  navigator.mediaDevices.getUserMedia({ video: true }).then((mediaStream) => {
    // Do something with the stream.
    const track = mediaStream.getVideoTracks()[0];
    let imageCapture = new ImageCapture(track);
    imageCapture.takePhoto().then((file) => provideFile(file));
  });
});
```

## Obtain results

Listen to the `results` event to get notified when the detected document details are available.

```js
ocr.on("results", ({ document }) => {
  // Present the details of the document that were detected from the uploaded image or images.
  // Decide whether to proceed to the next stage of the onboarding process
  // depending on whether document verification was successful.
  if (document) {
  } else {
  }
});
```

## Handle errors

Listen to the `error` event to handle any system errors.

```js
ocr.on("error", (error) => {
  console.error(error.message);
});
```

## Start the document capture flow

Finally, start the document capture flow. This will immediately trigger the `input_required` event.

```js
ocr.start();
```

## Step 5: Perform KYC verification

Use the FrankieOne API to perform KYC verification using the identity documents submitted by the individual so far.

```sh
curl https://api.demo.frankiefinancial.io/compliance/v1.2/entity/ENTITY_ID/verify/profile/full \
  -X POST \
  -H 'api_key: YOUR_API_KEY' \
  -H 'X-Frankie-CustomerID: YOUR_CUSTOMER_ID' \
  -H 'X-Frankie-CustomerChildID: YOUR_CUSTOMER_CHILD_ID' \
  -H 'Content-Type: application/json' \
  -d '{
    "entity": {
      "entityId": "ENTITY_ID",
    }
  }';
```

Your system will receive a webhook describing how to retreive the verification results for the entity.

> If the entity profile used to verify the entity requires that biometrics are submitted, then the recommended action will be `FAIL`. However, you can use the details of the identity document verification results to determine whether onboarding should proceed to biometrics or prevent the user from continuing..

## Step 6: Verify biometrics

Use the Biometrics Component provided by OneSDK to verify the user's facial image.

You may skip this step if biometrics is not required according to the current workflow for the entity.

## Create the container element for the Biometrics Component

Create a DOM container element on your onboarding web page where you want the Component to be rendered. Make sure to give the container element a descriptive id.

For example:

```html
<div id="biometrics-container"></div>
```

If you are using JavaScript frameworks such as Vue or React, make sure that you use references instead of selectors and that you don't re-render the DOM element.

## Create the Biometrics Component

Create an instance of the Biometrics Component by passing `'biometrics'` to the `component(type, options?)` method of the FrankieOne object.

```js
const biometrics = oneSdk.component("biometrics");
```

## Obtain results

Listen to the `detection_complete` event to get notified when biometrics detection phase has been completed.

```js
biometrics.on("detection_complete", () => {});
```

Listen to the `results` event to get notified when biometrics results are available.

```js
biometrics.on("results", ({ checkStatus }) => {
  // Here you have access to the status of the check, e.g. COMPLETE
  console.log({ checkStatus });
});
```

## Handle errors

Listen to the `vendor_sdk_failed_loading` event to handle any vendor SDK loading errors.

```js
biometrics.on("vendor_sdk_failed_loading", ({ vendor, errorObject }) => {
  console.error(errorObject);
});
```

Listen to the session_data_failed_loading event to handle any errors related to loading of vendor session data.

```js
biometrics.on("session_data_failed_loading", ({ code, message }) => {
  console.error(message);
});
```

Listen to the `detection_failed` event to handle any retry attempts if problems occur during a detection step. Retrying would involve mounting the component anew.

```js
biometrics.on("detection_failed", (error) => {
  console.error(error);

  if (retriesAttempted < 3) {
    biometrics.mount("#biometrics-container");
  }
});
```

Listen to the `error` event to handle any system errors.

```js
biometrics.on("error", ({ message, payload }) => {
  console.error(message);
});
```

## Start the biometrics flow

Finally, start the document capture flow by mounting the component in your container element. This will begin to mount the user interface to the DOM, which can take a few seconds. During this time you can optionally display your own loading state

```js
biometrics.mount("#biometrics-container");
```

Listen to the `ready` event to know when the biometrics capture interface is ready for use.

```js
biometrics.on("ready", () => {
  // If you provided your own loading state it can now be hidden.
  loadingElement.remove();
});
```

## Other useful events

Listen to the `vendor_sdk_loaded` event to know when the vendor SDK has loaded successfully.

```js
biometrics.on("vendor_sdk_loaded", ({ vendor }) => {
  console.debug(`Successfully loaded ${vendor} SDK`);
});
```

Listen to the `session_data_generated` event to know when the session data was created successfully.

```js
biometrics.on("session_data_generated", ({ session }) => {});
```

Listen to the `session_closed` event to know when the vendor SDK session was closed.

```js
biometrics.on("session_closed", () => {});
```

## Step 7: Submit information

Access the Individual object to represent the person being onboarded.

```js
const individual = oneSdk.individual();
```

Submit all information, make sure that consent has been added and initiate the verification process.

```js
individual.addConsent();
individual.submit({
  verify: true,
});
```
