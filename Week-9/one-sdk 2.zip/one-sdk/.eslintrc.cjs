// typescript related rules should go under the /**/*.ts override section. Add them to the variable `typescriptOnlyRules`
const NON_TYPESCRIPT_GENERAL_RULES = {
  semi: ['error', 'always'],
  'check-file/filename-naming-convention': [
    'warn' /* error */,
    {
      // regular JS / TS files should be camelCase
      '**/*.{js,ts}': 'CAMEL_CASE',
      // JSX / React files should be PascalCase
      '**/*.{jsx,tsx}': 'PASCAL_CASE',
      // class files should be PascalCase
      '**/*.class.{js,ts}': 'PASCAL_CASE',
      // types files should be camelCase
      '**/*.types.{js,ts}': 'CAMEL_CASE',
    },
    {
      ignoreMiddleExtensions: true,
    },
  ],

  // 'import/no-restricted-paths': [
  //   'error',
  //   {
  //     zones: [{
  //       target: './apps/playground/src/**/*',
  //       from: './modules/**/*',
  //       message: 'The playground cannot import directly from OneSDK internal source code. Please update its public api (modules/index.ts and modules/types.ts) and import from @frankieone/one-sdk instead.',
  //       except: ['./modules/{index,types}.ts'],
  //     }],
  //   },
  // ],'
  'no-multiple-empty-lines': ['warn' /* error */, { max: 2, maxBOF: 0, maxEOF: 0 }],
  'unused-imports/no-unused-imports': 'warn' /* error */,
  'max-len': ['warn', { code: 120, comments: 200 }],
  'max-depth': ['warn' /* error */, 2],
  'multiline-ternary': ['error', 'always-multiline'],
  'no-nested-ternary': 'warn' /* error */,
  'react-refresh/only-export-components': ['warn', { allowConstantExport: true }],
  'comma-dangle': ['warn' /* error */, 'always-multiline'],
  'max-params': ['warn', 2],
  'import/no-unresolved': 'error',
  'import/no-default-export': 'error',
  'import/order': [
    'warn' /* error */,
    {
      groups: ['builtin', 'external', 'internal', 'parent', 'sibling', 'index', 'type'],
      pathGroups: [
        // I tried doing:
        // {
        //   pattern: '@**',
        //   group: 'internal',
        // }
        // but that didn't work the same as the explicit patterns below
        {
          pattern: '@config',
          group: 'internal',
        },
        {
          pattern: '@frankieone/one-sdk',
          group: 'internal',
        },
        {
          pattern: '@package-meta',
          group: 'internal',
        },
        {
          pattern: '@types',
          group: 'internal',
        },
        {
          pattern: '@module/**',
          group: 'internal',
        },
        {
          pattern: '@static/**',
          group: 'internal',
        },
        {
          pattern: '@tests/**',
          group: 'internal',
        },
      ],
      // For some reason, without this line, external (not builtin) packages
      // like 'axios' will not be treated as distinct from internal ones.
      pathGroupsExcludedImportTypes: ['builtin'],
      alphabetize: {
        order: 'asc',
        caseInsensitive: true,
      },
      'newlines-between': 'always', // For easier visual distinguishing
    },
  ],
  'no-debugger': 'error',
  'no-console': ['error', { allow: ['debug', 'group', 'groupEnd'] }],
  // coflicting with some other settings I couldn't identify
  'prettier/prettier': 'off',
};

// Rules that should apply to typescript should be added here. This is important because the parser is only configure to interpret typescript in .ts and .tsx files
const TYPESCRIPT_ONLY_RULES = {
  '@typescript-eslint/consistent-type-exports': 'warn' /* error */,
  '@typescript-eslint/switch-exhaustiveness-check': 'warn' /* error */, // doesn't seem to work
  '@typescript-eslint/member-delimiter-style': [
    'warn' /* error */,
    {
      multiline: {
        delimiter: 'semi',
      },
    },
  ],
  '@typescript-eslint/no-unused-vars': [
    'warn' /* error */,
    {
      ignoreRestSiblings: true,
      argsIgnorePattern: '^_',
      args: 'after-used',
    },
  ],
  '@typescript-eslint/no-explicit-any': 'error',
  '@typescript-eslint/consistent-type-assertions': ['warn', { assertionStyle: 'as' }],
  '@typescript-eslint/consistent-type-imports': [
    'warn' /* error */,
    {
      disallowTypeAnnotations: false,
    },
  ],
};

module.exports = {
  root: true,
  env: { browser: true, es2020: true },
  extends: ['eslint:recommended', 'plugin:import/typescript'],
  parser: '@typescript-eslint/parser',
  plugins: ['import', 'react-refresh', '@typescript-eslint', 'unused-imports', 'check-file'],
  settings: {
    'import/resolver': {
      typescript: {
        project: '.',
      },
    },
    parserOptions: {
      project: ['./tsconfig.json'],
    },
  },
  ignorePatterns: [
    'modules/common/shared/**/*',
    '**/dist/**/*',
    '/*.js',
    '/*.mjs',
    '/*.cjs',
    '/*.json',
    'vite.config.js',
    'nolint_*',
    '.eslintrc.cjs',
  ],
  rules: NON_TYPESCRIPT_GENERAL_RULES,
  overrides: [
    {
      files: ['**/*.ts', '**/*.tsx'],
      extends: ['plugin:@typescript-eslint/recommended'],
      parserOptions: {
        project: ['./tsconfig.json'], // Specify it only for TypeScript files
      },
      rules: TYPESCRIPT_ONLY_RULES,
    },
    {
      files: ['**/*.d.ts'],
      extends: ['plugin:@typescript-eslint/recommended'],
      parserOptions: {
        project: ['./tsconfig.json'], // Specify it only for TypeScript files
      },
      rules: {
        '@typescript-eslint/consistent-type-imports': 'off',
      },
    },
    {
      files: ['**/apps/*/*.ts', '**/apps/*/*.tsx'],
      extends: ['plugin:react-hooks/recommended'],
      parserOptions: {
        project: ['./tsconfig.json'], // Specify it only for TypeScript files
      },
      rules: TYPESCRIPT_ONLY_RULES,
    },
    {
      files: ['*.types.ts'],
      plugins: ['@typescript-eslint'],
      parserOptions: {
        project: ['./tsconfig.json'], // Specify it only for TypeScript files
      },
      rules: {
        '@typescript-eslint/no-restricted-imports': [
          'error',
          {
            patterns: [
              {
                group: ['*'],
                message: 'Please only import types from files suffixed with .types',
                allowTypeImports: true,
              },
            ],
          },
        ],
      },
    },
    {
      files: ['**/*.tsx', 'apps/**/*', '**/index.ts', '**/*.config.*'],
      rules: {
        'import/no-default-export': 'off',
      },
    },
    {
      files: ['**/*.tsx'],
      rules: {
        '@typescript-eslint/consistent-type-assertions': ['warn', { assertionStyle: 'as' }],
      },
    },
    {
      files: ['**/tests/**/*.ts'],
      rules: {
        '@typescript-eslint/no-var-requires': 'off',
        '@typescript-eslint/ban-ts-ignore': 'off',
        '@typescript-eslint/ban-ts-comment': 'off',
        '@typescript-eslint/consistent-type-assertions': 'off',
        'check-file/filename-naming-convention': 'off',
        'max-params': 'off',
      },
    },
    {
      // declaration files use no rule, since modules can be named anything
      files: ['**/*.d.ts'],
      rules: {
        'check-file/filename-naming-convention': 'off',
      },
    },
    {
      files: ['**/apps/**/*'],
      rules: {
        'no-console': 'off',
        'no-debugger': 'off',
      },
    },
  ],
};
