import * as fs from 'fs';

import { pathsToModuleNameMapper } from 'ts-jest';

const tsconfig = JSON.parse(fs.readFileSync('./tsconfig.base.json', 'utf-8'));
const pathMapping = pathsToModuleNameMapper(tsconfig.compilerOptions.paths, { prefix: '<rootDir>/' });
/** @type {import('@jest/types').Config.InitialOptions} */
export default {
  preset: 'ts-jest',
  globals: {
    'ts-jest': {
      useESM: true,
      tsconfig: './tsconfig.tests.json',
      // ...replaceImportMetaEnv(),
    }
  },
  transform: {
    '^.+\\.ts?$': 'ts-jest',
  },
  setupFiles: ['<rootDir>/tests/jest.setup.ts'],
  setupFilesAfterEnv: ['<rootDir>/tests/jest.env-setup.ts'],
  extensionsToTreatAsEsm: ['.ts'],
  testEnvironment: 'jsdom',
  testMatch: ['<rootDir>/tests/**/*.spec.ts'],
  passWithNoTests: true,
  modulePaths: [tsconfig.compilerOptions.baseUrl],
  modulePathIgnorePatterns: ['<rootDir>/dist', '<rootDir>/node_modules', '<rootDir>/apps'],
  moduleNameMapper: {
    // Mocking third party module since it exports a es module, which jest doesn't handle well,
    // specially when using typescript and having a package.json of type "module"
    uuid: '<rootDir>/tests/mocks/uuid',
    ...pathMapping,
  },
  collectCoverage: true,
  coverageReporters: ['json-summary', 'text-summary', 'html'],
  collectCoverageFrom: [
    'modules/**/*.ts',
    '!modules/common/shared/**',
    '!modules/**/types/**/*.ts',
    '!modules/**/*.types.ts'
  ],
  coverageProvider: 'v8'
}
