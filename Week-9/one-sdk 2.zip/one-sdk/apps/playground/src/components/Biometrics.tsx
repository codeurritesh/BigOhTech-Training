import { useEffect, useState } from 'react';

import type { OneSdkContext } from '@frankieone/one-sdk';
import { wildcardEventLogger } from '@frankieone/one-sdk';

import type { CSSProperties } from 'react';

export const BiometricsIDV = ({ oneSdk }: { oneSdk: OneSdkContext }) => {
  const [mounted, setMounted] = useState(false);
  const biometrics = oneSdk.component('biometrics');
  const [toggled, setToggled] = useState(false);

  const startIDV = () => {
    setToggled(true);
    biometrics.mount('#biometrics-el');
    setMounted(true);
  };

  useEffect(() => {
    /**
     * This component will open the camera in full screen and close it once the event "detection_complete" is emitted
     */
    const detectionHandler = () => {
      setToggled(false);
    };
    biometrics.on('*', wildcardEventLogger);
    biometrics.on('detection_complete', detectionHandler);

    return () => biometrics.off();
  });
  const containerStyle: CSSProperties = {
    width: '100%',
    height: toggled ? '100%' : 'auto',
    top: '0',
    left: '0',
    position: toggled ? 'fixed' : null,
    margin: '0 auto',
  };
  return (
    <div style={containerStyle}>
      {!mounted &&
        <button onClick={startIDV}>Start Identity Verification</button>}
      <div id="biometrics-el"></div>
    </div>
  );
};
