#!/bin/bash
version=$1

if [ $(git tag -l "$version") ]; then
  # tag already exists. fail pipeline.
  exit 1
else
  # tag doesn't exist, create and push tag.
  git tag -am "Tagging for release ${BITBUCKET_BUILD_NUMBER}" $version
  git push origin $version
fi

echo $version