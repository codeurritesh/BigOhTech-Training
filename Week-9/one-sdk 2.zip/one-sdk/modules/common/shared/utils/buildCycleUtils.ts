declare let process: { env: any };
export function webpackChainEnableShadowDOM(config) {
  const configs = [
    config.module.rule('vue').use('vue-loader'),
  ];

  const ruleSets = ['css', 'postcss', 'sass', 'scss', 'stylus', 'less'];
  const ruleNames = ['vue-modules', 'vue', 'normal-modules', 'normal'];

  const hasLoader = (rule, loader) => rule.uses.store.has(loader);
  ruleSets.forEach((ruleSet) => {
    if (config.module.rules.store.has(ruleSet)) {
      ruleNames.forEach((rName) => {
        if (config.module.rule(ruleSet).oneOfs.store.has(rName)) {
          const rule = config.module.rule(ruleSet).oneOf(rName);
          if (hasLoader(rule, 'vue-style-loader')) {
            configs.push(config.module.rule(ruleSet).oneOf(rName).use('vue-style-loader'));
          }
        }
      });
    }
  });
  if (!process.env.BUILD_MODE) {
    process.env.BUILD_MODE = config.store.get('mode');
  }
  configs.forEach((c) => c.tap((options) => {
    options.shadowMode = true;
    return options;
  }));
}
