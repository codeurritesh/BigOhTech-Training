import { CommonEvents, EventHub, EventsDictionary } from "@module/common";
import { FrankieApiClient } from "@module/frankie-client";
import { DummyFrankieApiClient } from "@module/frankie-client/DummyFrankieApiClient";
import { SessionContext } from "@module/session/SessionContext";
import { jwtWithEntityId, jwtWithReference } from "../testUtils/tokens";
import { mockEventHub } from "./EventHub";

type ClientType = "dummy" | "real";
type Options<Events extends EventsDictionary = CommonEvents, Client extends ClientType = ClientType> = {
  sessionType?: "reference" | "entityId";
  globalEventHub?: Partial<EventHub<Events>>;
  clientType?: Client;
};
type FrankieClientMock<Events extends EventsDictionary, Client extends ClientType> = {
  frankieClient: jest.Mocked<Client extends "dummy" ? DummyFrankieApiClient : FrankieApiClient>;
  globalEventHub: EventHub<Events>;
};

export function mockFrankieClient<Events extends EventsDictionary = CommonEvents>(
  o?: Options<Events, "dummy">
): FrankieClientMock<Events, "dummy">;

export function mockFrankieClient<Events extends EventsDictionary = CommonEvents>(
  o?: Options<Events, "real">
): FrankieClientMock<Events, "real">;

export function mockFrankieClient<Events extends EventsDictionary = CommonEvents>(
  o: Options = {}
): FrankieClientMock<Events, ClientType> {
  const { clientType = "dummy", sessionType = "reference" } = o;
  const globalEventHub = Object.assign(mockEventHub<Events>(), o.globalEventHub);

  const Constructor = clientType === "dummy" ? DummyFrankieApiClient : FrankieApiClient;
  const frankieClient = new Constructor({ globalEventHub });

  jest.spyOn(frankieClient, "post");
  jest.spyOn(frankieClient, "get");
  jest.spyOn(frankieClient, "put");
  jest.spyOn(frankieClient, "delete");
  jest.spyOn(frankieClient, "redirect");

  const mockedClient = <jest.Mocked<FrankieApiClient>>frankieClient;

  if (sessionType) {
    frankieClient.session = new SessionContext(sessionType === "entityId" ? jwtWithEntityId : jwtWithReference);
  }

  return { frankieClient: mockedClient, globalEventHub };
}
