import { mkEventHub } from "@module/common";
import { DummyFrankieApiClient } from "@module/frankie-client";
import { OCRClient, OCRStatus } from "@module/frankie-client/clients/OCRClient";
import { dateMatcher, mockedUuidMatcher } from "../../testUtils/patterns";
import { resolveSimplifiedMockOptions } from "@module/frankie-client/mocks/options/simplified/resolveSimplifiedMockOptions";
import { applyMocks } from "@module/frankie-client/mocks/applyMocks";
import { MockOptions } from "@module/frankie-client/mocks/options/MockOptions.type";

describe("Dummy mode:: simplifyMockOptions. No previous OCR Document, creation succeeds, update succeeds", () => {
  test("detects passport, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      ocrFlow: {
        detectedType: "PASSPORT",
        statusResults: [OCRStatus.COMPLETE],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      ocrRequests: {
        detectedType: "PASSPORT",
        postResponsePayload: {
          status: OCRStatus.COMPLETE,
          ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
        },
        updateResponsePayloads: [],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);
    const client = new OCRClient(dummyClient);
    const { documentStatus, ocrDocument } = await client.attachNewOCRDocument(new File([""], "filename.jpeg"));

    expect(documentStatus).toBe(OCRStatus.COMPLETE);
    expect(ocrDocument).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });
  });
  test("detects drivers licence, status is WAITING_BACK, second scan submission succeeds, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      ocrFlow: {
        detectedType: "DRIVERS_LICENCE",
        statusResults: [OCRStatus.WAITING_BACK, OCRStatus.COMPLETE],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      ocrRequests: {
        detectedType: "DRIVERS_LICENCE",
        postResponsePayload: {
          status: OCRStatus.WAITING_BACK,
          ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
        },
        updateResponsePayloads: [
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);
    const client = new OCRClient(dummyClient);
    const { documentStatus: ds1, ocrDocument: od1 } = await client.attachNewOCRDocument(
      new File([""], "filename.jpeg")
    );

    expect(ds1).toBe(OCRStatus.WAITING_BACK);
    expect(od1).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.WAITING_BACK,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });

    const { documentStatus: ds2, ocrDocument: od2 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds2).toBe(OCRStatus.COMPLETE);
    expect(od2).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
        expect.objectContaining({
          side: "B",
        }),
      ],
    });
  });
});
describe("Dummy mode:: simplifyMockOptions. No previous OCR Document, creation succeeds, update fails then succeeds", () => {
  test("detects drivers licence, status is WAITING_BACK, scan submission fails 1x with status INVALID_TYPE, third scan submission succeeds, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      ocrFlow: {
        detectedType: "DRIVERS_LICENCE",
        statusResults: [OCRStatus.WAITING_BACK, OCRStatus.DOCUMENTS_INVALID, OCRStatus.COMPLETE],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      ocrRequests: {
        detectedType: "DRIVERS_LICENCE",
        postResponsePayload: {
          status: OCRStatus.WAITING_BACK,
          ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
        },
        updateResponsePayloads: [
          {
            status: OCRStatus.DOCUMENTS_INVALID,
            ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
          },
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);
    const client = new OCRClient(dummyClient);
    const { documentStatus: ds1, ocrDocument: od1 } = await client.attachNewOCRDocument(
      new File([""], "filename.jpeg")
    );

    expect(ds1).toBe(OCRStatus.WAITING_BACK);
    expect(od1).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.WAITING_BACK,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });

    const { documentStatus: ds2, ocrDocument: od2 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds2).toBe(OCRStatus.DOCUMENTS_INVALID);
    expect(od2).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.DOCUMENTS_INVALID,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });
    const { documentStatus: ds3, ocrDocument: od3 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds3).toBe(OCRStatus.COMPLETE);
    expect(od3).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
        expect.objectContaining({
          side: "B",
        }),
      ],
    });
  });
  test("detects drivers licence, status is WAITING_BACK, scan submission fails 2x with status INVALID_TYPE and FILE_SIZE, third scan submission succeeds, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      ocrFlow: {
        detectedType: "DRIVERS_LICENCE",
        statusResults: [
          OCRStatus.WAITING_BACK,
          OCRStatus.DOCUMENTS_INVALID,
          OCRStatus.FAILED_FILE_SIZE,
          OCRStatus.COMPLETE,
        ],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      ocrRequests: {
        detectedType: "DRIVERS_LICENCE",
        postResponsePayload: {
          status: OCRStatus.WAITING_BACK,
          ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
        },
        updateResponsePayloads: [
          {
            status: OCRStatus.DOCUMENTS_INVALID,
            ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
          },
          {
            status: OCRStatus.FAILED_FILE_SIZE,
            ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
          },
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);
    const client = new OCRClient(dummyClient);
    const { documentStatus: ds1, ocrDocument: od1 } = await client.attachNewOCRDocument(
      new File([""], "filename.jpeg")
    );

    expect(ds1).toBe(OCRStatus.WAITING_BACK);
    expect(od1).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.WAITING_BACK,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });

    const { documentStatus: ds2, ocrDocument: od2 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds2).toBe(OCRStatus.DOCUMENTS_INVALID);
    expect(od2).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.DOCUMENTS_INVALID,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });

    const { documentStatus: ds3, ocrDocument: od3 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds3).toBe(OCRStatus.FAILED_FILE_SIZE);
    expect(od3).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.FAILED_FILE_SIZE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });
    const { documentStatus: ds4, ocrDocument: od4 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds4).toBe(OCRStatus.COMPLETE);
    expect(od4).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
        expect.objectContaining({
          side: "B",
        }),
      ],
    });
  });
});
describe("Dummy mode:: simplifyMockOptions. No previous OCR Document, creation fails then succeeds, update fails then succeeds", () => {
  test("fails 1x detecting id type with status is INVALID_TYPE, second scan submission succeeds, detects drivers licence, status is WAITING_BACK, fails 1x with status FAILED_FILE_SIZE, fourth scan submission succeeds, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      ocrFlow: {
        detectedType: "DRIVERS_LICENCE",
        statusResults: [
          OCRStatus.DOCUMENTS_INVALID,
          OCRStatus.WAITING_BACK,
          OCRStatus.FAILED_FILE_SIZE,
          OCRStatus.COMPLETE,
        ],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      ocrRequests: {
        detectedType: "DRIVERS_LICENCE",
        postResponsePayload: {
          status: OCRStatus.DOCUMENTS_INVALID,
          ocrDocument: expect.objectContaining({ scans: [] }),
        },
        updateResponsePayloads: [
          {
            status: OCRStatus.WAITING_BACK,
            ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
          },
          {
            status: OCRStatus.FAILED_FILE_SIZE,
            ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
          },
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);
    const client = new OCRClient(dummyClient);

    const { documentStatus: ds1, ocrDocument: od1 } = await client.attachNewOCRDocument(
      new File([""], "filename.jpeg")
    );

    expect(ds1).toBe(OCRStatus.DOCUMENTS_INVALID);
    expect(od1).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.DOCUMENTS_INVALID,
        runDate: dateMatcher,
      },
      scans: [],
    });

    const { documentStatus: ds2, ocrDocument: od2 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds2).toBe(OCRStatus.WAITING_BACK);
    expect(od2).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.WAITING_BACK,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });

    const { documentStatus: ds3, ocrDocument: od3 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds3).toBe(OCRStatus.FAILED_FILE_SIZE);
    expect(od3).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.FAILED_FILE_SIZE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });

    const { documentStatus: ds4, ocrDocument: od4 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds4).toBe(OCRStatus.COMPLETE);
    expect(od4).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
        expect.objectContaining({
          side: "B",
        }),
      ],
    });
  });
  test("fails 1x detecting id type with status is INVALID_TYPE, third scan submission succeeds, detects drivers licence, status is WAITING_FRONT, fails 1x with status FAILED_FILE_SIZE, fourth scan submission succeeds, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      ocrFlow: {
        detectedType: "DRIVERS_LICENCE",
        statusResults: [
          OCRStatus.DOCUMENTS_INVALID,
          OCRStatus.WAITING_BACK,
          OCRStatus.FAILED_FILE_SIZE,
          OCRStatus.COMPLETE,
        ],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      ocrRequests: {
        detectedType: "DRIVERS_LICENCE",
        postResponsePayload: {
          status: OCRStatus.DOCUMENTS_INVALID,
          ocrDocument: expect.objectContaining({ scans: [] }),
        },
        updateResponsePayloads: [
          {
            status: OCRStatus.WAITING_BACK,
            ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
          },
          {
            status: OCRStatus.FAILED_FILE_SIZE,
            ocrDocument: expect.objectContaining({ scans: [expect.objectContaining({ side: "F" })] }),
          },
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);
    const client = new OCRClient(dummyClient);

    const { documentStatus: ds1, ocrDocument: od1 } = await client.attachNewOCRDocument(
      new File([""], "filename.jpeg")
    );

    expect(ds1).toBe(OCRStatus.DOCUMENTS_INVALID);
    expect(od1).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.DOCUMENTS_INVALID,
        runDate: dateMatcher,
      },
      scans: [],
    });

    const { documentStatus: ds2, ocrDocument: od2 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds2).toBe(OCRStatus.WAITING_BACK);
    expect(od2).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.WAITING_BACK,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });

    const { documentStatus: ds3, ocrDocument: od3 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds3).toBe(OCRStatus.FAILED_FILE_SIZE);
    expect(od3).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.FAILED_FILE_SIZE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });

    const { documentStatus: ds4, ocrDocument: od4 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds4).toBe(OCRStatus.COMPLETE);
    expect(od4).toMatchObject({
      documentId: mockedUuidMatcher,
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
        expect.objectContaining({
          side: "B",
        }),
      ],
    });
  });
});

describe("Dummy mode:: simplifyMockOptions. HAS previous COMPLETED OCR Document", () => {
  test("has passport with status COMPLETE", () => {
    const mockOptions = resolveSimplifiedMockOptions({
      preloadedIndividual: {
        documents: [{ idType: "PASSPORT", ocrResult: { status: OCRStatus.COMPLETE } }],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      preloadedIndividual: {
        individual: expect.any(Object),
        documents: [
          {
            idType: "PASSPORT",
            ocrResult: { status: OCRStatus.COMPLETE },
            scans: [expect.objectContaining({ side: "F" })],
          },
        ],
      },
    });
  });
  test("has drivers licence status COMPLETE", () => {
    const mockOptions = resolveSimplifiedMockOptions({
      preloadedIndividual: {
        documents: [{ idType: "DRIVERS_LICENCE", ocrResult: { status: OCRStatus.COMPLETE } }],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      preloadedIndividual: {
        individual: expect.any(Object),
        documents: [
          {
            idType: "DRIVERS_LICENCE",
            ocrResult: { status: OCRStatus.COMPLETE },
            scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
          },
        ],
      },
    });
  });
});

describe("Dummy mode:: simplifyMockOptions. HAS previous INCOMPLETE OCR Document, update succeeds", () => {
  test("has passport with with status WAITING_OCR, submission succeeds, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      preloadedIndividual: {
        documents: [{ idType: "PASSPORT", ocrResult: { status: OCRStatus.WAITING_OCR_RUN }, scans: "F" }],
      },
      ocrFlow: {
        detectedType: "PASSPORT",
        statusResults: [OCRStatus.COMPLETE],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      preloadedIndividual: {
        individual: expect.any(Object),
        documents: [
          {
            idType: "PASSPORT",
            ocrResult: { status: OCRStatus.WAITING_OCR_RUN },
            scans: [expect.objectContaining({ side: "F" })],
          },
        ],
      },
      ocrRequests: {
        detectedType: "PASSPORT",
        postResponsePayload: null,
        updateResponsePayloads: [
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);

    const client = new OCRClient(dummyClient);
    const { documentStatus: ds1, ocrDocument: od1 } = await client.rerun("any-id");

    expect(ds1).toBe(OCRStatus.COMPLETE);
    expect(od1).toMatchObject({
      documentId: "any-id",
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });
  });
  test("has drivers licence with status WAITING_OCR, scan submission succeeds, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      preloadedIndividual: {
        documents: [{ idType: "DRIVERS_LICENCE", ocrResult: { status: OCRStatus.WAITING_OCR_RUN } }],
      },
      ocrFlow: {
        detectedType: "DRIVERS_LICENCE",
        statusResults: [OCRStatus.COMPLETE],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      preloadedIndividual: {
        individual: expect.any(Object),
        documents: [
          {
            idType: "DRIVERS_LICENCE",
            ocrResult: { status: OCRStatus.WAITING_OCR_RUN },
            scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
          },
        ],
      },
      ocrRequests: {
        detectedType: "DRIVERS_LICENCE",
        postResponsePayload: null,
        updateResponsePayloads: [
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);

    const client = new OCRClient(dummyClient);
    const { documentStatus: ds1, ocrDocument: od1 } = await client.rerun("any-id");

    expect(ds1).toBe(OCRStatus.COMPLETE);
    expect(od1).toMatchObject({
      documentId: "any-id",
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
    });
  });
  test("has drivers licence with status WAITING_BACK, scan submission succeeds, status is WAITING_BACK, then COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      preloadedIndividual: {
        documents: [{ idType: "DRIVERS_LICENCE", ocrResult: { status: OCRStatus.WAITING_OCR_RUN } }],
      },
      ocrFlow: {
        detectedType: "DRIVERS_LICENCE",
        statusResults: [OCRStatus.WAITING_BACK, OCRStatus.COMPLETE],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      preloadedIndividual: {
        individual: expect.any(Object),
        documents: [
          {
            idType: "DRIVERS_LICENCE",
            ocrResult: { status: OCRStatus.WAITING_OCR_RUN },
            scans: [expect.objectContaining({ side: "F" })],
          },
        ],
      },
      ocrRequests: {
        detectedType: "DRIVERS_LICENCE",
        postResponsePayload: null,
        updateResponsePayloads: [
          {
            status: OCRStatus.WAITING_BACK,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" })],
            }),
          },
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);

    const client = new OCRClient(dummyClient);
    const { documentStatus: ds1, ocrDocument: od1 } = await client.rerun("any-id");

    expect(ds1).toBe(OCRStatus.WAITING_BACK);
    expect(od1).toMatchObject({
      documentId: "any-id",
      ocrResult: {
        status: OCRStatus.WAITING_BACK,
        runDate: dateMatcher,
      },
      scans: [expect.objectContaining({ side: "F" })],
    });

    const { documentStatus: ds2, ocrDocument: od2 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds2).toBe(OCRStatus.COMPLETE);
    expect(od2).toMatchObject({
      documentId: "any-id",
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
    });
  });
});
describe("Dummy mode:: simplifyMockOptions. HAS previous INCOMPLETE OCR Document, update fails then succeeds", () => {
  test("has passport with with status WAITING_OCR, submission fails 1x with status INVALID_TYPE, second submission succeeds, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      preloadedIndividual: {
        documents: [{ idType: "PASSPORT", ocrResult: { status: OCRStatus.WAITING_OCR_RUN } }],
      },
      ocrFlow: {
        detectedType: "PASSPORT",
        statusResults: [OCRStatus.COMPLETE],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      preloadedIndividual: {
        individual: expect.any(Object),
        documents: [
          {
            idType: "PASSPORT",
            ocrResult: { status: OCRStatus.WAITING_OCR_RUN },
            scans: [expect.objectContaining({ side: "F" })],
          },
        ],
      },
      ocrRequests: {
        detectedType: "PASSPORT",
        postResponsePayload: null,
        updateResponsePayloads: [
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              scans: [expect.objectContaining({ side: "F" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);

    const client = new OCRClient(dummyClient);
    const { documentStatus: ds1, ocrDocument: od1 } = await client.rerun("any-id");

    expect(ds1).toBe(OCRStatus.COMPLETE);
    expect(od1).toMatchObject({
      documentId: "any-id",
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [
        expect.objectContaining({
          side: "F",
        }),
      ],
    });
  });
  test("has drivers licence with status WAITING_OCR, scan submission fails 1x with status INVALID_TYPE, seoncd submission succeeds, status is COMPLETE", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      preloadedIndividual: {
        documents: [{ idType: "DRIVERS_LICENCE", ocrResult: { status: OCRStatus.WAITING_OCR_RUN } }],
      },
      ocrFlow: {
        detectedType: "DRIVERS_LICENCE",
        statusResults: [OCRStatus.DOCUMENTS_INVALID, OCRStatus.COMPLETE],
      },
    });
    expect(mockOptions).toEqual(<MockOptions>{
      preloadedIndividual: {
        individual: expect.any(Object),
        documents: [
          {
            idType: "DRIVERS_LICENCE",
            ocrResult: { status: OCRStatus.WAITING_OCR_RUN },
            scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
          },
        ],
      },
      ocrRequests: {
        detectedType: "DRIVERS_LICENCE",
        postResponsePayload: null,
        updateResponsePayloads: [
          {
            status: OCRStatus.DOCUMENTS_INVALID,
            ocrDocument: expect.objectContaining({
              idType: "DRIVERS_LICENCE",
              scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
            }),
          },
          {
            status: OCRStatus.COMPLETE,
            ocrDocument: expect.objectContaining({
              idType: "DRIVERS_LICENCE",
              scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
            }),
          },
        ],
      },
    });

    const dummyClient = new DummyFrankieApiClient({
      globalEventHub: mkEventHub(),
    });
    applyMocks(dummyClient, mockOptions);

    const client = new OCRClient(dummyClient);
    const { documentStatus: ds1, ocrDocument: od1 } = await client.rerun("any-id");

    expect(ds1).toBe(OCRStatus.DOCUMENTS_INVALID);
    expect(od1).toMatchObject({
      documentId: "any-id",
      ocrResult: {
        status: OCRStatus.DOCUMENTS_INVALID,
        runDate: dateMatcher,
      },
      scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
    });

    const { documentStatus: ds2, ocrDocument: od2 } = await client.updateOCRDocument(
      new File([""], "filename.jpeg"),
      od1.documentId
    );

    expect(ds2).toBe(OCRStatus.COMPLETE);
    expect(od2).toMatchObject({
      documentId: "any-id",
      ocrResult: {
        status: OCRStatus.COMPLETE,
        runDate: dateMatcher,
      },
      scans: [expect.objectContaining({ side: "F" }), expect.objectContaining({ side: "B" })],
    });
  });
  test("Using ocrResult object instead of simply status in the ocrFlow.statusResults", async () => {
    const mockOptions = resolveSimplifiedMockOptions({
      preloadedIndividual: false,
      ocrFlow: {
        detectedType: "DRIVERS_LICENCE",
        statusResults: [
          { ocrDocument: { country: "BRA" }, ocrResult: { firstName: "thename" }, status: OCRStatus.WAITING_BACK },
          OCRStatus.COMPLETE,
        ],
      },
    });
    expect(mockOptions).toEqual(
      expect.objectContaining(<MockOptions>{
        ocrRequests: {
          detectedType: "DRIVERS_LICENCE",
          postResponsePayload: {
            status: OCRStatus.WAITING_BACK,
            ocrDocument: expect.objectContaining({
              idType: "DRIVERS_LICENCE",
              country: "BRA",
              ocrResult: { firstName: "thename" },
              scans: expect.arrayContaining([expect.objectContaining({ side: "F" })]),
            }),
          },
          updateResponsePayloads: [
            {
              status: OCRStatus.COMPLETE,
              ocrDocument: expect.objectContaining({
                idType: "DRIVERS_LICENCE",
                country: "BRA",
                ocrResult: { firstName: "thename" },
                scans: expect.arrayContaining([
                  expect.objectContaining({ side: "F" }),
                  expect.objectContaining({ side: "B" }),
                ]),
              }),
            },
          ],
        },
      })
    );
  });
});
