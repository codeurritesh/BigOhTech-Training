import { base64ToString, stringToBase64 } from "@module/common";
import { hexToBytes } from "convert-hex";

describe("base64 utilities", () => {
  test("stringToBase64", () => {
    expect(stringToBase64("test string")).toBe("dGVzdCBzdHJpbmc=");
  });
  test("base64ToString", () => {
    expect(base64ToString("dGVzdCBzdHJpbmc=")).toBe("test string");
  });
  test("hexToBytes", () => {
    expect(hexToBytes("7465737420737472696e67")).toEqual([116, 101, 115, 116, 32, 115, 116, 114, 105, 110, 103]);
  });
});
