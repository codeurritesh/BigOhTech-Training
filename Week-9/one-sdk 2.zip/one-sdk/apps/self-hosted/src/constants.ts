export const VERSION_PLACEHOLDER = '{{version}}';
export const CDN_URL = `https://assets.frankiefinancial.io/one-sdk/${VERSION_PLACEHOLDER}/oneSdk.umd.js`;
export const BFF_URL = 'https://backend.latest.frankiefinancial.io';
export const LOGGING = true;
