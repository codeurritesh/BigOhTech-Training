import type {
  FormIOInstance,
  FormIOOnboardingDataScheme,
} from '@module/form/vendors/formio/formioSdk';
import {
  assignIndividualDataToFormioSdk,
} from '@module/form/vendors/formio/transformers/assignIndividualDataToFormioSdk';
import { mockIndividualModule } from '@tests/mocks/IndividualModule';

describe('transformerIndividualModuleToFormio', () => {
  test('Complete individual data', () => {
    const individualModule = mockIndividualModule({
      accessState: {
        entityId: 'entityId',
        name: {
          givenName: 'firstName',
          familyName: 'lastName',
          middleName: 'middleName',
        },
        dateOfBirth: '2000-10-10',
        documents: [
          {
            documentId: 'documentId',
            idType: 'DRIVERS_LICENCE',
            country: 'issuingCountry',
            region: 'dl_region',
            idNumber: 'dl_idNumber',
            extraData: {
              document_number: 'dl_cardNumber',
            },
          },
        ],
        addresses: [
          {
            longForm: 'formatted_address',
            country: 'AUS',
          },
        ],
      },
    });
    const formio = {
      setSubmission: jest.fn(),
    } as unknown as FormIOInstance<FormIOOnboardingDataScheme>;

    assignIndividualDataToFormioSdk(individualModule, formio);

    expect(formio.setSubmission).toHaveBeenCalledWith(
      expect.objectContaining({
        data: {
          basicPiiForm: {
            data: {
              entityId: 'entityId',
              firstName: 'firstName',
              middleName: 'middleName',
              lastName: 'lastName',
              dateOfBirth: '2000-10-10',
            },
          },
          documents: [
            {
              genericDocument: {
                data: {
                  documentId: 'documentId',
                  idType: 'DRIVERS_LICENCE',
                  issuingCountry: 'issuingCountry',
                  dl_region: 'dl_region',
                  dl_idNumber: 'dl_idNumber',
                  dl_cardNumber: 'dl_cardNumber',
                },
              },
            },
          ],
          addressComponentForm: {
            data: {
              useManualAddress: false,
              residentialAddress: {
                formatted_address: 'formatted_address',
                address_components: [
                  {
                    long_name: 'Australia',
                    short_name: 'AU',
                    types: ['country'],
                  },
                ],
              },
            },
          },
        } as FormIOOnboardingDataScheme,
      }),
    );
  });
});
