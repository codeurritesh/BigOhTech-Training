import { TelemetryEvent } from "@module/common/shared/models/TelemetryEvent";
import { BaseClient } from "./BaseClient";

export class TelemetryEventsClient extends BaseClient {
  dispatch(payload: TelemetryEvent) {
    return this.frankie.post<void>(`/data/v2/events`, { ...payload });
  }
}
