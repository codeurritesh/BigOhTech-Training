import type { AnyFunction } from '@types';

/**
 *
 * @param testFunction
 * @param count
 * @returns
 */
export function delayTest<T>(testFunction: () => T, count = 1): Promise<T> {
  if (count === 0) return Promise.resolve(testFunction());
  else
    return new Promise<T>((ready, failed) => {
      setTimeout(() => {
        try {
          const returned = delayTest(testFunction, --count);
          ready(returned);
        } catch (e) {
          failed(e);
        }
      }, 0);
    });
}

type Callback = (n: string, c: AnyFunction) => unknown;
type CallbackMultiple = (n: string[] | string, c: AnyFunction) => unknown;
type EventHub = { on: Callback | CallbackMultiple; off: Callback };
export function waitFor(testFunction: AnyFunction | null, eventHub: EventHub, eventName: string): Promise<void> {
  return new Promise((done) => {
    const callback = (...args) => {
      return (
        Promise.resolve(testFunction?.(...args))
          // complete test
          .then(done)
          // stop listening  for the event to avoid memory leaks
          .finally(() => eventHub.off(eventName, callback))
      );
    };
    eventHub.on(eventName, callback);
  });
}
