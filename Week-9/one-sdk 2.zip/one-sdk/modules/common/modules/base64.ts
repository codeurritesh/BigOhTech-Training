import convertB64 from "base-64";
import convertUTF from "utf8";

export function stringToBase64(str: string): string {
  return convertB64.encode(convertUTF.encode(str));
}
export function base64ToString(b64: string): string {
  return convertUTF.decode(convertB64.decode(b64));
}
