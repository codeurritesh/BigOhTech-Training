/* This file exports tsconfig path aliases in different formats to be used by different bundlers */

import tsconfig from "../tsconfig.base.json";

/** 0) Extract paths as they are provided by tsconfig */
const paths = tsconfig.compilerOptions.paths;

type Paths = typeof paths;
type SingleMapping = Record<keyof Paths, string>;
type MappingEntry = [string, string];
type MappingList = MappingEntry[];

/**
 * 1) Extracted tsconfig paths as a list of tuples, where the first element is the path alias and the second is the path itself
 * TS Paths are allowed to be mapped to more than one file, as an array of patterns
 * pathsList simply contains the first option provided to simplify mapping it back for bundler configurations
 */
const pathsTuples: MappingList = Object.entries(paths).map(([k, vs]) => <[string, string]>[k, vs[0]]);
const removeWildcardFromTuple = ([k, v]: MappingEntry): MappingEntry => [k.replace("/*", ""), v.replace("/*", "")];
/**
 * 2) Same as pathsList, but without the wildcard symbol '*'
 * Some bundlers will use the mapping without a wildcard symbol '*' in the end, so remove "/*" endings from both key and value, when they exist
 */
const pathTuplesWithoutWildcard: MappingList = pathsTuples.map(removeWildcardFromTuple);
/**
 * 3) Same as withoutWildcard, but as a single mapping object
 */
const mappingWithoutWildcard = pathTuplesWithoutWildcard.reduce(
  (acc, [k, v]) => ({ ...acc, [k]: v }),
  <SingleMapping>{}
);

export { paths, pathTuplesWithoutWildcard, pathsTuples, mappingWithoutWildcard };
