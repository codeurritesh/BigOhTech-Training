import { Applicant } from "@module/common/shared/models/Applicant";
import { Document } from "@module/common/shared/models/Document";
import { Profile } from "@module/common/shared/models/Profile";
import { ApplicantClient } from "@module/frankie-client/clients/ApplicantClient";
import { mkSearch } from "@module/individual/actions/search";
import { EventHubMock } from "../mocks/EventHub";
import { mockFrankieClient } from "../mocks/FrankieClient";
import { mockReactiveStoreConstructor } from "../mocks/ReactiveStore";

const ReactiveStoreMock = mockReactiveStoreConstructor();
describe("individual::search", () => {
  test("Successfully loaded applicants will get stored into the modules internal state", async () => {
    const state$ = new ReactiveStoreMock({
      applicant: null,
      documents: null,
      isLoading: false,
      isPreloaded: false,
      isPersisted: null,
    });
    const foundApplicant = new Applicant();
    foundApplicant.entityId = "some-entity-id";
    foundApplicant.name = Object.assign(foundApplicant.name, {
      givenName: "Testgivenname",
      familyName: "Testlastname",
    });
    const foundDocument = new Document();
    foundDocument.idType = "PASSPORT";

    const { frankieClient } = mockFrankieClient({ sessionType: "reference" });
    frankieClient.stubResponse(
      { method: "get", url: "/data/v2/applicant" },
      {
        status: 200,
        data: {
          applicant: foundApplicant.toJSON(),
          documents: [foundDocument.toJSON()],
        },
      }
    );
    const client = new ApplicantClient(frankieClient);
    const eventHub = new EventHubMock();
    await mkSearch({ client, eventHub, state$, recipeName: "auto" })();

    expect(state$.next).toHaveBeenCalledWith(
      {
        applicant: foundApplicant,
        documents: [foundDocument],
        isPersisted: true,
        isPreloaded: true,
        isLoading: false
      }
    );
  });
  test("Applicants when not found: if using reference, will initialise with empty values", async () => {
    const state$ = new ReactiveStoreMock({
      applicant: null,
      documents: null,
      isLoading: false,
      isPreloaded: false,
      isPersisted: null,
    });

    const { frankieClient } = mockFrankieClient({ sessionType: "reference" });
    frankieClient.stubResponse({ method: "get", url: "/data/v2/applicant" }, { status: 404 });
    const client = new ApplicantClient(frankieClient);
    const eventHub = new EventHubMock();
    await mkSearch({ client, eventHub, state$, recipeName: "auto" })();

    expect(eventHub.emit).not.toHaveBeenCalledWith("error", expect.anything());
    const expectedApplicant = new Applicant();
    expectedApplicant.profile = new Profile("auto", "electronic");
    expectedApplicant.customerReference = "some-reference";
    expect(state$.next).toHaveBeenCalledWith(
      {
        applicant: expectedApplicant,
        documents: [],
        isLoading: false,
        isPreloaded: false,
        isPersisted: false
      }
    );
    expect(eventHub.emit).toHaveBeenCalledWith(
      "data_loaded",
      expect.objectContaining({ reference: "some-reference", isPreloaded: false })
    );
  });
  test("Applicants when not found: if using entity id, will emit/throw error and not initialise any state", async () => {
    const state$ = new ReactiveStoreMock({
      applicant: null,
      documents: null,
      isLoading: false,
      isPreloaded: false,
      isPersisted: null,
    });

    const { frankieClient } = mockFrankieClient({ sessionType: "entityId" });
    frankieClient.stubResponse({ method: "get", url: "/data/v2/applicant" }, { status: 404 });
    const client = new ApplicantClient(frankieClient);
    const eventHub = new EventHubMock();
    let thrown;
    try {
      await mkSearch({ client, eventHub, state$, recipeName: "auto" })();
    } catch (e) {
      thrown = e;
    }

    expect(thrown?.message).toMatch(/Critical error!/);
    expect(eventHub.emit).toHaveBeenCalledWith("error", expect.anything());
    expect(state$.next).not.toBeCalled();
    expect(eventHub.emit).not.toHaveBeenCalledWith("data_loaded", expect.anything());
  });
});
