export type ModuleCategory = "component" | "flow" | "private" | "setup";
/**
 * ModuleCategories
 * ----[ Component modules
 * These are the main modules of the OneSDK. They are the bricks with which the OneSDK provides all the different functionalities. They will usually map to FrankieOne services.
 * ----[ Flow modules
 * Similar to Component modules, they are a bit more abstract and offer simplified functionalities around the Component modules. They may initialise multiple components and orchestrate them,
 * or provide direct integration with Vendors which offer bundle services, which can't be split into Components
 * ----[ Private modules
 * Used mainly internally and because multiple modules rely on their behaviour to be consistent, they are more strictly controlled. The "individual" module is currently the only in this category, but eventually "organisation" will be another.
 * ----[ Setup modules
 * Use exclusively internally by the OneSDK initialisation process. They are not exposed to the user and are not part of the OneSDK public API. They are still available for use by other modules.
 * "Session" is an example of a pre initialisation module. It is initialised with the OneSDK and made available to other modules, allowing each of them to manage the OneSDK session internally.
 * 
 * TODO: Get rid of Setup modules entirely. These don't need to be a category of modules and can be used ad-hoc, without any constraints or special treatment.
 * TODO: These modules can be shared along with the GlobalState object and made available everywhere without being tied to the same restrictions as "component", "flow", or "private" modules.
 */
export type ModuleCategoryMapping<ModuleName extends string = string> = Record<ModuleCategory, ModuleName>;
