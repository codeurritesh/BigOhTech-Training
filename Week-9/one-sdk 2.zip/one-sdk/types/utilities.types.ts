import type { Dictionary, EmptyObject, EmptyValue } from './primitives.types';

export {};
/**
 * ParameterSubtraction<Func, Sub>
 * Helper Type that if Func is a function whose first argument is an object,
 * return said object without any properties in common with object Sub
 */
// Using "any" for compatibility with older typescript versions
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type ParameterSubtraction<Func, Sub extends Dictionary> = Func extends (...args: any[]) => unknown
  ? Omit<Parameters<Func>[0], keyof Sub> extends Record<string, never>
    ? never
    : Omit<Parameters<Func>[0], keyof Sub>
  : never;

/**
 * KeyOf<Dictionary> Extracts a string-key of an object
 */
export type KeyOf<Dictionary> = Extract<keyof Dictionary, string>;

/**
 * TreeShakenDictionary<Dictionary> Extracts keys of a dictionary, whose value types are "never"
 */
export type TreeShaken<Dictionary> = {
  [K in keyof Dictionary as Dictionary[K] extends never ? never : K]: Dictionary[K];
};
/**
 * Tuple<T, N> Creates a N-Tuple of T
 */
export type _Tuple<T, N extends number, A extends T[] = []> = A extends { length: N } ? A : _Tuple<T, N, [...A, T]>;
export type Tuple<T, N extends number> = _Tuple<T, N, [T]>;

/**
 * Takes a Value type and a numerical Length and returns:
 * - Value, if Length = 1
 * - Length-Tuple of Value, if Length > 1
 */
export type MaybeTuple<Value, Length extends number> = Length extends 1 ? Value : Tuple<Value, Length>;

/**
 * Merges object types together, ignoring undefined types
 */
export type Merge<A extends object, B extends object> = A extends undefined ? B : B extends undefined ? A : A & B;

/**
 * Get length of a tuple
 */
export type Length<Type extends readonly unknown[]> = Type['length'];
/**
 * Get number of parameters of a function
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type ParameterCount<F extends (...args: any) => any> = Length<Parameters<F>>;

/**
 * Provides cleaner type resolution and intellisense.
 * @param Type Type to be expanded
 * @param IgnoreKeys Union of keys to be ignored and kept as is. These keys will apply to the root object only.
 * @returns Expanded type
 * https://effectivetypescript.com/2022/02/25/gentips-4-display/
 */
// eslint-disable-next-line @typescript-eslint/ban-types
export type NOP<T, IgnoreKeys extends keyof T = never> = T extends Function
  ? T
  : { [K in keyof T]: T extends IgnoreKeys ? T[K] : NOP<T[K]> };

/** Branding */
export type Branded<Target extends object, Brand extends string, Value> = Target & {
  [k in Brand]: Value;
};

/** Unbrand */
export type Unbrand<T extends Branded<object, Brand, unknown>, Brand extends string> = T extends Branded<
  object,
  string,
  infer U
>
  ? U
  : never;

/** Extract Union internal types and convert them into a union */
export type TupleUnion<T> = T extends { [K: number]: infer P } ? P : never;

/** Override Origin fields with Overrider */
export type Override<Origin extends Record<string, unknown>, Overrider extends Record<string, unknown>> = TreeShaken<
  Omit<Origin, keyof Overrider> & Overrider
>;

/**
 * Helper type that will check if first parameter meets a condition and if it does, will return the value itself.
 * If the value does not meet the condition, it will return the second parameter.
 * @param Value Value to be checked
 * @param DefaultValue Value to be returned if Value does not meet the condition
 * @param Options object with option `mapTo`, which will replace Value in case it's not empty
 */
export type Default<
  Value,
  DefaultValue,
  Ops extends {
    mapTo?: unknown;
  } = EmptyObject,
> = Value extends EmptyValue ? DefaultValue : Fallback<Ops['mapTo'], void> extends void ? Value : Ops['mapTo'];

/**
 * Helper type that will check if first parameter meets condition and if it doesn't, will return the value itself.
 * If it is, it will return the second parameter.
 */
export type Fallback<Value, FallbackValue> = Value extends EmptyValue ? FallbackValue : Value;
/**
 * Helper which will pick nested property two levels deep.
 * @param Target Target object
 * @param First First level property
 * @param Sec Second level property
 * @returns Target[First][Sec]
 * TODO: Add support for more levels via dot notation
 **/
export type PickNested<Target, First extends keyof Target, Sec extends keyof Target[First]> = Target[First][Sec];

/**
 * Provide a simple way to
 * a) access an object's nested field (2 level only)
 * b) provide a default type when any is missing and
 * c) provide a replacement value when the field is not missing
 * TODO: replace Lvl1 and Lv2 parameters with a single parameter for dot notation to cover any number of levels
 * @param Target The object to pick field from
 * @param Lvl1 Top level field name to be accessed
 * @param Lvl2 Specific second level field name to be accessed
 * @param DefaultVal Default value to be used in case the field is missing
 * @param ReplaceValue Value to be returned if the field is not missing, instead of the actual value
 * @returns The value of the field, or the default value if the field is missing
 */
export type Field<
  Target extends Dictionary,
  Lvl1 extends keyof Target,
  Lvl2 extends keyof Target[Lvl1],
  DefaultVal = PickNested<Target, Lvl1, Lvl2>,
  ReplaceValue = void,
> = Lvl1 extends keyof Target
  ? Lvl2 extends keyof Target[Lvl1]
    ? // If both lvl1 and lvl2 fields are present in the target object
      ReplaceValue extends void
      ? // If no replacement value is provided, return the actual value
        Target[Lvl1][Lvl2]
      : // If a replacement value is provided, return it instead
        ReplaceValue
    : // If fields lvl1 and lvl2 are not present in the target object, return the default value
      DefaultVal
  : DefaultVal;
