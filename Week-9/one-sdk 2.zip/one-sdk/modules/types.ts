/**
 * Explicitly Export types (with type-only exports) and enums (without "type") at the root when importing into a typescript project via npm
 * https://www.typescriptlang.org/docs/handbook/release-notes/typescript-3-8.html#type-only-imports-and-export
 */

import type { DeviceModule } from '@module/device';
import type { IDVModule } from '@module/idv';
import type { IndividualModule } from '@module/individual';

export type { Modules } from '@config';
export { ENVIRONMENTS as Environments } from '@module/common';
export type { Accessors, ReadonlyAccessors } from '@module/common';
export type { CheckSummary } from '@module/common/shared/models/CheckSummary';
export type { DeviceModule, Events as DeviceModuleEvents } from '@module/device';
export { DummyFrankieApiClient, FrankieApiClient } from '@module/frankie-client';
export type { IndividualModule, Events as IndividualModuleEvents } from '@module/individual';
export { Status as OCRStatus } from '@module/ocr';
export { SdkModes as SdkMode } from '@module/sdk/types';
export type { OneSdkRootParameters as OneSdkConfiguration, OneSdkContext } from './sdk/types';

export type DeviceModuleContext = DeviceModule['moduleContext'];

export type IndividualModuleContext = IndividualModule['moduleContext'];

export type IDVModuleContext = IDVModule['moduleContext'];
