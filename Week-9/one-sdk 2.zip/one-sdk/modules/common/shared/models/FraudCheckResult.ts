import { FraudMatchDetail } from "./FraudMatchDetail";

interface IFraudCheckResult {
  matches: FraudMatchDetail[];
}
export class FraudCheckResult implements IFraudCheckResult {
  matches: FraudMatchDetail[] = [];

  toJSON(): FraudCheckResult {
    const matchesToJSON = this.matches.map((a) => a.toJSON());
    return { ...this, matches: matchesToJSON };
  }
  static fromJSON(payload: IFraudCheckResult): FraudCheckResult {
    const newFraudCheckResult = new FraudCheckResult();
    newFraudCheckResult.matches = payload.matches;
    return newFraudCheckResult;
  }
}
