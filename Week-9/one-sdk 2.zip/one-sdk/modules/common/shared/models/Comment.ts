import { IChangeStamp } from "./IChangeStamp";

export interface IComment {
  comment: string;
  associatedResourceId: string; //uuid
  created: IChangeStamp;
  context: ContextString;
}

export enum ContextString {
  supporting_docs = "supporting_docs",
}

export class Comment implements IComment {
  comment: string;
  associatedResourceId: string;
  created: IChangeStamp;
  context: ContextString;

  constructor(payload: IComment) {
    this.comment = payload.comment;
    this.associatedResourceId = payload.associatedResourceId;
    this.created = payload.created;
    this.context = payload.context;
  }

  toJSON(): IComment {
    return { ...this };
  }

  static fromJSON(payload: IComment): Comment {
    return new Comment({ ...payload });
  }
}
