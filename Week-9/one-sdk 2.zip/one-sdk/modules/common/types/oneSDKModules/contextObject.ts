import { CommonEvents, EventListener, EventsDictionary } from "@module/common";

/**
 * Module context represents an instance of a module. It is the result of calling the initialise function of that module.
 * Both "Component" and "Flow" are instances of a module which are created by their respective factory functions. The factory function will:
 * 1) Take any custom options the module might required, as defined by its implementation of the ModuleInitialiseFunction.
 * 2) Call the ModuleInitialiseFunction with the shared state and the custom options.
 * 3) Inject instanceName into the resulting context object and store it in the dictionary of instances.
 * 4) The final object is defiend by the type ModuleInstance below
 * The ModuleContext interface is the merge of a custom interface for each module with an EventListener (the methods "on" and "off")
 */
export type ModuleContext<Context extends object = object, Events extends EventsDictionary = CommonEvents> = Context &
  EventListener<Events>;
/**
 * The context object injected with the instanceName property. Details above.
 */
export type ModuleInstance<Ctx extends ModuleContext = ModuleContext> = Ctx & { instanceName: string };
