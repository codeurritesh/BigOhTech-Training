import format from "string-format";
export const strFormat = format;
