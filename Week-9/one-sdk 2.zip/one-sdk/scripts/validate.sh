npm run eslint-check || exit 1
npm run tsc-check || exit 1
npm run test:analyze || exit 1
