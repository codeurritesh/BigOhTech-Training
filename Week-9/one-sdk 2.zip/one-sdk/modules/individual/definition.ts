import type { AccessFunction, AccessorsDictionary } from '@module/common';
import type { Address } from '@module/common/shared/models/Address';
import type { Applicant } from '@module/common/shared/models/Applicant';
import type { CheckSummary } from '@module/common/shared/models/CheckSummary';
import type { Document } from '@module/common/shared/models/Document';
import type { ModuleDefinition } from '@module/common/types';

import type { Events } from './events';

export type IndividualModule = ModuleDefinition<{
  module: {
    category: 'private';
    name: 'individual';
    context: IndividualModuleContext;
    events: Events;
  };
}>;

export type IndividualModuleContext = {
  /** Has already attempted to load any existing data. This is true even when there's no data to load */
  isLoading: () => boolean;
  /** Existing data was found for this individual */
  isPreloaded: () => boolean;
  /** Whenever making any changes to the individual details an "isPersisted" flag is set to "false" until "submit" is called */
  isPersisted: () => boolean;
  /** Add consent string to the entity's list of consents  */
  addConsent: (type: string) => void;
  /** Add whole new {@link Document} to entity's list of identity documents */
  addDocument: (details: Document) => void;
  /** Update existing Document object by its documentId  */
  updateDocument: (id: string, details: Document) => void;
  /** Add new address to entity's list of addresses */
  addAddress: (details: Address) => void;
  /** Update existing Address object by its addressId */
  updateAddress: (id: string, details: Address) => void;
  addReference: {
    /**
     * Attach a new indexable "customer_reference" to the entity. Won't override a previously set customer reference.
     **/
    (customerReference: string): void;
    /** Attach a new indexable "key" reference to the entity */
    (key: string, value: string): void;
  };
  /** Persist all entity data in this component. Optional parameter { verify: true } may be provided, which will cause this method to resolve to a [Check summary object]{@link CheckSummary} */
  submit: <T extends boolean>(o?: { verify: T }) => Promise<T extends true ? CheckSummary : void>;
  /** Access public property {@link PublicAccessors} */
  access: AccessFunction<PublicAccessors>;
  /** Trigger another search for any existing data for this entity within the service. ! ATTENTION: This will cause a rewrite of any unpersisted information. */
  search: () => Promise<void>;
};

export type PublicAccessors = AccessorsDictionary<{
  readonly entityId: Applicant['entityId'];
  name: Applicant['name'];
  dateOfBirth: Applicant['dateOfBirth'];
  consentsGiven: Applicant['consents'];
  documents: Document[];
  addresses: Address[];

  /** @deprecated This field is temporary and should not be used */
  __deprecated_applicant: Applicant;
  /** @deprecated This field is temporary and should not be used */
  __deprecated_documents: Document[];

  /** Internal loading state. Set to false at the start of every call of submit/search methods and set to true on completion.  */
  readonly isLoading: boolean;
  readonly isPersisted: boolean;
}>;

export type InternalState = {
  applicant: Applicant;
  documents: Document[];
  isLoading: boolean;
  isPreloaded: boolean;
  isPersisted: boolean;
};
