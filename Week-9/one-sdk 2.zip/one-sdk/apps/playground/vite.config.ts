import react from '@vitejs/plugin-react';
import mergeDefaultConfig from '../common/vite.config';
import basicSsl from '@vitejs/plugin-basic-ssl';

const PORT = 3001;
// ALIAS_ONE_SDK is true if not defined. By default always use internal OneSDK source code
const ALIAS_ONE_SDK = process.env.npm_config_use_npm !== 'true';
export default mergeDefaultConfig(
  {
    plugins: [react(), basicSsl()],
    server: {
      port: PORT,
      proxy: {
        '/callback': {
          target: `http://127.0.0.1:${PORT}`,
          rewrite: (path) => path.replace('/callback', ''),
        },
      },
      https: true,
    },
  },
  { appDir: 'playground', entryFile: 'main.tsx', aliasOneSdkSourceCode: ALIAS_ONE_SDK },
);
