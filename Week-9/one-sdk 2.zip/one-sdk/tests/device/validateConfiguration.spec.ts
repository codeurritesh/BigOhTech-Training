import { mkEventHub } from '@module/common';
import { InjectedState } from '@module/common/types';
import DeviceInitialise from '@module/device';

import { optionalParameters } from '@tests/testUtils/functionUtilities';

const DeviceModule = optionalParameters(DeviceInitialise);
describe('device: configuration', () => {
  test("Dummy mode is rejected, since there's no implementation for it yet", () => {
    const failureEvent = jest.fn();
    const globalEventHub = mkEventHub();
    try {
      DeviceModule(
        <InjectedState>{
          mode: { modeName: 'dummy' },
          globalEventHub,
          recipe: {},
        },
        { activityType: 'LOGIN' },
      );
    } catch (error) {
      failureEvent(error);
    }
    expect(failureEvent).toHaveBeenCalledWith(
      expect.objectContaining({
        message: "There is no implementation for the device component in 'dummy' mode.",
      }),
    );
  });
});
describe('device: configuration', () => {
  test('missing configuration emits error event globally: with {}', () => {
    const failureEvent = jest.fn();
    const globalEventHub = mkEventHub();
    try {
      DeviceModule(
        <InjectedState>{
          mode: { modeName: 'development' },
          globalEventHub,
          recipe: {},
        },
        { activityType: 'LOGIN' },
      );
    } catch (error) {
      failureEvent(error);
    }
    expect(failureEvent).toHaveBeenCalledWith(
      expect.objectContaining({
        message:
          "Your account doesn't have any device characteristics providers configured. Please contact FrankieOne support.",
      }),
    );
  });
  test('missing configuration emits error event globally: with deviceCharacteristics: { }', () => {
    const failureEvent = jest.fn();
    const globalEventHub = mkEventHub();
    try {
      DeviceModule(
        <InjectedState>{
          mode: { modeName: 'development' },
          globalEventHub,
          recipe: { deviceCharacteristics: {} },
        },
        { activityType: 'LOGIN' },
      );
    } catch (error) {
      failureEvent(error);
    }

    expect(failureEvent).toHaveBeenCalledWith(
      expect.objectContaining({
        message:
          "Your account doesn't have any device characteristics providers configured. Please contact FrankieOne support.",
      }),
    );
  });
  test('missing configuration emits error event globally: with deviceCharacteristics: { provider: {} }', () => {
    const failureEvent = jest.fn();
    const globalEventHub = mkEventHub();
    try {
      DeviceModule(
        <InjectedState>{
          mode: { modeName: 'development' },
          globalEventHub,
          recipe: { deviceCharacteristics: { provider: {} } },
        },
        { activityType: 'LOGIN' },
      );
    } catch (error) {
      failureEvent(error);
    }

    expect(failureEvent).toHaveBeenCalledWith(
      expect.objectContaining({
        message:
          "Your account doesn't have any device characteristics providers configured. Please contact FrankieOne support.",
      }),
    );
  });
  test('missing configuration emits error event globally: with deviceCharacteristics: { provider: { name } }', () => {
    const failureEvent = jest.fn();
    const globalEventHub = mkEventHub();
    try {
      DeviceModule(
        <InjectedState>{
          mode: { modeName: 'development' },
          globalEventHub,
          recipe: { deviceCharacteristics: { provider: { name: 'sardine' } } },
        },
        { activityType: 'LOGIN' },
      );
    } catch (error) {
      failureEvent(error);
    }

    expect(failureEvent).toHaveBeenCalledWith(
      expect.objectContaining({
        message: `Your account is missing the environment configuration for the device characteristics provider "sardine". Please contact FrankieOne support.`,
      }),
    );
  });
});
